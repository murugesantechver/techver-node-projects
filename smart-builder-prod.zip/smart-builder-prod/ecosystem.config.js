module.exports = {
    apps: [
        {
            name: 'smartbuilder-backend',
            script: 'node ./bin/www',
        },
    ],
};
