const {scheduleEmail} = require('./emailJob');

module.exports = {
    scheduleEmail
}
