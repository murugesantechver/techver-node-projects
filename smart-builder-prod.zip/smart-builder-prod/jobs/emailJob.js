const cron = require('node-cron');
const emailUtils = require('../utilities/emailUtils');
const userRepository = require('../modules/user/user.repository');
const { logger } = require('../utilities');
const { CONSTANTS } = require('../configs');

exports.scheduleEmail = async () => {
    try {
        cron.schedule('* * * * *', async () => {
            const usersWithEmailSentStatus = await userRepository.findUsersByEmailSentStatus(false);
            if (usersWithEmailSentStatus.length > 0) {
                logger.info(`########### Sending Pending ${usersWithEmailSentStatus.length} Registration Emails to be sent ###########`);
                for (const user of usersWithEmailSentStatus) {
                    const redirectLink = CONSTANTS.REDIRECTS.RESET_PASSWORD + user.id;
                    const emailSent = await emailUtils.sendUserRegistrationMail(user.email, user.userName, redirectLink);
                    if (emailSent) {
                        const userData = {
                            emailSent: true,
                        };
                        await userRepository.updateEmailSentStatus(user.id, userData);
                    }
                }
            }
        });
    } catch (error) {
        logger.error('Exception occured');
        logger.error(error.message);
        logger.error('Cron Job Ended With Exception');
    }
};
