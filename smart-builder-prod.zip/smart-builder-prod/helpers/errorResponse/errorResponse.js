class ErrorResponse extends Error {
    constructor(message, statusCode, code) {
        super(message);
        this.type = 'Error';
        this.statusCode = statusCode;
        this.code = code ? code : null;
    }
}

module.exports = ErrorResponse;
