const { HTTP_CODES } = require('../../configs');

class pwsBadRequestException extends Error {
    constructor(message, err = null) {
        super(message);
        this.code = HTTP_CODES.CONTINUE;
        this.status = 'error';
        this.type = 'text';
        this.data = message;
    }
}

module.exports = pwsBadRequestException;
