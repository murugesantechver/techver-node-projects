const CryptoJS = require('crypto-js');
const { CONSTANTS, MESSAGES } = require('../configs');
const { BadRequestException } = require('./errorResponse');

const secretKey = CONSTANTS.ENCRYPTION.secret;

function decryptData(data) {
    try {
        const decodedCiphertext = base64Decode(data);
        const bytes = CryptoJS.AES.decrypt(decodedCiphertext, secretKey);
        const decryptedData = bytes.toString(CryptoJS.enc.Utf8);
        return JSON.parse(decryptedData);
    } catch (e) {
        throw new BadRequestException(MESSAGES.APP.decryptionError);
    }
}

function encryptData(data) {
    try {
        const plaintext = JSON.stringify(data);
        const ciphertext = CryptoJS.AES.encrypt(plaintext, secretKey).toString();
        const encodedCiphertext = base64Encode(ciphertext);
        return encodedCiphertext;
    } catch (e) {
        throw new BadRequestException(MESSAGES.APP.encryptionError);
    }
}

function decryptJsonValue(obj) {
    const result = {};
    for (let key in obj) {
        if (typeof obj[key] === 'object') {
            result[key] = decryptJsonValue(obj[key]);
        } else {
            result[key] = decryptData(obj[key]);
        }
    }
    return result;
}

function encryptJsonValue(obj) {
    const result = {};
    for (let key in obj) {
        if (typeof obj[key] === 'object') {
            result[key] = encryptJsonValue(obj[key]);
        } else {
            result[key] = encryptData(obj[key]);
        }
    }
    return result;
}

function encryptArrayOfObjects(obj) {
    if (Array.isArray(obj)) {
        return obj.map((item) => encryptJsonValue(item));
    }

    const result = {};
    for (let key in obj) {
        if (typeof obj[key] === 'object') {
            result[key] = encryptJsonValue(obj[key]);
        } else {
            result[key] = encryptData(obj[key]);
        }
    }
    return result;
}

function decryptArrayOfObjects(obj) {
    if (Array.isArray(obj)) {
        return obj.map((item) => decryptJsonValue(item));
    }

    const result = {};
    for (let key in obj) {
        if (typeof obj[key] === 'object') {
            result[key] = decryptJsonValue(obj[key]);
        } else {
            result[key] = decryptData(obj[key]);
        }
    }
    return result;
}

function base64Decode(str) {
    return atob(str);
}

function base64Encode(str) {
    return btoa(str);
}

module.exports = { decryptData, encryptData, decryptJsonValue, encryptJsonValue, encryptArrayOfObjects, decryptArrayOfObjects };
