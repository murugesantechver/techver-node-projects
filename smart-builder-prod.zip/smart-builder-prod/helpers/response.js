const { HTTP_CODES } = require('../configs');
const { encryptData } = require('../helpers/encryption');

function encryptNestedIds(obj) {
    for (let key in obj) {
        if (typeof obj[key] === 'object') {
            encryptNestedIds(obj[key]);
        } else if (key === 'id') {
            obj[key] = encryptData(obj[key]);
        }
    }
}

const formatResponse = (res, statusCode, message, data, custom, mode) => {
    if (data) {
        encryptNestedIds(data);
    }
    if (custom) {
        if (mode == 'normal') {
            res.status(statusCode).json({
                status: data,
            });
        }
        if (mode == 'pws') {
            res.status(statusCode).send(data);
        }
    } else {
        res.status(statusCode).json({
            message,
            data,
        });
    }
};

exports.success = (res, data, message) => formatResponse(res, HTTP_CODES.OK, message, data, false);
exports.created = (res, data, message) => formatResponse(res, HTTP_CODES.CREATED, message, data, false);
exports.badRequest = (res, data, message) => formatResponse(res, HTTP_CODES.BAD_REQUEST, message, data, false);
exports.unAuthorized = (res, data, message) => formatResponse(res, HTTP_CODES.UNAUTHORIZED, message, data, false);
exports.forbidden = (res, data, message) => formatResponse(res, HTTP_CODES.FORBIDDEN, message, data, false);
exports.notFound = (res, data, message) => formatResponse(res, HTTP_CODES.NOT_FOUND, message, data, false);
exports.noContent = (res) => res.status(HTTP_CODES.NO_CONTENT).send();
exports.notify = (res, data, message) => formatResponse(res, HTTP_CODES.OK, message, data, true, 'normal');
exports.pwsSuccess = (res, data, message) => formatResponse(res, HTTP_CODES.OK, message, data, true, 'pws');
exports.pwsError = (res, data, message) => formatResponse(res, HTTP_CODES.BAD_REQUEST, message, data, true, 'pws');
