/* const { Roles, Rolepermission, Permission } = require('../database/models');
const { Op } = require('sequelize');

exports.checkPermission = async (role, permisssion) => {
    const roleCheck = [{ role: { [Op.like]: role } }];
    console.log("roleCheck", roleCheck)
    const roleId = await Roles.findOne({
        where: {
            [Op.or]: roleCheck,
        },
    });
    const permissionCheck = [{ permission: { [Op.like]: permisssion } }];
    console.log("permissionCheck", permissionCheck)
    const permissionId = await Permission.findOne({
        where: {
            [Op.or]: permissionCheck,
        },
    });
    const userCheck = [{ roleId: roleId.id, permissionId: permissionId.id }];
    console.log("userCheck", userCheck)
    const doesPermissionMatch = await Rolepermission.findOne({
        where: {
            [Op.or]: userCheck,
        },
    });
    console.log("doesPermissionMatch", doesPermissionMatch)
    if (!doesPermissionMatch) {
        return false;
    }
    return true;
}; */

const { Roles, Rolepermission, Permission } = require('../database/models');
const { Op } = require('sequelize');

exports.checkPermission = async (role, permission) => {
    const result = await Rolepermission.findOne({
        where: {
            [Op.and]: [
                {
                    '$roleName.role$': role,
                },
                {
                    '$permissionName.permission$': permission,
                },
            ],
        },
        include: [
            {
                model: Roles,
                as: 'roleName',
                where: {
                    role: role,
                },
            },
            {
                model: Permission,
                as: 'permissionName',
                where: {
                    permission: permission,
                },
            },
        ],
    });

    if (result) {
        return true
    }
    

    return false;
};