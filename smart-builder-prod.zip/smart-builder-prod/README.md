# smart-builder

Smart Builder is the backend for managing campaigns.

## Setting Up the Backend

#### Required Dependencies

-   NodeJS (Ver 16 and Above)
-   PostgreSQL

##### Steps to setup

1. Clone the backend repository

```
git clone https://github.com/arundotrs/smart-builder.git
```

2. Change Directory to Smart Builder

```
cd smart-builder
```

3. Setup environment according to the sample environment

```
# APP
NODE_ENV=development
PORT=4000

# Database

DB_USERNAME=<Username>
DB_PASSWORD=<Password>
DB_NAME=<Name>
DB_HOST=<Host>
DB_PORT=<5432>
DB_DIALECT=<>

# JWT
JWT_SECRET="some secret"
JWT_TOKEN_EXPIRY_IN="60m"

# CORS
CORS_WHITELIST_IP="['http://localhost:4000']"

# Encryption
ENCRYPTION_SECRET="your-secret-here"

# OTP
# Twilio config
OTP_EXPIRY_MINUTES=5
TWILIO_ACCOUNT_SID="twillio sid
TWILIO_AUTH_TOKEN=twillio auth token
TWILIO_FROM_PHONE='from phone number'

# NODEMAILER
SENDER_EMAIL="sender gmail address"
SENDER_PASSWORD="sender gmail password"

```

4. Start the backend server

```
npm start

```

This will create all the required migrations and seed the database with data to get started.
