const app = require('../app');
require('dotenv').config();
const { superAdmin } = require('./env.json');
const { superAdminLogin } = require('../modules/user/tests/superAdminTest');
const { clientCreate } = require('../modules/user/tests/adminCreateTest');

describe('Admin Test Cases', () => {
    superAdminLogin();
    clientCreate(superAdmin.superAdminAccessToken);
});
