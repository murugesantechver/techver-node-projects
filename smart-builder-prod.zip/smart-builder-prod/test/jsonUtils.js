const fs = require('fs');
const { logger } = require('../utilities');

// Function to read the JSON file
function readJsonFile(filePath) {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        // If the file doesn't exist or is invalid JSON, return an empty object
        return {};
    }
}

function saveTokensToFile(filePath, tokens) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(tokens, null, 2), 'utf8');
    } catch (error) {
        logger.info('Testing: Error Saving Env to file');
    }
}

module.exports = {
    readJsonFile,
    saveTokensToFile,
};
