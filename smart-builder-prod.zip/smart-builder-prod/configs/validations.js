const MESSAGES = require('./messages');
const Joi = require('joi');

module.exports = {
    mobileNumber: Joi.string()
        .length(10) // The total length should be 10 digits
        .pattern(/^[0-9]{10}$/), // Matches a string consisting of exactly 10 digits
    otp: Joi.string()
        .length(4)
        .pattern(/^[0-9]+$/),
    state: Joi.string(),
    city: Joi.string(),
    email: Joi.string().trim().lowercase().email(),
    firstName: Joi.string()
        .trim()
        .regex(/^[a-z ,.'-]+$/i)
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.nameValidation,
        }),
    lastName: Joi.string()
        .trim()
        .regex(/^[a-z ,.'-]+$/i)
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.nameValidation,
        }),
    address1: Joi.string()
        .trim()
        .regex(/^(?!.*\.\.)(?!.*\.$)[^\W][\w.]{2,29}$/)
        .prefs({ convert: true })
        .label('address1')
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.addressValidation,
        }),
    address2: Joi.string()
        .trim()
        .regex(/^(?!.*\.\.)(?!.*\.$)[^\W][\w.]{2,29}$/)
        .prefs({ convert: true })
        .label('address2')
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.addressValidation,
        }),
    pinCode: Joi.string()
        .length(6)
        .pattern(/^[0-9]+$/)
        .prefs({ convert: true })
        .label('pincode')
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.pincodeValidation,
        }),
    panCard: Joi.string()
        .trim()
        .regex(/^[A-Z]{5}\d{4}[A-Z]$/)
        .prefs({ convert: true })
        .label('PAN card number')
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.panCardValidation,
        }),
    aadharCard: Joi.string()
        .length(12)
        .pattern(/^[0-9]+$/)
        .prefs({ convert: true })
        .label('Aadhar card number')
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.aadharCardValidation,
        }),
    ifscCode: Joi.string()
        .length(11)
        .pattern(/^[A-Z]{4}\d{7}$/)
        .prefs({ convert: true })
        .label('IFSC Code')
        .messages({
            'string.pattern.base': 'Invalid IFSC code format',
        }),
    accountNumber: Joi.string()
        .trim()
        .regex(/^\d{1,20}$/)
        .prefs({ convert: true })
        .label('Bank Account Number')
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.bankAccountValidation,
        }),
    vpa: Joi.string()
        .trim()
        .regex(/^[\w.@]+$/)
        .prefs({ convert: true })
        .label('UPI ID')
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.upiIdValidation,
        }),
    payTM: Joi.string()
        .length(10)
        .pattern(/^[0-9]+$/)
        .prefs({ convert: true })
        .label('Paytm Number')
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.walletAppsNumberValidation,
        }),
    phonePe: Joi.string()
        .length(10)
        .pattern(/^[0-9]+$/)
        .prefs({ convert: true })
        .label('Phonepe Number')
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.walletAppsNumberValidation,
        }),
    voucherCode: Joi.string().trim().alphanum().label('Voucher Code').messages({
        'string.alphanum': MESSAGES.SURVEY.voucherCodeValidation,
    }),
    date: Joi.date().raw().label('Date').messages({
        'string.date': MESSAGES.SURVEY.dateValidation,
    }),
    name: Joi.string()
        .trim()
        .regex(/^[a-z ,.'-]+$/i)
        .messages({
            'string.pattern.base': MESSAGES.SURVEY.nameValidation,
        }),
    telephone: Joi.string()
        .length(10) // The total length should be 10 digits
        .pattern(/^[0-9]{10}$/), // Matches a string consisting of exactly 10 digits
    type: Joi.string().valid('BANK_ACCOUNT', 'UPI'),
    callbackUrl: Joi.string().uri({ scheme: ['http', 'https'] }), // TODO Currenty supports both http and https
};
