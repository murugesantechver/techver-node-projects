const constants = require('./constants');
const httpCodes = require('./httpCodes');
const messages = require('./messages');
const validation = require('./validations');
const loggerConfig = require('./loggerConfig');

module.exports = {
    CONSTANTS: constants,
    HTTP_CODES: httpCodes,
    MESSAGES: messages,
    CAMPAIGN_VALIDATION: validation,
    LOGGER_CONFIG: loggerConfig,
};
