module.exports = {
    APP: {
        env: process.env.NODE_ENV,
        port: process.env.PORT,
        baseUrl: {
            development: 'http://localhost:4000',
            production: 'http://localhost:4000',
        },
    },
    JWT: {
        secret: process.env.JWT_SECRET,
        accessToken: {
            expiresIn: process.env.JWT_ACCESS_TOKEN_EXPIRES_IN,
        },
        refreshToken: {
            expiresIn: process.env.JWT_REFRESH_TOKEN_EXPIRES_IN,
        },
        tokenSource: {
            accessToken: 'access-token',
            refreshToken: 'refresh-token',
            forgotPassword: 'forgot-password',
        },
    },
    CORS: {
        whitelistIP: "['http://localhost:3000', 'http://202.88.236.230', 'http://localhost:4000']",
    },
    USER: {
        roles: {
            admin: 'ADMIN',
            superAdmin: 'SUPERADMIN',
        },
        permissions: {
            ADMIN: {
                surveyReporting: 'partial',
                eventCreate: 'partial',
                clientCreate: 'none',
            },
            SUPERADMIN: {
                surveyReporting: 'full',
                eventCreate: 'full',
                clientCreate: 'full',
            },
        },
    },
    ENCRYPTION: {
        secret: process.env.ENCRYPTION_SECRET,
        privateKey: '',
        publicKey: '',
    },
    OTP: {
        expiryMinutes: '5',
        twillioAccountId: process.env.TWILIO_ACCOUNT_SID,
        twillioAuthToken: process.env.TWILIO_AUTH_TOKEN,
        twillioFromNumber: process.env.TWILIO_FROM_PHONE,
    },
    ENUMS: {
        clientStatus: ['ACTIVE', 'INACTIVE'],
        paymentType: ['BANK_ACCOUNT', 'UPI'],
        fieldType: ['NORMAL', 'REWARD'],
        campaignStatus: ['ONGOING', 'COMPLETED', 'UPCOMING'],
        campaignModes: ['NORMAL', 'WHATSAPP'],
        inviteeStatus: ['ACTIVE', 'DISABLED'],
        voucherStatus: ['AVAILABLE', 'REDEEMED'],
        userStatus: ['ACTIVE', 'INACTIVE', 'DISABLED'],
        adminRoles: ['SUPERADMIN', 'ADMIN'],
        rewardFrame: ['MINUTE', 'HOURLY', 'WEEKLY', 'MONTHLY'],
        beneficiaryStatus: ['CREATED', 'VALIDATING', 'VALIDATED'],
        paymentStatus: ['PENDING', 'FAILED', 'VALIDATING', 'COMPLETED'],
        orderStatus: ['CREATED', 'COMPLETE', 'CANCELLED'],
    },
    SURVEY: {
        fileFields: ['file', 'aadhar', 'pan'],
    },
    CAMPAIGN: {
        campaignIdLength: 5,
    },
    EMAIL: {
        emailCreds: {
            email: process.env.SENDER_EMAIL,
            password: process.env.SENDER_PASSWORD,
            CLIENT_ID: process.env.CLIENT_ID,
            CLIENT_SECRET: process.env.CLIENT_SECRET,
            REFRESH_TOKEN: process.env.REFRESH_TOKEN,
            APP_PASSWORD: process.env.APP_PASSWORD,
        },
    },
    TEMPLATES: {
        invitee: {
            template1: [
                { id: 'name', title: 'Name' },
                { id: 'phone', title: 'Phone' },
                { id: 'status', title: 'Status' },
            ],
            template2: [
                { id: 'phone', title: 'Phone' },
                { id: 'status', title: 'Status' },
            ],
            template3: [
                { id: 'name', title: 'Name' },
                { id: 'status', title: 'Status' },
            ],
        },
        voucher: {
            template1: [
                { id: 'voucherNumber', title: 'Voucher Number' },
                { id: 'denomnination', title: 'Denomination' },
                { id: 'status', title: 'Status' },
            ],
            template2: [
                { id: 'denomnination', title: 'Denomination' },
                { id: 'status', title: 'Status' },
            ],
            template3: [
                { id: 'voucherNumber', title: 'Voucher Number' },
                { id: 'status', title: 'Status' },
            ],
        },
        campaignUrl: {
            template1: [
                { id: 'uniqueId', title: 'Unique Id' },
                { id: 'uniqueUrl', title: 'Url' },
            ],
        },
    },
    QWIKGIFTAPI: {
        sandBoxCredentials: {
            consumerKey: process.env.SANDBOX_QWIKGIFTAPI_CONSUMER_KEY,
            consumerSecret: process.env.SANDBOX_QWIKGIFTAPI_CONSUMER_SECRET,
            username: process.env.SANDBOX_QWIKGIFTAPI_USERNAME,
            password: process.env.SANDBOX_QWIKGIFTAPI_PASSWORD,
        },
        sandBoxBaseUrl: {
            baseUrl: process.env.SANDBOX_QWIKGIFTAPI_BASE_URL,
        },
        apiRoutes: {
            generateAuthorizationCode: '/oauth2/verify',
            generateBearerToken: '/oauth2/token',
            validateBeneficiary: '/rest/v3/beneficiaries/validations',
            createOrder: '/rest/v3/orders',
            createBeneficiary: `/rest/v3/customers/${process.env.SANDBOX_QWIKGIFTAPI_CUSTOMERID}/beneficiaries`,
        },
        tokenGenerationOptions: {
            dayGap: 6,
        },
    },
    TESTCASE: {
        superAdminAccessToken: '',
        superAdminRefreshToken: '',
        adminAccessToken: '',
        adminRefreshToken: '',
        userId: '',
    },
    QUEUE: {
        CONNECTION_URL: process.env.RMQ_CONN_URL,
        LIST: {
            createOrder: 'createOrder',
            validateBeneficiary: 'validateBeneficiary',
            createBeneficiary: 'createBeneficiary',
        },
    },
    REDIRECTS: {
        RESET_PASSWORD: process.env.RESET_PASSWORD_URL,
    },
};
