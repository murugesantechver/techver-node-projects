module.exports = {
    USER: {
        register: {
            action: 'Admin Register',
        },
        login: {
            action: 'Admin Login',
        },
        logout: {
            action: 'User Logout',
        },
        refreshtoken: {
            action: 'User Refresh Token',
        },
        forgotPassword: {
            action: 'Forgot Password',
        },
        resetPassword: {
            action: 'Reset Password',
        },
        verifyOTP: {
            action: 'Verify OTP',
        },
    },
    COMPANY: {
        add: {
            action: 'Add Company',
        },
        search: {
            action: 'Search Company',
        },
        list: {
            action: 'List Company',
        },
    },
    CLIENT: {
        list: {
            action: 'List Clients',
        },
        register: {
            action: 'Register Client',
        },
        update: {
            action: 'Update Client',
        },
        delete: {
            action: 'Delete Client',
        },
        details: {
            action: 'Client Details',
        },
        search: {
            action: 'Search Client',
        },
    },
    CAMPAIGN: {
        create: {
            action: 'Campaign Create',
        },
        delete: {
            action: 'Campaign Delete',
        },
        update: {
            action: 'Campaign Update',
        },
        list: {
            action: 'Campaign List',
        },
        listByCompany: {
            action: 'Campaign List by Company',
        },
        listByCampaignId: {
            action: 'Campaign List by Campaign Id',
        },
        listCampaignsOfCampaignOwnerAndCompany: {
            action: 'Campaign List of Campaign Owner and Company',
        },
        generateUniqueUrl: {
            action: 'Generate Unique URL',
        },
        downloadUniqueUrl: {
            action: 'Download Unique URL',
        },
    },
    FIELDS: {
        list: {
            action: 'Fields list',
        },
        add: {
            action: 'Fields create',
        },
    },
    INVITEES: {
        create: {
            action: 'Invitee Create',
        },
        data: {
            action: 'Invitee Data',
        },
        downloadInviteeByCampaignId: {
            action: 'DownLoad Invitees By Campaign Id',
        },
        deleteInvitees: {
            action: 'Delete Invitees',
        },
        deleteInviteesByInviteeId: {
            action: 'Delete Invitees By Invitee Id',
        },
    },
    OTP: {
        generate: {
            action: 'OTP Generate',
        },
        verify: {
            action: 'OTP Verify',
        },
    },
    wallet: {
        createDenomination: {
            action: 'Create Denomination',
        },
        deleteDenomination: {
            action: 'Delete Denomination',
        },
        updateDenomination: {
            action: 'Update Denomination',
        },
    },
    SURVEY: {
        create: {
            action: 'Survey Create',
        },
        validate: {
            action: 'Survey Validate',
        },
        report: {
            action: 'Survey Report',
        },
        download: {
            action: 'Survey Download',
        },
    },
    VOUCHERS: {
        create: {
            action: 'Voucher Create',
        },
        list: {
            action: 'Voucher List',
        },
        delete: {
            action: 'Voucher Delete',
        },
        download: {
            action: 'Voucher Download',
        },
        deleteVoucherById: {
            action: 'Voucher By Id',
        },
    },
    AUTH: {
        addRole: {
            action: 'Add Role',
        },
        addPermission: {
            action: 'Add Permission',
        },
        listPermission: {
            action: 'List Permission',
        },
        listRoles: {
            action: 'List Roles',
        },
        userRole: {
            action: 'Assign A Role To User',
        },
        rolePermission: {
            action: 'Assign A Permission To Role',
        },
    },
};
