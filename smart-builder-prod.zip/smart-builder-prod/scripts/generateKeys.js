const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { logger } = require('../utilities');

function generateKeyPairAndUpdateConfig() {
    logger.info('Creating Key Pairs');

    const configFilePath = path.join(__dirname, '../configs/constants.js');

    // Generate a key pair
    const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
        modulusLength: 2048,
    });

    // Store the keys in the config file
    const config = require(configFilePath);

    config.ENCRYPTION.privateKey = privateKey.export({ type: 'pkcs1', format: 'pem' });
    config.ENCRYPTION.publicKey = publicKey.export({ type: 'pkcs1', format: 'pem' });

    // Update the config file
    fs.writeFileSync(configFilePath, `module.exports = ${JSON.stringify(config, null, 2)};`);

    logger.info('Created Key Pairs, and saved it config file');
}

if (require.main === module) {
    generateKeyPairAndUpdateConfig();
}
