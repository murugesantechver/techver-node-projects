#!/bin/bash

echo "waiting 15 seconds for queue to initialize..."
sleep 15
echo "waiting completed..."