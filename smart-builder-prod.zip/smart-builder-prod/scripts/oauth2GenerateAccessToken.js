const axios = require('axios');

axios
    .post(
        'http://localhost:4000/auth/oauth/token',
        {
            username: 'pwsuser',
            grant_type: 'password',
            password: 'TYDTG44gsy',
        },
        {
            auth: {
                username: 'pws-client001',
                password: 'express-secret-yellow',
            },
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        }
    )
    .then(function (response) {
        console.log(response.data);
    })
    .catch(function (error) {
        console.log(error);
    });
