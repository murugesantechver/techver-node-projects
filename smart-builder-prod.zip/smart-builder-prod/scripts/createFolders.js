const fs = require('fs');
const path = require('path');
require('dotenv').config();
const { logger } = require('../utilities');

const parentFolder = 'uploads';
const childFolders = ['invitee', 'surveyReports', 'campaignurl', 'voucher'];

const parentPath = path.join(__dirname, `../${parentFolder}`);

// Create the parent folder if it doesn't exist
if (!fs.existsSync(parentPath)) {
    fs.mkdirSync(parentPath);
} else {
    logger.info('Dependent folder already exists');
}

// Iterate through child folders
for (const childFolder of childFolders) {
    const childPath = path.join(parentPath, childFolder);

    if (!fs.existsSync(childPath)) {
        fs.mkdirSync(childPath);
    } else {
        logger.info('Dependent child folders already exists');
    }
}
