const { decryptData } = require('../helpers/encryption');

module.exports = (req, res, next) => {
    if (req.params.id) {
        req.params.id = decryptData(req.params.id);
    }
    if (req.params.voucherId) {
        req.params.voucherId = decryptData(req.params.voucherId);
    }
    if (req.params.inviteeId) {
        req.params.inviteeId = decryptData(req.params.inviteeId);
    }
    if (req.params.clientId) {
        req.params.clientId = decryptData(req.params.clientId);
    }
    if (req.params.campaignId) {
        req.params.campaignId = decryptData(req.params.campaignId);
    }
    next();
};
