const multer = require('multer');
const { ErrorResponse } = require('../helpers/errorResponse');
const { HTTP_CODES } = require('../configs');
const campaignRepository = require('../modules/campaign/campaignManagement/campaign.repository');
const fs = require('fs');
// const { s3Utils } = require('../utilities');

const diskStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = 'uploads/';
        // Create the upload directory if it doesn't exist
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, 'uploads/'); // uploads folder where files will be saved
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname); // filename format with timestamp and original name
    },
});

const getUploadMiddleware = (storageType = 'disk', allowedFileTypes = ['jpg', 'png', 'jpeg']) => {
    const fileFilter = async (req, file, cb, mandatoryFields) => {
        const missingFields = mandatoryFields.filter((field) => field.requireFileUpload && !req.files[`${field.fieldName}File`]);
        if (missingFields.length > 0) {
            return cb(
                new ErrorResponse(
                    `Missing mandatory file upload for fields: ${missingFields.map((field) => field.fieldName).join(', ')}`,
                    HTTP_CODES.BAD_REQUEST
                )
            );
        }

        const fileType = file.mimetype.split('/')[1];
        if (allowedFileTypes.includes(fileType)) {
            cb(null, false);
        } else {
            cb(null, true);
            return cb(new ErrorResponse(`Only ${allowedFileTypes.join(', ')} files are allowed!`, HTTP_CODES.BAD_REQUEST));
        }
    };
    return async (req, res, next) => {
        const { id, isVoucherOnly } = req.params;
        // let checkType;
        // if (type === 'survey') {
        //     checkType = 'normal';
        // } else {
        //     checkType = 'reward';
        // }
        // console.log('Fields data', id, isVoucherOnly);
        const storage = storageType === 'disk' ? diskStorage : multer.memoryStorage();
        const mandatoryFields = await campaignRepository.findMandatoryFieldsById(id);
        let fields;
        if (isVoucherOnly) {
            fields = [];
        } else {
            fields = mandatoryFields
                .filter((field) => field.requireFileUpload)
                .map((field) => ({
                    name: `${field.fieldName}File`,
                    maxCount: 2,
                }));
        }
        // console.log('Fields are', fields);

        const fileUpload = multer({
            storage: storage,
            limits: {
                fileSize: 1024 * 1024 * 5, // 5MB file size limit
                files: 5, // maximum of 5 files allowed
            },
            fileFilter: (req, file, cb) => fileFilter(req, file, cb, mandatoryFields),
        });
        const uploadMiddleware = fileUpload.fields(fields);
        uploadMiddleware(req, res, (err) => {
            if (err) {
                return next(new ErrorResponse(err.message, HTTP_CODES.INTERNAL_SERVER_ERROR));
            } else {
                // for (const field of fields) {
                //     console.log('Field is', field);
                //     console.log('Req Files are', req.files);
                //     const file = req.files[field.name][0];
                //     console.log('File is', file);
                //     const path = `Campaign${id}/${file.originalname}`; // Set the path to the desired location
                //     s3Utils
                //         .uploadFile(file, path)
                //         .then((data) => {
                //             console.log(`File uploaded successfully. ${data.Location}`);
                //         })
                //         .catch((err) => {
                //             return next(new ErrorResponse(err.message, HTTP_CODES.INTERNAL_SERVER_ERROR));
                //         });
                // }
                return next();
            }
        });
    };
};

module.exports = getUploadMiddleware;
