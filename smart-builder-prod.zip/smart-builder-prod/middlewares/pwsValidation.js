const { pwsBadRequestException } = require('../helpers/errorResponse');

const options = {
    basic: {
        abortEarly: false,
        convert: true,
    },
    array: {
        abortEarly: false,
        convert: true,
    },
};

module.exports = (schema) => (req, res, next) => {
    try {
        Object.keys(schema).forEach((key) => {
            const { error, value } = schema[key].validate(req[key], options);
            if (error) {
                const message = error.details[0].message || 'Invalid inputs';
                throw new pwsBadRequestException(message);
            } else {
                req[key] = value;
            }
        });

        next();
    } catch (error) {
        error.type = 'pwsError';
        next(error);
    }
};
