const multer = require('multer');
const { ErrorResponse } = require('../helpers/errorResponse');
const { HTTP_CODES } = require('../configs');

const diskStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // uploads folder where files will be saved
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname); // filename format with timestamp and original name
    },
});

const getUploadMiddleware = (storageType = 'disk', allowedFileTypes = ['csv']) => {
    const storage = storageType === 'disk' ? diskStorage : multer.memoryStorage();

    const fileUpload = multer({
        storage: storage,
        limits: {
            fileSize: 1024 * 1024 * 5, // 5MB file size limit
            files: 5, // maximum of 5 files allowed
        },
        fileFilter: (req, file, cb) => {
            // Validate file type
            const fileType = file.mimetype.split('/')[1];
            if (allowedFileTypes.includes(fileType)) {
                cb(null, true);
            } else {
                cb(null, false);
                // If the file is not of the correct type, pass the error to the next function
                return cb(new ErrorResponse(`Only ${allowedFileTypes.join(', ')} files are allowed!`, HTTP_CODES.BAD_REQUEST));
            }
        },
    }).array('file');

    return (req, res, next) => {
        fileUpload(req, res, (err) => {
            if (err) {
                // Pass the error to the next function instead of throwing it
                return next(new ErrorResponse(err.message, HTTP_CODES.INTERNAL_SERVER_ERROR));
            } else {
                return next();
            }
        });
    };
};

module.exports = getUploadMiddleware;
