const cors = require('cors');
const { CONSTANTS } = require('../configs');

const whitelist = CONSTANTS.CORS.whitelistIP;

const corsOptions = {
    origin: function (origin, callback) {
        if (whitelist.includes(origin) || !origin) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    allowedHeaders: ['Origin', 'X-Requested-With', 'Content-Type', 'Accept', 'Authorization'],
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
};

const corsMiddleware = cors(corsOptions);

module.exports = corsMiddleware;
