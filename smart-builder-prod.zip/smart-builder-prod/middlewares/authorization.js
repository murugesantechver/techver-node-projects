const { UnauthorizedException } = require('../helpers/errorResponse');
const { MESSAGES, CONSTANTS } = require('../configs');
const { jwt } = require('../utilities');
const { checkPermission } = require('../helpers/authhelper');
const userRepository = require('../modules/user/user.repository');

module.exports = (permission) => async (req, res, next) => {
    try {
        if (!req.headers.authorization) throw new UnauthorizedException(MESSAGES.MIDDLEWARE.authorization.missingHeader);
        const token = req.headers.authorization.split(' ')[1];
        if (!token) throw new UnauthorizedException(MESSAGES.MIDDLEWARE.authorization.missingToken);
        let isTokenAvailable = await userRepository.checkTokenAvailable(token);
        if (!isTokenAvailable) throw new UnauthorizedException(MESSAGES.MIDDLEWARE.authorization.tokenUnavailable);

        const decoded = await jwt.verifyToken(token, CONSTANTS.JWT.tokenSource.accessToken);
        if (req.url === '/logout') {
            decoded.token = token;
        }

        const userRoles = await userRepository.findUserRoles(decoded.id);
        let isPermitted = false;

        // Iterate through user's roles and check for permission in each role
        for (const role of userRoles) {
            isPermitted = await checkPermission(role, permission);
            if (isPermitted) {
                req.user = decoded;
                next();
                return; // Exit the loop and middleware if permission is found in any role
            }
        }

        // If no role has the required permission, reject the request
        if (!isPermitted) {
            throw new UnauthorizedException(MESSAGES.MIDDLEWARE.authorization.permissionDenied);
        }
    } catch (error) {
        next(error);
    }
};
