const validationMiddleware = require('./validation');
const pwsValidationMiddleware = require('./pwsValidation');
const authMiddleware = require('./authorization');
const corsMiddleware = require('./cors');
const campaignValidationMiddleware = require('./campaignValidation');
const getUploadMiddleware = require('./fileUploader');
const decryptIds = require('./decryptIds');
const surveyFileUploader = require('./surveyFileUploader');
const apiCache = require('./caching');
const pwsWhitelist = require('./pwsWhitelist');

module.exports = {
    pwsWhitelist,
    validationMiddleware,
    pwsValidationMiddleware,
    authMiddleware,
    corsMiddleware,
    campaignValidationMiddleware,
    getUploadMiddleware,
    decryptIds,
    surveyFileUploader,
    apiCache,
};
