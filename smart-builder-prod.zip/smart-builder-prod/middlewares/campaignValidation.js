const moment = require('moment');
const { PreconditionException, BadRequestException } = require('../helpers/errorResponse');
const campaignRepository = require('../modules/campaign/campaignManagement/campaign.repository');
const { CAMPAIGN_VALIDATION } = require('../configs');
const Joi = require('joi');
const { Op } = require('sequelize');
const { encryptJsonValue, decryptJsonValue } = require('../helpers/encryption');
const { MESSAGES } = require('../configs');
const options = {
    basic: {
        abortEarly: false,
        convert: true,
    },
    array: {
        abortEarly: false,
        convert: true,
    },
};

function getSchemaKeys(fields) {
    const schemaKeys = {};
    for (const field of fields) {
        const validationRule = CAMPAIGN_VALIDATION[field.fieldName];
        if (validationRule) {
            let schema = validationRule;
            if (field.isMandatory) {
                schema = schema.required();
            } else {
                schema = schema.allow(null).optional();
            }
            schemaKeys[field.fieldName] = schema;
        }
    }
    return schemaKeys;
}

module.exports = () => async (req, res, next) => {
    const { id } = req.params;
    const { type } = req.query;
    const checks = [{ id: { [Op.eq]: id } }];
    const isCampaignActive = await campaignRepository.checkCampaignExists(checks);
    if (!isCampaignActive) return next(new BadRequestException(MESSAGES.CAMPAIGN.notFound));
    // Sample date strings
    const currentDate = moment(); // Current date and time
    const issuedDate = moment(`${isCampaignActive.issuedDate}`);
    const startDate = moment(`${isCampaignActive.startDate}`);
    const endDate = moment(`${isCampaignActive.endDate}`);
    // Check if currentDate is within the specified range
    if (!currentDate.isSameOrAfter(startDate)) return next(new BadRequestException(MESSAGES.CAMPAIGN.campaignNotStarted));
    if (!currentDate.isSameOrAfter(issuedDate)) return next(new BadRequestException(MESSAGES.CAMPAIGN.campaignNotLive));
    if (!currentDate.isSameOrBefore(endDate)) return next(new BadRequestException(MESSAGES.CAMPAIGN.campaignEnded));

    if (isCampaignActive) {
        if (!isCampaignActive.publish) return next(new BadRequestException(MESSAGES.CAMPAIGN.campaignNotPublished));
        if (!isCampaignActive.isActive) return next(new BadRequestException(MESSAGES.CAMPAIGN.campaignNotActive));
        if (isCampaignActive.status) {
            if (isCampaignActive.status === 'COMPLETED') return next(new BadRequestException(MESSAGES.CAMPAIGN.campaignEnded));
            if (isCampaignActive.status === 'UPCOMING') return next(new BadRequestException(MESSAGES.CAMPAIGN.campaignNotStarted));
        }
    }
    // For Backend Testing
    // req.body = encryptJsonValue(req.body);
    const mandatoryFields = await campaignRepository.findMandatoryFieldsById(id);
    const fields = mandatoryFields
        .filter((campaignUrl) => {
            if (campaignUrl.fieldName === 'uniqueUrl') {
                if (!req?.query?.uniqueId) {
                    return next(new PreconditionException(MESSAGES.SURVEY.uniqueIdValidation));
                }
            }
            return campaignUrl.fieldName !== 'uniqueUrl';
        })
        .filter((field) => {
            return (type === 'survey' && field.fieldType === 'NORMAL') || (type === 'payment' && field.fieldType === 'REWARD');
        })
        .map((field) => {
            const fieldName = field.fieldName;
            const requireFileUpload = field.requireFileUpload || false;
            const isMandatory = field.isMandatory;
            // Construct the object with the field name and the requireFileUpload attribute
            return {
                fieldName: fieldName,
                requireFileUpload: requireFileUpload,
                isMandatory: isMandatory,
            };
        });
    const schema = Joi.object().keys(getSchemaKeys(fields));
    const decryptedBody = decryptJsonValue(req.body);
    const { error } = schema.validate(decryptedBody, options);
    if (error) {
        // Schema validation failed
        const message = error.details[0].message || 'Invalid inputs';
        const response = error.details[0];
        return next(new PreconditionException(message, response));
    }

    // Schema validation passed, update request body with validated values
    next();
};
