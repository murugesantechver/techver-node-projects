const apicache = require('apicache');

exports.cache = apicache.middleware;
