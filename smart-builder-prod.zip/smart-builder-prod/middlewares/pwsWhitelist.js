const { MESSAGES, HTTP_CODES } = require('../configs');
const { pwsBadRequestException } = require('../helpers/errorResponse');

const allowedIPsEnv = process.env.ALLOWED_IPS || ''; // Read allowed IPs from environment variable
const allowedIPs = allowedIPsEnv.split(',').map((ip) => ip.trim());

function whitelistMiddleware(req, res, next) {
    // const clientIP = req.ip; // Get the IP address of the client making the request
    const clientIP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    try {
        if (allowedIPs.includes(clientIP)) {
            // If the client's IP is in the whitelist, allow the request to proceed
            next();
        } else {
            // If the client's IP is not in the whitelist, respond with a 403 Forbidden status
            throw new pwsBadRequestException(MESSAGES.PWS.ipNotWhitelisted);
        }
    } catch (error) {
        error.type = 'pwsError';
        error.statusCode = HTTP_CODES.UNAUTHORIZED;
        next(error);
    }
}

module.exports = whitelistMiddleware;
