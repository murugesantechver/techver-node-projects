const clientServices = require('./services');
const { MESSAGES, LOGGER_CONFIG } = require('../../configs');
const { logger } = require('../../utilities');
const { response } = require('../../helpers');
const commonServices = require('../common/services');

exports.registerClient = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CLIENT.register.action;
    try {
        logger.info('Client Register Controller Function Initiated');
        const responsePayload = await clientServices.createClient(req.body);
        logger.info('Client Register Controller Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CLIENT.clientCreated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Client Create ended with exception');
        next(error);
    }
};

exports.listClient = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CLIENT.list.action;
    const page = req.query.page || 1;
    const limit = parseInt(req.query.limit) || 10;
    const queryParams = {
        page,
        limit,
    };
    try {
        logger.info('Client List Controller Function Initiated');
        const responseData = await clientServices.listClient(queryParams);
        logger.info('Client List Controller Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responseData, MESSAGES.CLIENT.listSuccess);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Client data fetch ended with exception');
        next(error);
    }
};

exports.updateClient = async (req, res, next) => {
    const { id } = req.params;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CLIENT.update.action;
    try {
        logger.info('Client Update Controller Function Initiated');
        const user = await clientServices.updateClient(req.body, id);
        logger.info('Client Update Controller Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, user, MESSAGES.CLIENT.userUpdated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('User data update ended with exception');
        next(error);
    }
};

exports.deleteClient = async (req, res, next) => {
    const { id } = req.params;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CLIENT.delete.action;
    try {
        logger.info('Client Delete Controller Function Initiated');
        const user = await clientServices.deleteClient(id);
        logger.info('Client Delete Controller Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, user, MESSAGES.CLIENT.clientDeleted);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('User data update ended with exception');
        next(error);
    }
};

exports.searchClient = async (req, res, next) => {
    const { searchTerm } = req.query;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CLIENT.search.action;
    try {
        logger.info('Client Search Controller Function Initiated');
        if (searchTerm) {
            const searchedItem = await clientServices.searchClient(searchTerm);
            logger.info('Client Search Controller Function Ended');
            await commonServices.auditLogs(action, url, userId);
            return response.success(res, searchedItem, MESSAGES.CLIENT.searchFound);
        } else {
            logger.info('Client Search Controller Function Ended');
            await commonServices.auditLogs(action, url, userId);
            return response.badRequest(MESSAGES.CLIENT.notFound);
        }
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('User data update ended with exception');
        next(error);
    }
};

exports.listCompanies = async (req, res, next) => {
    const page = req.query.page || 1;
    const limit = parseInt(req.query.limit) || 30;
    const queryParams = {
        page,
        limit,
    };
    try {
        logger.info('Company List Controller Function Initiated');
        const responseData = await clientServices.listCompanies(queryParams);
        logger.info('Company List Controller Function Ended');
        return response.success(res, responseData, MESSAGES.CLIENT.listSuccess);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Company data fetch ended with exception');
        next(error);
    }
};

exports.getClientDetails = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CLIENT.details.action;
    const { id } = req.params;
    try {
        logger.info('Client Details Controller Function Initiated');
        const responseData = await clientServices.getClientDetails(id);
        logger.info('Client Details Controller Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responseData, MESSAGES.CLIENT.listSuccess);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Client details fetch ended with exception');
        next(error);
    }
};
