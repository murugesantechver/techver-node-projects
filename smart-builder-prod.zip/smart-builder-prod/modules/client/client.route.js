const express = require('express');
const router = express.Router();
const { validationMiddleware, authMiddleware, decryptIds } = require('../../middlewares');
const { registerClient, listClient, updateClient, deleteClient, searchClient, getClientDetails } = require('./client.controller');
const { registerClientValidator, listValidator, updateClientValidator } = require('../client/client.validation');

router.get('/', authMiddleware('SUPERADMIN'), validationMiddleware(listValidator), listClient);
router.post('/register', authMiddleware('SUPERADMIN'), validationMiddleware(registerClientValidator), registerClient);
router.patch('/:id', authMiddleware('SUPERADMIN'), decryptIds, validationMiddleware(updateClientValidator), updateClient);
router.delete('/:id', authMiddleware('SUPERADMIN'), decryptIds, deleteClient);
router.get('/:id/details', authMiddleware('BASIC'), decryptIds, getClientDetails);
router.get('/search', authMiddleware('SUPERADMIN'), searchClient);
module.exports = router;
