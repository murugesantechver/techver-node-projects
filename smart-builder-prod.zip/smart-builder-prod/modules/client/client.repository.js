const { User, Company, Subcompany, Userrole, Role, sequelize } = require('../../database/models');
const { Op, QueryTypes, col } = require('sequelize');
const { CONSTANTS } = require('../../configs');
const { admin } = CONSTANTS.USER.roles;

exports.createClient = async (client, roleData, t = null) => {
    const isCreated = await User.create(client, { transaction: t });
    roleData.userId = isCreated.id;
    await Userrole.create(roleData, { transaction: t });
    if (isCreated) {
        if (isCreated.dataValues) {
            const id = isCreated?.dataValues?.id;
            return this.findClientById(id);
        }
    }
    return {};
};

exports.findClientById = async (id) => {
    const user = await User.findOne({
        where: {
            id,
        },
        attributes: [
            'id',
            'email',
            'userName',
            'companyId',
            'subCompanyId',
            'status',
            'mobile',
            'country',
            'location',
            'contactPersonName',
        ],
    });

    if (user) {
        if (user.companyId) {
            const company = await Company.findOne({
                where: {
                    id: user.companyId,
                },
                attributes: ['companyName'],
            });
            if (company) {
                user.dataValues.companyName = company.companyName;
            }
        }
        if (user.subCompanyId) {
            const subCompany = await Subcompany.findOne({
                where: {
                    id: user.subCompanyId,
                },
                attributes: ['subCompanyName'],
            });
            if (subCompany) {
                user.dataValues.subCompanyName = subCompany.companyName;
            }
        }
    }
    return user;
};

exports.checkAnyClientDataAlreadyExists = async (checks) => {
    return await User.findOne({
        where: {
            [Op.or]: checks,
        },
    });
};

exports.findClientByEmail = async (email) => {
    return await User.findOne({
        where: {
            email: email,
        },
    });
};

exports.findClients = async (limit, page) => {
    const role = 'ADMIN';
    const userIdsQuery = `
        SELECT "userId" 
        FROM "Userrole" AS "roleName"
        INNER JOIN "Roles" AS "Role" ON "roleName"."roleId" = "Role"."id"
        WHERE "Role"."role" = :roleName
    `;

    const results = await sequelize.query(userIdsQuery, {
        replacements: { roleName: role },
        type: sequelize.QueryTypes.SELECT,
    });
    const userIds = results.map((result) => result.userId);
    return await User.findAndCountAll({
        where: { id: userIds },
        offset: (page - 1) * limit,
        limit,
        distinct: true,
        attributes: ['id', 'email', 'status', 'companyId'],
    });
};

exports.findCompanies = async (limit, page) => {
    const role = admin;
    const offset = (page - 1) * limit;

    const countQuery = `
    SELECT COUNT(DISTINCT "companyName") AS count
    FROM "Users"
    WHERE "role" = :role
  `;

    const dataQuery = `
    SELECT DISTINCT ON ("companyName") "id", "companyName"
    FROM "Users"
    WHERE "role" = :role
    ORDER BY "companyName", "id"
    OFFSET :offset
    LIMIT :limit
  `;

    const replacements = { role, offset, limit };

    const countResult = await User.sequelize.query(countQuery, {
        type: QueryTypes.SELECT,
        replacements,
    });

    const dataResult = await User.sequelize.query(dataQuery, {
        type: QueryTypes.SELECT,
        replacements,
    });

    return {
        count: countResult[0].count,
        rows: dataResult,
    };
};

exports.updateClient = async (id, data, t = null) => {
    const isUpdated = await User.update(data, { where: { id }, transaction: t, returning: true });
    if (isUpdated[0] === 1) {
        return await this.findClientById(id);
    }
    return {};
};

exports.deleteClient = async (id) => {
    return await User.destroy({
        where: {
            id,
        },
    });
};

exports.searchClients = async (searchTerm) => {
    const attributes = ['id', 'email', 'status'];

    return await User.findAll({
        where: {
            email: {
                [Op.iLike]: `%${searchTerm}%`,
            },
        },
        attributes,
    });
};
