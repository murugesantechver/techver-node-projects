const { MESSAGES } = require('../../../configs');
const { decryptData } = require('../../../helpers/encryption');
const { BadRequestException } = require('../../../helpers/errorResponse');
const clientRepository = require('../client.repository');

module.exports = async (data, id) => {
    const { companyId, subCompanyId } = data;
    const clientExists = await clientRepository.findClientById(id);
    if (companyId) {
        data.companyId = decryptData(companyId);
    }
    if (subCompanyId) {
        data.subCompanyId = decryptData(subCompanyId);
    }
    if (!clientExists) {
        throw new BadRequestException(MESSAGES.CLIENT.notFound);
    }

    const updateData = await clientRepository.updateClient(id, data);
    return updateData;
};
