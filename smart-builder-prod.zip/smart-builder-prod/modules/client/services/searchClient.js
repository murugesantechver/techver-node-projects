const clientRepository = require('../client.repository');

module.exports = async (search) => {
    const searchData = await clientRepository.searchClients(search);
    return searchData;
};
