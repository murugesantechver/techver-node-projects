const { CONSTANTS, MESSAGES } = require('../../../configs');
const clientRepository = require('../client.repository');
const userRepository = require('../../user/user.repository');
const companyRepository = require('../../company/company.repository');
const { admin } = CONSTANTS.USER.roles;
const { bcrypt, common, emailUtils } = require('../../../utilities');
const { decryptData, encryptData } = require('../../../helpers/encryption');
const { BadRequestException } = require('../../../helpers/errorResponse');

module.exports = async (data) => {
    const { email, companyId, subCompanyId } = data;
    const password = common.generatePassword();
    const encodedPassword = await bcrypt.generatePassword(password);
    if (!companyId) {
        throw new BadRequestException(MESSAGES.COMPANY.companyDetailsNotProvided);
    }
    if (companyId) {
        data.companyId = decryptData(companyId);
    }
    if (subCompanyId) {
        data.subCompanyId = decryptData(subCompanyId);
    }
    let companyDetails = await companyRepository.findCompanyById(decryptData(companyId));

    if (!companyDetails) {
        throw new BadRequestException(MESSAGES.COMPANY.companyNotFound);
    }
    const uniqueUsername = await common.generateUniqueUsernameAndCode(companyDetails.companyName, email);
    data.role = admin;
    data.password = encodedPassword;
    data.userName = uniqueUsername;
    // Initially Set Status to Inactive
    const roleData = {
        roleId: 2,
    };
    const client = await clientRepository.createClient(data, roleData);
    if (client) {
        const redirectLink = CONSTANTS.REDIRECTS.RESET_PASSWORD + encryptData(client.id);
        const emailSent = await emailUtils.sendUserRegistrationMail(email, uniqueUsername, redirectLink);
        if (emailSent) {
            const userData = {
                emailSent: true,
            };
            await userRepository.updateEmailSentStatus(client.id, userData);
        }
    }
    return {
        id: client.id,
        userName: client.userName,
        password: password,
        role: admin,
        status: client.status,
    };
};
