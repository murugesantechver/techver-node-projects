const createClient = require('./createClient');
const listClient = require('./listClient');
const updateClient = require('./updateClient');
const deleteClient = require('./deleteClient');
const searchClient = require('./searchClient');
const listCompanies = require('./listCompanies');
const getClientDetails = require('./getClientDetail');

module.exports = {
    createClient,
    listClient,
    updateClient,
    deleteClient,
    searchClient,
    listCompanies,
    getClientDetails,
};
