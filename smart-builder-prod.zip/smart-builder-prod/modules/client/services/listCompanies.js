const clientRepository = require('../client.repository');

module.exports = async ({ page, limit }) => {
    const clientData = await clientRepository.findCompanies(limit, page);
    return clientData;
};
