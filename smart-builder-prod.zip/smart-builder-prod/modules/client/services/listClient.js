const clientRepository = require('../client.repository');

module.exports = async ({ page, limit }) => {
    const clientData = await clientRepository.findClients(limit, page);
    return {
        count: clientData.count,
        clientData: clientData.rows,
    };
};
