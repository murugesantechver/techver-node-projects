const { MESSAGES, CONSTANTS } = require('../../../configs');
const { BadRequestException } = require('../../../helpers/errorResponse');
const clientRepository = require('../client.repository');

module.exports = async (id) => {
    const client = await clientRepository.findClientById(id);

    if (!client) {
        throw new BadRequestException(MESSAGES.CLIENT.notFound);
    }

    await clientRepository.deleteClient(id);

    return true;
};
