const clientRepository = require('../client.repository');

module.exports = async (id) => {
    const clientData = await clientRepository.findClientById(id);
    return clientData;
};
