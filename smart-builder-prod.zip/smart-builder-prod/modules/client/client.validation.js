const Joi = require('joi');
const { MESSAGES } = require('../../configs');

exports.registerClientValidator = {
    body: Joi.object().keys({
        email: Joi.string().allow(null).trim().lowercase().email().required(),
        contactPersonName: Joi.string()
            .allow(null)
            .trim()
            .required()
            .regex(/^[a-z ,.'-]+$/i)
            .messages({
                'string.pattern.base': MESSAGES.ADMIN.nameValidation,
            }),
        companyId: Joi.string().required(),
        subCompanyId: Joi.string().allow(null).optional(),
        mobile: Joi.string()
            .length(10) // The total length should be 10 digits
            .pattern(/^[0-9]{10}$/) // Matches a string consisting of exactly 10 digits
            .required(),
        country: Joi.string().allow(null).trim().optional(),
        location: Joi.string().allow(null).trim().optional(),
        status: Joi.string().valid('ACTIVE', 'INACTIVE').required(),
        role: Joi.string().allow(null).trim().valid('ADMIN').optional(),
    }),
};

exports.listValidator = {
    query: Joi.object().keys({
        page: Joi.number().optional(),
        limit: Joi.number().optional(),
    }),
};

exports.updateClientValidator = {
    body: Joi.object().keys({
        email: Joi.string().allow(null).trim().lowercase().email().optional(),
        contactPersonName: Joi.string()
            .allow(null)
            .trim()
            .optional()
            .regex(/^[a-z ,.'-]+$/i)
            .messages({
                'string.pattern.base': MESSAGES.ADMIN.nameValidation,
            }),
        mobile: Joi.string()
            .length(10) // The total length should be 10 digits
            .pattern(/^[0-9]{10}$/) // Matches a string consisting of exactly 10 digits
            .optional(),
        companyId: Joi.string().optional(),
        subCompanyId: Joi.string().allow(null).optional(),
        country: Joi.string().allow(null).trim().optional(),
        location: Joi.string().allow(null).trim().optional(),
        status: Joi.string().valid('ACTIVE', 'INACTIVE').optional(),
        role: Joi.string().allow(null).trim().valid('ADMIN').optional(),
    }),
};
