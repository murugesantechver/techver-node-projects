const Joi = require('joi');

exports.listValidator = {
    query: Joi.object().keys({
        code: Joi.string().required(),
    }),
};
