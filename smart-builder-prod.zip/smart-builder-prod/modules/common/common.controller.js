const { State, City, Country } = require('country-state-city');
const { MESSAGES } = require('../../configs');
const { logger } = require('../../utilities');
const { response } = require('../../helpers');

exports.listStates = async (req, res, next) => {
    try {
        logger.info('State List Controller Function Initiated');
        const statesList = State.getStatesOfCountry('IN');
        const simplifiedList = statesList.map((state) => ({
            name: state.name,
            isoCode: state.isoCode,
        }));
        logger.info('State List Controller Function Ended');
        return response.success(res, simplifiedList, MESSAGES.COMMON.statesListFetched);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('State List ended with exception');
        next(error);
    }
};

exports.listCities = async (req, res, next) => {
    const { code } = req.query;
    try {
        logger.info('City List Controller Function Initiated');
        const citiesList = City.getCitiesOfState('IN', code);
        const simplifiedList = citiesList.map((city) => city.name);
        logger.info('City List Controller Function Ended');
        return response.success(res, simplifiedList, MESSAGES.COMMON.citiesListFetched);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('City list data fetch ended with exception');
        next(error);
    }
};

exports.getCodeForState = async (req, res, next) => {
    const { name } = req.query;
    function toTitleCase(str) {
        return str.replace(/\b\w/g, (match) => match.toUpperCase());
    }

    const formattedString = toTitleCase(name);
    try {
        logger.info('State Code Controller Function Initiated');
        const statesList = State.getStatesOfCountry('IN');
        // console.log('States list', statesList);
        const state = statesList.find((state) => state.name === formattedString);
        var isoCode;
        if (state) {
            isoCode = state.isoCode;
        }

        logger.info('State Code Controller Function Ended');
        return response.success(res, isoCode, MESSAGES.COMMON.stateCodeFetched);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('State Code data fetch ended with exception');
        next(error);
    }
};

exports.listCountries = async (req, res, next) => {
    try {
        logger.info('Country List Controller Function Initiated');
        const countriesList = Country.getAllCountries();
        const simplifiedList = countriesList.map((country) => ({
            name: country.name,
            isoCode: country.isoCode,
        }));
        logger.info('Country List Controller Function Ended');
        return response.success(res, simplifiedList, MESSAGES.COMMON.countryListFetched);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Country List ended with exception');
        next(error);
    }
};

exports.getCodeForCountry = async (req, res, next) => {
    const { name } = req.query;
    function toTitleCase(str) {
        return str.replace(/\b\w/g, (match) => match.toUpperCase());
    }

    const formattedString = toTitleCase(name);
    try {
        logger.info('Country Code Controller Function Initiated');
        const countryList = Country.getAllCountries();
        // console.log('States list', statesList);
        const country = countryList.find((country) => country.name === formattedString);
        var isoCode;
        if (country) {
            isoCode = country.isoCode;
        }

        logger.info('Country Code Controller Function Ended');
        return response.success(res, isoCode, MESSAGES.COMMON.countryCodeFetched);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Country Code data fetch ended with exception');
        next(error);
    }
};
