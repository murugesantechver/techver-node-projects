const { Auditlogs } = require('../../database/models');

exports.auditLogs = async (auditDetails, t = null) => {
    return await Auditlogs.create(auditDetails, { transaction: t });
};
