const express = require('express');
const router = express.Router();
const { validationMiddleware, apiCache, authMiddleware } = require('../../middlewares');
const { listStates, listCities, getCodeForState, listCountries, getCodeForCountry } = require('./common.controller');
const { listValidator } = require('./common.validator');

router.get('/state', authMiddleware('BASIC'), apiCache.cache('30 minutes'), listStates);
router.get('/countries', authMiddleware('BASIC'), apiCache.cache('30 minutes'), listCountries);
router.get('/cities', authMiddleware('BASIC'), apiCache.cache('30 minutes'), validationMiddleware(listValidator), listCities);
router.get('/state/isocode', authMiddleware('BASIC'), apiCache.cache('30 minutes'), getCodeForState);
router.get('/country/isocode', authMiddleware('BASIC'), apiCache.cache('30 minutes'), getCodeForCountry);

module.exports = router;
