
const auditLogs = require('./auditLogs');

module.exports = {
    auditLogs,
};
