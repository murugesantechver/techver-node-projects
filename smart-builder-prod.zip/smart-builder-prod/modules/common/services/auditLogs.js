const commonRepository = require('../common.repository');
const { logger } = require('../../../utilities');

module.exports = async (action, url, userId) => {
    const auditDetails = {
        action: action,
        url: url,
        userId: userId,
        currentTime: new Date(),
    };
    try {
        await commonRepository.auditLogs(auditDetails);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Audit Logs Updation Ended with Exception');
        return;
    }
    return;
};
