const { response } = require('../../helpers');
const { MESSAGES } = require('../../configs');
const { logger } = require('../../utilities');
const { updatePaymentStatus } = require('./services');

exports.listenNotificationForPayment = async (req, res, next) => {
    try {
        logger.info('Recieve notification Controller Initiated');
        let responsePayload;
        responsePayload = await updatePaymentStatus(req.body);
        return response.notify(res, responsePayload, MESSAGES.COMPANY.companyAdded);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Recieve Notification Failed');
        next('Could not process your request, Please try again later');
    }
};
