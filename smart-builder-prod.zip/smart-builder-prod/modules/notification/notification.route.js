const express = require('express');
const router = express.Router();
const { listenNotificationForPayment } = require('./notification.controller');
const { validationMiddleware } = require('../../middlewares');
const { surveyPaymentStatusValidator } = require('./notification.validation');

router.post('/', listenNotificationForPayment);

module.exports = router;
