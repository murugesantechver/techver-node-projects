const updatePaymentStatus = require('./updatePaymentStatus');

module.exports = {
    updatePaymentStatus,
};
