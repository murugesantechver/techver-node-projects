const surveyRepository = require('../../campaign/survey/survey.repository');
const { logger } = require('../../../utilities');
const { notificationLogger } = require('../../../utilities');
const { Op } = require('sequelize');
const { ErrorResponse } = require('../../../helpers/errorResponse');
const { encryptJsonValue } = require('../../../helpers/encryption');

module.exports = async (data) => {
    logger.info('update-paymentStatus-service function initiated');
    const { orderId, status } = data;
    notificationLogger.info(`Notification Request: orderId: ${orderId}, status: ${status}`);
    let checks;
    checks = [{ orderId: { [Op.eq]: String(orderId) } }];
    const orderExists = await surveyRepository.checkIfOrderExists(checks);
    if (!orderExists) {
        notificationLogger.info(`Notification Response: orderId: ${orderId}, Response: NOT ACKNOWLEDGED, Order does not exists`);
        throw new ErrorResponse('OrderId is not associated with the system.');
    }
    const orderData = {
        paymentStatus: status,
    };
    var encryptedData = encryptJsonValue(orderData);
    await surveyRepository.updateOrder(orderId, encryptedData);
    const acceptedMessage = 'ACCEPTED';
    notificationLogger.info(`Notification Response: orderId: ${orderId}, Response: ACCEPTED`);
    if (status == "COMPLETED") {
        return acceptedMessage;
    } else {
        throw new ErrorResponse('Could not process your request, Please try again later/Waiting for Order to get completed');
    }
};
