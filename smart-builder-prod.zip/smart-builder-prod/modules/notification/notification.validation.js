const Joi = require('joi');
const { CONSTANTS } = require('../../configs');

exports.surveyPaymentStatusValidator = {
    body: Joi.object().keys({
        status: Joi.string()
            .valid(...CONSTANTS.ENUMS.orderStatus)
            .required(),
        orderId: Joi.number().required(),
        refno: Joi.string()
            .regex(/^[A-Z]{2}-\d{12}$/)
            .required(),
        orderStatus: Joi.string()
            .valid(...CONSTANTS.ENUMS.orderStatus)
            .required(),
        cancel: Joi.object()
            .keys({
                allowed: Joi.boolean().required(),
                allowedWithIn: Joi.string().required(),
            })
            .required(),
        customer: Joi.object()
            .keys({
                id: Joi.string().required(),
            })
            .required(),
    }),
};
