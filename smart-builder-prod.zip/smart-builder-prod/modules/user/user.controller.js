const userServices = require('./services');
const { response } = require('../../helpers');
const { MESSAGES, LOGGER_CONFIG } = require('../../configs');
const { logger } = require('../../utilities');
const { UnauthorizedException } = require('../../helpers/errorResponse');
const commonServices = require('../common/services');

exports.registerAdmin = async (req, res, next) => {
    const action = LOGGER_CONFIG.USER.register.action;
    const url = req.baseUrl + req.url;

    try {
        logger.info('Admin Register Controller Function Initiated');
        const responsePayload = await userServices.createAdmin(req.body);
        await commonServices.auditLogs(action, url, responsePayload.id);
        return response.success(res, responsePayload, MESSAGES.ADMIN.userCreated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Admin Register ended with exception');
        next(error);
    }
};

exports.loginUser = async (req, res, next) => {
    const { userName, password } = req.body;
    const action = LOGGER_CONFIG.USER.login.action;
    const url = req.baseUrl + req.url;
    try {
        logger.info('User Login Controller Function Initiated');
        const responsePayload = await userServices.loginUser(userName, password);
        await commonServices.auditLogs(action, url, responsePayload.id);
        return response.success(res, responsePayload, MESSAGES.USER.login);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('User Login ended with exception');
        next(error);
    }
};

exports.logoutUser = async (req, res, next) => {
    const { id: userId, token } = req.user;
    const action = LOGGER_CONFIG.USER.logout.action;
    const url = req.baseUrl + req.url;

    try {
        logger.info('User Logout Controller Function Initiated');
        const responsePayload = await userServices.logoutUser(userId, token);
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.USER.logout);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('User Logout ended with exception');
        next(error);
    }
};

exports.userRefreshToken = async (req, res, next) => {
    const { id: userId } = req.user;
    const action = LOGGER_CONFIG.USER.logout.action;
    const url = req.baseUrl + req.url;
    try {
        logger.info('Refresh Token Controller Function Initiated');
        if (!req.headers.authorization) throw new UnauthorizedException(MESSAGES.MIDDLEWARE.authorization.missingHeader);
        const { authorization } = req.headers;
        const responsePayload = await userServices.userRefreshToken(authorization);
        logger.info('Refresh Token Controller Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.ADMIN.refreshTokenGenerated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('RefreshToken-controller ended with exception');
        next(error);
    }
};

exports.forgotPassword = async (req, res, next) => {
    const { id: userId } = req.user;
    const action = LOGGER_CONFIG.USER.forgotPassword.action;
    const url = req.baseUrl + req.url;

    try {
        logger.info('Forgot Password Controller Function Initiated');
        const data = req.body;
        const responsePayload = await userServices.forgotPassword(data);
        await commonServices.auditLogs(action, url, userId);
        logger.info('Forgot Password Function ended');
        return response.success(res, responsePayload, MESSAGES.ADMIN.passwordUpdated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Forgot Password controller ended with exception');
        next(error);
    }
};

exports.resetPassword = async (req, res, next) => {
    const { id: userId } = req.params;
    const action = LOGGER_CONFIG.USER.resetPassword.action;
    const url = req.baseUrl + req.url;
    try {
        const data = req.body;
        logger.info('Reset Password Controller Function Initiated');
        const responsePayload = await userServices.resetPassword(data, userId);
        await commonServices.auditLogs(action, url, userId);
        logger.info('Reset Password Function Ended');
        return response.success(res, responsePayload, MESSAGES.ADMIN.passwordUpdated);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('Reset Password Controller Ended with Exception');
        next(error);
    }
};

exports.verifyOtp = async (req, res, next) => {
    const action = LOGGER_CONFIG.USER.verifyOTP.action;
    const url = LOGGER_CONFIG.USER.verifyOTP.url;
    try {
        const data = req.body;
        logger.info('Verify OTP Controller Function Initiated');
        const responsePayload = await userServices.verifyOTP(data);
        await commonServices.auditLogs(action, url, data.username);
        logger.info('Verify OTP Function Ended');
        return response.success(res, responsePayload, MESSAGES.USER.otpVerificationSuccessfull);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('Verify OTP Controller Ended with Exception');
        next(error);
    }
};
