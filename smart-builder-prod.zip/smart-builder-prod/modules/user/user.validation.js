const Joi = require('joi');
const { MESSAGES } = require('../../configs');

exports.registerAdminValidator = {
    body: Joi.object().keys({
        firstName: Joi.string()
            .allow(null)
            .trim()
            .required()
            .regex(/^[a-z ,.'-]+$/i)
            .messages({
                'string.pattern.base': MESSAGES.ADMIN.nameValidation,
            }),
        lastName: Joi.string()
            .allow(null)
            .trim()
            .required()
            .regex(/^[a-z ,.'-]+$/i)
            .messages({
                'string.pattern.base': MESSAGES.ADMIN.nameValidation,
            }),
        userName: Joi.string()
            .allow(null)
            .trim()
            .regex(/^(?=[a-zA-Z])[\w-]{3,20}$/)
            .required()
            .prefs({ convert: true })
            .label('userName')
            .messages({
                'string.pattern.base': MESSAGES.USER.userNameValidate,
            }),
        email: Joi.string().allow(null).trim().lowercase().email().required(),
        password: Joi.string()
            .trim()
            .regex(/^(?!.*\s)(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
            .required(),
        role: Joi.string().allow(null).trim().valid('SUPERADMIN').optional(),
    }),
};

exports.forgotPasswordValidator = {
    body: Joi.object().keys({
        userName: Joi.string()
            .allow(null)
            .trim()
            .regex(/^(?=[a-zA-Z])[\w-]{3,20}$/)
            .label('userName')
            .prefs({ convert: true })
            .messages({
                'string.pattern.base': MESSAGES.USER.userNameValidate,
            }),
        password: Joi.string()
            .trim()
            .regex(/^(?!.*\s)(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
            .required(),
        confirmPassword: Joi.string()
            .trim()
            .regex(/^(?!.*\s)(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
            .required(),
    }),
};

exports.resetPasswordValidator = {
    body: Joi.object().keys({
        password: Joi.string()
            .trim()
            .regex(/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).*$/)
            .required(),
        confirmPassword: Joi.string()
            .trim()
            .regex(/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).*$/)
            .required(),
    }),
};

exports.userLoginValidator = {
    body: Joi.object().keys({
        userName: Joi.string()
            .allow(null)
            .trim()
            .regex(/^(?=[a-zA-Z])[\w-]{3,30}$/)
            .label('userName')
            .prefs({ convert: true })
            .messages({
                'string.pattern.base': MESSAGES.USER.userNameValidate,
            }),
        password: Joi.string()
            .trim()
            .regex(/^(?!.*\s)(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
            .required(),
    }),
};

exports.verifyOTPValidator = {
    body: Joi.object().keys({
        userName: Joi.string()
            .allow(null)
            .trim()
            .regex(/^(?=[a-zA-Z])[\w-]{3,20}$/)
            .label('userName')
            .prefs({ convert: true })
            .messages({
                'string.pattern.base': MESSAGES.USER.userNameValidate,
            }),
        otp: Joi.string()
            .length(4)
            .pattern(/^[0-9]+$/)
            .required(),
    }),
};
