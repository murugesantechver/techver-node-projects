const request = require('supertest');
const app = require('../../../app');
const { superAdmin } = require('../../../test/env.json');
const { readJsonFile, saveTokensToFile } = require('../../../test/jsonUtils');
require('dotenv').config();

exports.superAdminLogin = () => {
    it('Superadmin Admin Logged Successfully', async () => {
        const response = await request(app).post('/user/login').send({
            userName: 'jaleSully',
            password: 'passWORD@123',
        });

        // Load existing JSON data
        const existingData = readJsonFile('test/env.json');

        // Add or update your token information in the JSON data
        const newToken = response.body.data.accessToken; // Replace with your actual token
        existingData.superAdmin.superAdminAccessToken = newToken;
        saveTokensToFile('test/env.json', existingData);
        expect(response.statusCode).toBe(200);
    });

    it('checks 412 precondtions, Username not be empty', function (done) {
        request(app)
            .post('/user/login')
            .send({ userName: '', password: 'dsds' })
            .set('Accept', 'application/json')
            .expect('Content-Type', /json/)
            .expect(412, {
                error: {
                    code: 412,
                    type: 'Precondition Failed',
                    message: '"userName" is not allowed to be empty',
                    data: {
                        message: '"userName" is not allowed to be empty',
                        path: ['userName'],
                        type: 'string.empty',
                        context: {
                            label: 'userName',
                            value: '',
                            key: 'userName',
                        },
                    },
                },
            })
            .end(done);
    });

    it('checks 412 precondtions, Password required', function (done) {
        request(app)
            .post('/user/login')
            .send({ username: 'jaleSully' })
            .set('Accept', 'application/json')
            .expect('Content-Type', /json/)
            .expect(412, {
                error: {
                    code: 412,
                    type: 'Precondition Failed',
                    message: '"password" is required',
                    data: {
                        message: '"password" is required',
                        path: ['password'],
                        type: 'any.required',
                        context: {
                            label: 'password',
                            key: 'password',
                        },
                    },
                },
            })
            .end(done);
    });

    it('Admin Wrong Credentials', function (done) {
        request(app)
            .post('/user/login')
            .send({
                userName: 'wrong',
                password: 'Test@123',
            })
            .set('Accept', 'application/json')
            .expect('Content-Type', /json/)
            .expect(401, {
                error: {
                    code: 401,
                    type: 'Unauthorized',
                    message: 'Invalid username or password',
                    data: {},
                },
            })
            .end(done);
    });
};
