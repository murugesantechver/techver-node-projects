const request = require('supertest');
const app = require('../../../app');
const { CONSTANTS } = require('../../../configs');
require('dotenv').config();

exports.clientCreate = (adminToken) => {
    if (!adminToken) {
        throw new Error('You Must login first and get the access token');
    }
    it('Client Created Successfully', async () => {
        const response = await request(app)
            .post('/user/admin/register')
            .set('Authorization', `Bearer ${adminToken}`)
            .send({
                firstName: 'Jay',
                lastName: 'Manto',
                userName: 'jaymant',
                email: 'jaymant@yopmail.com',
                password: 'passWORD@123',
            })
            .expect('Content-Type', /json/);

        expect(response.statusCode).toBe(200);
    });
};
