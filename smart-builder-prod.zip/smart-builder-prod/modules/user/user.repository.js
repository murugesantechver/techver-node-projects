const { User, Userrole, Roles, Rolepermission, Permissions, Usertoken } = require('../../database/models');
const { Op } = require('sequelize');

exports.createAdmin = async (user, roleData, t = null) => {
    const userData = await User.create(user, { transaction: t });
    roleData.userId = userData.id;
    await Userrole.create(roleData, { transaction: t });
    return userData;
};

exports.findUserById = async (id) => {
    return await User.findOne({
        where: {
            id,
        },
    });
};

exports.getUserCompanyDetails = async (id) => {
    return await User.findOne({
        where: {
            id,
        },
        attributes: ['companyId', 'subCompanyId'],
    });
};

exports.checkUserAlreadyExists = async (checks) => {
    return await User.findOne({
        where: {
            [Op.or]: checks,
        },
    });
};

exports.findUserByUsername = async (userName) => {
    return await User.findOne({
        where: {
            userName: userName,
        },
    });
};

exports.findUserByIdOrUsername = async (checks) => {
    return await User.findOne({
        where: {
            [Op.or]: checks,
        },
    });
};

exports.findUserByEmail = async (email) => {
    return await User.findOne({
        where: {
            email: email,
        },
    });
};

exports.updateUserDetails = async (params, id, t = null) => {
    return await User.update(params, { where: { id }, transaction: t });
};

exports.findUserPermissions = async (userId) => {
    // Find the roles associated with the user
    const userRoles = await Userrole.findAll({
        where: { userId: userId },
        include: [{ model: Roles, include: [Rolepermission] }],
    });

    // Extract permissions from the roles
    const permissions = userRoles.flatMap((userRole) => userRole.Role.RolePermissions.map((rolePermission) => rolePermission.permissionId));

    // Fetch the actual permission names
    const permissionNames = await Permissions.findAll({
        where: { id: permissions },
        attributes: ['name'],
    });

    // Extract the permission names into an array
    const permissionNamesArray = permissionNames.map((permission) => permission.name);

    return permissionNamesArray;
};

exports.findUserRoles = async (userId) => {
    // Find the roles associated with the user
    const userRoles = await Userrole.findAll({
        where: { userId: userId },
    });

    // Extract the role IDs from the userRoles
    const roleIds = userRoles.map((userRole) => userRole.roleId);

    // Fetch the role names from the Roles table
    const roles = await Roles.findAll({
        where: { id: roleIds },
        attributes: ['role'],
    });

    // Extract the role names into an array
    const rolesArray = roles.map((user) => user.role);

    return rolesArray;
};

exports.createUsertoken = async (accesstoken, t = null) => {
    return await Usertoken.create(accesstoken, { transaction: t });
};

exports.checkTokenAvailable = async (token) => {
    return await Usertoken.findOne({
        where: {
            Token: token,
        },
    });
};

exports.findTokenIdUsingToken = async (token) => {
    return await Usertoken.findOne({
        where: {
            Token: token,
        },
    });
};

exports.deleteTokenFromUsertoken = async (id) => {
    return await Usertoken.destroy({
        where: {
            id: id,
        },
    });
};

exports.findUsersByEmailSentStatus = async (emailSent) => {
    return await User.findAll({
        where: {
            emailSent: emailSent,
        },
    });
};

exports.updateEmailSentStatus = async (userId, userData, t = null) => {
    const user = await User.update(userData, { where: { id: userId }, transaction: t });
    return user;
};
