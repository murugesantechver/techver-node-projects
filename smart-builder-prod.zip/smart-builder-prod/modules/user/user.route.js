const express = require('express');
const router = express.Router();
const { validationMiddleware, authMiddleware, decryptIds } = require('../../middlewares');
const { registerAdmin, loginUser, userRefreshToken, forgotPassword, logoutUser, resetPassword, verifyOtp } = require('./user.controller');
const {
    registerAdminValidator,
    userLoginValidator,
    forgotPasswordValidator,
    resetPasswordValidator,
    verifyOTPValidator,
} = require('./user.validation');

router.post('/register', authMiddleware('SUPERADMIN'), validationMiddleware(registerAdminValidator), registerAdmin);
router.post('/login', validationMiddleware(userLoginValidator), loginUser);
router.post('/logout', authMiddleware('BASIC'), logoutUser);
router.get('/refreshToken', authMiddleware('BASIC'), userRefreshToken);
router.post('/forgotPassword', authMiddleware('BASIC'), validationMiddleware(forgotPasswordValidator), forgotPassword);
router.post('/resetPassword/:id', decryptIds, validationMiddleware(resetPasswordValidator), resetPassword);
router.post('/verifyotp', validationMiddleware(verifyOTPValidator), verifyOtp);

module.exports = router;
