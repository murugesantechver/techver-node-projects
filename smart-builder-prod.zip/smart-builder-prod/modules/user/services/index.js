const createAdmin = require('./createAdmin');
const loginUser = require('./loginUser');
const userRefreshToken = require('./userRefreshToken');
const forgotPassword = require('./forgotPassword');
const userOldPasswordCheck = require('./userOldPasswordCheck');
const logoutUser = require('./logoutUser');
const resetPassword = require('./resetPassword');
const oldPasswordCheck = require('./oldPasswordCheck');
const verifyOTP = require('./verifyOTP');
module.exports = {
    createAdmin,
    loginUser,
    userRefreshToken,
    forgotPassword,
    userOldPasswordCheck,
    logoutUser,
    resetPassword,
    oldPasswordCheck,
    verifyOTP,
};
