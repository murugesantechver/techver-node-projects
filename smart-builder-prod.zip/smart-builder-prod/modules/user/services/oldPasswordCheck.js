const { MESSAGES } = require('../../../configs');
const userRepository = require('../user.repository');
const { NotFoundException } = require('../../../helpers/errorResponse');
const { bcrypt } = require('../../../utilities');

module.exports = async (userId, password) => {
    const user = await userRepository.findUserById(userId);
    if (!user) throw new NotFoundException(MESSAGES.ADMIN.invalidCredentials);

    const validPassword = (await bcrypt.verifyPassword(user.password)) === password;
    if (!validPassword) {
        return {
            valid: false,
        };
    } else {
        return {
            valid: true,
        };
    }
};
