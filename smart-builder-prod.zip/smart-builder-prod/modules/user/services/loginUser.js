const { MESSAGES, CONSTANTS } = require('../../../configs');
const userRepository = require('../user.repository');
const companyRepository = require('../../company/company.repository');
const { UnauthorizedException } = require('../../../helpers/errorResponse');
const { jwt, bcrypt, logger, otp, emailUtils } = require('../../../utilities');
const { permissions } = CONSTANTS.USER;
const { Op } = require('sequelize');

const MAX_WRONG_ATTEMPTS = 3; // Define the maximum number of wrong attempts

module.exports = async (userName, password) => {
    logger.info('User-login-service function initiated');
    const checks = [{ userName: { [Op.eq]: userName } }];
    const user = await userRepository.checkUserAlreadyExists(checks);
    if (!user) throw new UnauthorizedException(MESSAGES.ADMIN.invalidCredentials);
    if (user) {
        if (user.status === 'DISABLED') throw new UnauthorizedException(MESSAGES.ADMIN.userDisabled);
    }
    // Check if the user has exceeded the wrong password attempts threshold
    if (user.wrongPasswordAttempts >= MAX_WRONG_ATTEMPTS) {
        const OTP = await otp.generate();
        await emailUtils.sendOTPViaMail(user.email, OTP);
        const update = {
            verifyOtp: OTP,
        };
        await userRepository.updateUserDetails(update, user.id);
        throw new UnauthorizedException(MESSAGES.USER.OTPVerificationRequired);
    }
    const validPassword = await bcrypt.verifyPassword(password, user.password);
    if (!validPassword) {
        const update = {
            wrongPasswordAttempts: user.wrongPasswordAttempts + 1,
        };
        await userRepository.updateUserDetails(update, user.id);
        throw new UnauthorizedException(MESSAGES.ADMIN.invalidCredentials);
    }
    if (user.wrongPasswordAttempts > 0) {
        const update = {
            wrongPasswordAttempts: 0,
        };
        await userRepository.updateUserDetails(update, user.id);
    }
    const userRoles = await userRepository.findUserRoles(user.id);
    const tokenPayload = {
        id: user.id,
        role: userRoles,
    };

    const accessToken = jwt.generateAccessToken(tokenPayload);
    const refreshToken = jwt.generateRefreshToken(tokenPayload);
    await userRepository.createUsertoken({ Token: accessToken });

    let userPermissions;
    if (userRoles) {
        if (userRoles.includes('ADMIN') && userRoles.includes('SUPERADMIN')) {
            userPermissions = permissions['SUPERADMIN'];
        }
        if (userRoles.includes('ADMIN')) {
            userPermissions = permissions['ADMIN'];
        }
        if (userRoles.includes('SUPERADMIN')) {
            userPermissions = permissions['SUPERADMIN'];
        }
    }
    const responsePayload = {
        ...tokenPayload,
        email: user.email,
        userName: user.userName,
        accessToken,
        refreshToken,
        userPermissions,
    };
    if (tokenPayload.role.includes('ADMIN')) {
        const { companyId, subCompanyId } = await userRepository.getUserCompanyDetails(tokenPayload.id);
        if (companyId) {
            const { companyName } = await companyRepository.findCompanyById(companyId);
            responsePayload.companyName = companyName;
            responsePayload.companyId = companyId;
        }
        if (subCompanyId) {
            responsePayload.subCompanyId = subCompanyId;
            const subCompanyData = await companyRepository.findSubCompanyNameBySubCompanyId(subCompanyId);
            if (subCompanyData != null) responsePayload.subCompanyName = subCompanyData.subCompanyName;
            else responsePayload.subCompanyName = 'No Affilate';
        }
    }
    logger.info('User-login-service function ended');

    return responsePayload;
};
