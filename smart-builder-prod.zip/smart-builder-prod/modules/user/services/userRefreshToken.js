const { MESSAGES, CONSTANTS } = require('../../../configs');
const { UnauthorizedException, NotFoundException } = require('../../../helpers/errorResponse');
const userRepository = require('../user.repository');
const { jwt } = require('../../../utilities');

module.exports = async (token) => {
    token = token.split(' ')[1];

    if (!token) throw new UnauthorizedException(MESSAGES.MIDDLEWARE.authorization.missingToken);

    const decoded = await jwt.verifyToken(token, CONSTANTS.JWT.tokenSource.refreshToken);

    const existingAdmin = await userRepository.findUserById(decoded.id);

    if (!existingAdmin) throw new NotFoundException(MESSAGES.ADMIN.notFound);

    if (existingAdmin.status === 'DISABLED') throw new UnauthorizedException(MESSAGES.ADMIN.userDisabled);

    const tokenPayload = {
        id: existingAdmin.id,
        role: existingAdmin.role,
    };

    const accessToken = jwt.generateAccessToken(tokenPayload);
    const refreshToken = jwt.generateRefreshToken(tokenPayload);

    const responsePayload = {
        accessToken,
        refreshToken,
    };

    return responsePayload;
};
