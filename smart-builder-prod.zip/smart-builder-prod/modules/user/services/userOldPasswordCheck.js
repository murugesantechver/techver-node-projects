const { MESSAGES } = require('../../../configs');
const userRepository = require('../user.repository');
const { NotFoundException } = require('../../../helpers/errorResponse');
const { bcrypt } = require('../../../utilities');

module.exports = async (userName, password) => {
    const admin = await userRepository.findUserByUsername(userName);
    if (!admin) throw new NotFoundException(MESSAGES.ADMIN.invalidCredentials);

    const validPassword = await bcrypt.verifyPassword(password, admin.password);

    if (!validPassword) {
        return {
            valid: false,
        };
    } else {
        return {
            valid: true,
        };
    }
};
