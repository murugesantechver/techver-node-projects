const { MESSAGES } = require('../../../configs');
const userRepository = require('../user.repository');
const { UnauthorizedException } = require('../../../helpers/errorResponse');
const { logger } = require('../../../utilities');
const { Op } = require('sequelize');

module.exports = async (userId, token) => {
    logger.info('User-logout-service function initiated');
    const checks = [{ id: { [Op.eq]: userId } }];
    const user = await userRepository.checkUserAlreadyExists(checks);
    if (!user) throw new UnauthorizedException(MESSAGES.USER.userNotAvailable);
    // Invalidate Token Here
    const { id } = await userRepository.findTokenIdUsingToken(token);
    await userRepository.deleteTokenFromUsertoken(id);

    logger.info('User-logout-service function ended');
    return true;
};
