const { MESSAGES, CONSTANTS } = require('../../../configs');
const { BadRequestException } = require('../../../helpers/errorResponse');
const userRepository = require('../user.repository');
const { bcrypt } = require('../../../utilities');
const { Op } = require('sequelize');
const { superAdmin } = CONSTANTS.USER.roles;

module.exports = async (data) => {
    const { userName, email, password } = data;
    const checks = [{ userName: { [Op.eq]: userName } }, { email: { [Op.eq]: email } }];
    let isAlreadyExists = await userRepository.checkUserAlreadyExists(checks);
    if (isAlreadyExists) {
        if (isAlreadyExists.userName === userName) {
            throw new BadRequestException(MESSAGES.USER.isUserNameExists);
        } else if (isAlreadyExists.email === email) {
            throw new BadRequestException(MESSAGES.USER.isAdminEmailExists);
        }
    }
    const encodedPassword = await bcrypt.generatePassword(password);
    data.password = encodedPassword;
    data.status = CONSTANTS.ENUMS.userStatus[0];
    data.role = superAdmin;
    const roleData = {
        roleId: 1,
    };
    const admin = await userRepository.createAdmin(data, roleData);
    return {
        id: admin.id,
        userName,
        role: superAdmin,
        status: admin.status,
    };
};
