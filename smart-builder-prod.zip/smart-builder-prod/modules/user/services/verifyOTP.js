const { MESSAGES } = require('../../../configs');
const { UnauthorizedException, BadRequestException } = require('../../../helpers/errorResponse');
const userRepository = require('../user.repository');

module.exports = async (data) => {
    const { otp, userName } = data;
    const user = await userRepository.findUserByUsername(userName);
    if (!user) throw new BadRequestException(MESSAGES.USER.userNotAvailable);
    if (!user?.verifyOtp) throw new BadRequestException(MESSAGES.USER.OTPNotAvailable);
    if (user.verifyOtp === otp) throw new UnauthorizedException(MESSAGES.USER.otpVerificationFailed);
    const updateUser = {
        wrongPasswordAttempts: 0,
        verifyOtp: 0,
    };
    await userRepository.updateUserDetails(updateUser, user.id);
    return true;
};
