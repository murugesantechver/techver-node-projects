const { MESSAGES } = require('../../../configs');
const { NotFoundException, UnauthorizedException, BadRequestException } = require('../../../helpers/errorResponse');
const userRepository = require('../user.repository');
const { bcrypt } = require('../../../utilities');
const userOldPasswordCheck = require('./userOldPasswordCheck');

module.exports = async (data) => {
    const { userName, password, confirmPassword } = data;
    if (password !== confirmPassword) throw new BadRequestException(MESSAGES.ADMIN.passwordNotMatch);
    let isExistingAdmin = await userRepository.findUserByUsername(userName);
    const OldPasswordCheck = await userOldPasswordCheck(userName, password);
    if (OldPasswordCheck.valid) throw new BadRequestException(MESSAGES.ADMIN.oldPassword);
    if (!isExistingAdmin) {
        throw new NotFoundException(MESSAGES.ADMIN.invalidCredentials);
    }
    const encodedPassword = await bcrypt.generatePassword(password);
    const updatePassword = await userRepository.updateUserDetails({ password: encodedPassword }, isExistingAdmin.id);
    if (!updatePassword) throw new UnauthorizedException(MESSAGES.ADMIN.passwordChangeFailed);
    return true;
};
