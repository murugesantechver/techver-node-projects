const { MESSAGES } = require('../../../configs');
const { UnauthorizedException, BadRequestException } = require('../../../helpers/errorResponse');
const userRepository = require('../user.repository');
const { bcrypt } = require('../../../utilities');
const oldPasswordCheck = require('./oldPasswordCheck');

module.exports = async (data, userId) => {
    const { password, confirmPassword } = data;
    if (password !== confirmPassword) throw new BadRequestException(MESSAGES.ADMIN.passwordNotMatch);
    const OldPasswordCheck = await oldPasswordCheck(userId, password);
    if (OldPasswordCheck.valid) throw new BadRequestException(MESSAGES.ADMIN.oldPassword);
    const encodedPassword = await bcrypt.generatePassword(password);
    const updatePassword = await userRepository.updateUserDetails({ password: encodedPassword }, userId);
    if (!updatePassword) throw new UnauthorizedException(MESSAGES.ADMIN.passwordChangeFailed);
    return true;
};
