const authServices = require('./services');
const { response } = require('../../helpers');
const { MESSAGES, LOGGER_CONFIG } = require('../../configs');
const { logger } = require('../../utilities');
const commonServices = require('../common/services');

exports.addRoles = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.AUTH.addRole.action;
    try {
        logger.info('Add Role Controller Function Initiated');
        const responsePayload = await authServices.addRoles(req.body);
        logger.info('Add Role Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.AUTH.rolesAdd);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('Add Role Ended With Exception');
        next(error);
    }
};

exports.addPermissions = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.AUTH.addPermission.action;
    try {
        logger.info('Add Permission Controller Function Initiated');
        const responsePayload = await authServices.addPermissions(req.body);
        logger.info('Add Permission Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.AUTH.permisionsAdd);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('Add Permission Ended With Exception');
        next(error);
    }
};

exports.listRoles = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.AUTH.listRoles.action;
    try {
        logger.info('List Roles Controller Function Initiated');
        const responsePayload = await authServices.listRoles();
        logger.info('List Roles Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.AUTH.rolesFetch);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('List Roles Ended With exception');
        next(error);
    }
};

exports.listPermission = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.AUTH.listPermission.action;
    try {
        logger.info('List Permission Controller Function Initiated');
        const responsePayload = await authServices.listPermission();
        logger.info('List Permission Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.AUTH.permissionsFetch);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('List Permission Ended With exception');
        next(error);
    }
};

exports.userRole = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.AUTH.userRole.action;
    try {
        logger.info('User Role Controller Function Initiated');
        const responsePayload = await authServices.userRole(req.body);
        logger.info('User Role Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.AUTH.userRole);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('User Role Function Ended With Exception');
        next(error);
    }
};

exports.rolePermission = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.AUTH.rolePermission.action;
    try {
        logger.info('Role Permission Controller Function Initiated');
        const responsePayload = await authServices.rolePermission(req.body);
        logger.info('Role Permission Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.AUTH.rolePermission);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.messgae);
        logger.error('Role Permission Ended With Exception');
        next(error);
    }
};
