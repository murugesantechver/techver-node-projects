const { MESSAGES } = require('../../../configs');
const { UnauthorizedException } = require('../../../helpers/errorResponse');
const oauthRepository = require('../oauth2.repository');

module.exports = async (username, password) => {
    const user = await oauthRepository.getUser(username, password);
    if (!user) throw new UnauthorizedException(MESSAGES.USER.invalidCredentials);
    return user;
};
