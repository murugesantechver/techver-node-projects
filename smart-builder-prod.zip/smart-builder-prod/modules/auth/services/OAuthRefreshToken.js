const oauthRepository = require('../oauth2.repository');

module.exports = async (refreshToken) => {
    const token = await oauthRepository.getRefreshToken(refreshToken);
    return token;
};
