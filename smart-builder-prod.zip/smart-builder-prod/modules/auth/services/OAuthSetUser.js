const oauthRepository = require('../oauth2.repository');

module.exports = async (data) => {
    const client = await oauthRepository.setUser(data);
    return client;
};
