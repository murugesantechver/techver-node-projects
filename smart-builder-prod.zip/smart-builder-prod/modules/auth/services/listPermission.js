const authRepository = require('../auth.repository');

module.exports = async () => {
    return await authRepository.listPermissions();
};
