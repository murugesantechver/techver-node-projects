const addRoles = require('./addRole');
const addPermissions = require('./addPermission');
const listPermission = require('./listPermission');
const listRoles = require('./listRoles');
const userRole = require('./userRole');
const rolePermission = require('./rolePermission');
const OAuthGetAccessToken = require('./OAuthGetAccessToken');
const OAuthGetClient = require('./OAuthGetClient');
const OAuthGetRefreshToken = require('./OAuthRefreshToken');
const OAuthGetUser = require('./OAuthGetUser');
const OAuthSaveToken = require('./OAuthSaveToken');
const OAuthSetClient = require('./OAuthSetClient');
const OAuthSetUser = require('./OAuthSetUser');

module.exports = {
    addRoles,
    addPermissions,
    listPermission,
    listRoles,
    userRole,
    rolePermission,
    OAuthGetAccessToken,
    OAuthGetClient,
    OAuthGetRefreshToken,
    OAuthGetUser,
    OAuthSaveToken,
    OAuthSetClient,
    OAuthSetUser,
};
