const oauthRepository = require('../oauth2.repository');

module.exports = async (data) => {
    const { clientId, clientSecret } = data;
    const client = await oauthRepository.getClient(clientId, clientSecret);
    return client;
};
