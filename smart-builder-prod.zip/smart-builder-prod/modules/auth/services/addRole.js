const { logger } = require('../../../utilities');
const authRepository = require('../auth.repository');
const { BadRequestException } = require('../../../helpers/errorResponse');
const { MESSAGES } = require('../../../configs');

module.exports = async (roleData) => {
    logger.info('roles-add-service function initiated');
    const role = roleData.role.toUpperCase();

    const roleDetails = {
        role: role,
    };

    const roleExists = await authRepository.searchRoles(role);
    if (roleExists?.length > 0) {
        throw new BadRequestException(MESSAGES.AUTH.roleAlreadyExists);
    } else {
        const roles = await authRepository.addRoles(roleDetails);
        return roles;
    }
};
