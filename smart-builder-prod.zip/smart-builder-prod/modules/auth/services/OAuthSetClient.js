const oauthRepository = require('../oauth2.repository');
const { generateClientIdAndSecret } = require('../utilities/generatClientCredentials');

module.exports = async (data) => {
    const { clientId, clientSecret } = generateClientIdAndSecret();
    const clientData = {
        clientId: data.clientId ? data.clientId : clientId,
        clientSecret: data.clientSecret ? data.clientSecret : clientSecret,
        redirectUri: data.redirectUri ? data.redirectUri : 'http://example.com/callback',
        grants: data.grants,
    };
    const client = await oauthRepository.setClient(clientData);
    const userData = {
        username: data.username,
        password: data.password,
        name: data.name,
    };
    const user = await oauthRepository.setUser(userData);
    const returnData = {
        clientId: client.clientId,
        clientSecret: client.clientSecret,
        grants: client.grants,
        client: client.client,
        username: user.username,
        password: user.password,
        name: user.name,
    };
    return returnData;
};
