const oauthRepository = require('../oauth2.repository');

module.exports = async (tokenData) => {
    const { token, client, user } = tokenData;
    const savedToken = await oauthRepository.saveToken(token, client, user);
    return savedToken;
};
