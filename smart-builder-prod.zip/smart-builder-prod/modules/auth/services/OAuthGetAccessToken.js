const oauthRepository = require('../oauth2.repository');

module.exports = async (bearerToken) => {
    const token = await oauthRepository.getAccessToken(bearerToken);
    return token;
};
