const { logger } = require('../../../utilities');
const authRepository = require('../auth.repository');
const { BadRequestException, NotFoundException } = require('../../../helpers/errorResponse');
const { MESSAGES } = require('../../../configs');
const { decryptData } = require('../../../helpers/encryption');

module.exports = async (data) => {
    logger.info('user-role-service function initiated');
    const { roleId, permissionId } = data;
    const decodedRoleId = decryptData(roleId);
    const decodedPermissionId = decryptData(permissionId);
    
    const role = await authRepository.getRoleById(decodedRoleId);
    const permission = await authRepository.getPermissionById(decodedPermissionId);

    if (!role) {
        throw new NotFoundException(`Role not found.`);
    }

    if (!permission) {
        throw new NotFoundException(`Permission not found.`);
    }

    const roleExistsWithPermissionId = await authRepository.roleExistsWithPermissionId(decodedRoleId, decodedPermissionId);
    if (roleExistsWithPermissionId) {
        throw new BadRequestException(MESSAGES.AUTH.roleWithSamePermission);
    }

    const rolePermission = await authRepository.rolePermissionCreate({
        roleId: decodedRoleId,
        permissionId: decodedPermissionId,
    });
    return rolePermission;
};