const { logger } = require('../../../utilities');
const authRepository = require('../auth.repository');
const { BadRequestException, NotFoundException } = require('../../../helpers/errorResponse');
const { MESSAGES } = require('../../../configs');
const { decryptData } = require('../../../helpers/encryption');

module.exports = async (data) => {
    logger.info('user-role-service function initiated');
    const { userId, roleId } = data;
    const decodedUserId = decryptData(userId);
    const decodedRoleId = decryptData(roleId);

    const user = await authRepository.getUserById(decodedUserId);
    const role = await authRepository.getRoleById(decodedRoleId);

    if (!user) {
        throw new NotFoundException(`User not found.`);
    }

    if (!role) {
        throw new NotFoundException(`Role not found.`);
    }
    

    const userExistsWithRoleId = await authRepository.userExistsWithRoleId(decodedUserId, decodedRoleId);
    if (userExistsWithRoleId) {
        throw new BadRequestException(MESSAGES.AUTH.userWithSameRole);
    }

    const userRoles = await authRepository.userRoleCreate({
        userId: decodedUserId,
        roleId: decodedRoleId,
    });
    return userRoles;
};
