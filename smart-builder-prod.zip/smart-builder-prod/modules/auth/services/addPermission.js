const { logger } = require('../../../utilities');
const authRepository = require('../auth.repository');
const { BadRequestException } = require('../../../helpers/errorResponse');
const { MESSAGES } = require('../../../configs');

module.exports = async (permissionData) => {
    logger.info('permission-add-service function initiated');
    const permission = permissionData.permission.toUpperCase();

    const permissionDetails = {
        permission: permission,
    };

    const permissionExists = await authRepository.searchPermission(permission);
    if (permissionExists?.length > 0) {
        throw new BadRequestException(MESSAGES.AUTH.permissionAlreadyExists);
    } else {
        const permissions = await authRepository.addPermissions(permissionDetails);
        return permissions;
    }
};
