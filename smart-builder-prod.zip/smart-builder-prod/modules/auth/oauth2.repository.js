const { OAuthClients, OAuthTokens, OAuthUsers } = require('../../database/models');
const bcrypt = require('bcrypt');
const { UnauthorizedException } = require('../../helpers/errorResponse');
const { MESSAGES } = require('../../configs');

exports.getAccessToken = async (bearerToken) => {
    return await OAuthTokens.findOne({
        where: {
            accessToken: bearerToken,
        },
        include: [
            {
                model: OAuthClients,
                as: 'client',
            },
            {
                model: OAuthUsers,
                as: 'user',
            },
        ],
    }).then((token) => {
        const data = new Object();
        for (const prop in token.get()) data[prop] = token[prop];
        data.client = data.client.get();
        data.user = data.user.get();
        return data;
    });
};

exports.getClient = async (clientId, clientSecret) => {
    return OAuthClients.findOne({
        where: {
            clientId: clientId,
            clientSecret: clientSecret,
        },
        raw: true,
    });
};

exports.getRefreshToken = async (refreshToken) => {
    return OAuthTokens.findOne({
        where: {
            refreshToken: refreshToken,
        },
        include: [
            {
                model: OAuthClients,
                as: 'client',
            },
            {
                model: OAuthUsers,
                as: 'user',
            },
        ],
    }).then((token) => {
        const data = new Object();
        for (const prop in token.get()) data[prop] = token[prop];
        data.client = data.client.get();
        data.user = data.user.get();
        return data;
    });
};

exports.getUser = async (username, password) => {
    return OAuthUsers.findOne({
        where: {
            username: username,
        },
    }).then((user) => {
        const isMatch = bcrypt.compareSync(password, user.get().password);
        if (isMatch) {
            return user.get();
        } else {
            throw new UnauthorizedException(MESSAGES.USER.invalidCredentials);
        }
    });
};

exports.saveToken = async (token, client, user) => {
    return OAuthTokens.create({
        accessToken: token.accessToken,
        accessTokenExpiresAt: token.accessTokenExpiresAt,
        clientId: client.id,
        refreshToken: token.refreshToken,
        refreshTokenExpiresAt: token.refreshTokenExpiresAt,
        userId: user.id,
    }).then((token) => {
        const data = new Object();
        console.log('Token get is', token.get());
        for (const prop in token.get()) data[prop] = token[prop];
        data.client = data.clientId;
        data.user = data.userId;

        return data;
    });
};

exports.revokeToken = async (token) => {
    return OAuthTokens.findOne({
        where: {
            refreshToken: token.refreshToken,
        },
    }).then((refreshToken) => {
        return refreshToken.destroy().then(() => {
            return !!refreshToken;
        });
    });
};

exports.setClient = async (client) => {
    return OAuthClients.create({
        clientId: client.clientId,
        clientSecret: client.clientSecret,
        redirectUri: client.redirectUri,
        grants: client.grants,
    }).then((client) => {
        client = client && typeof client == 'object' ? client.toJSON() : client;
        const data = new Object();
        for (const prop in client) data[prop] = client[prop];
        data.client = data.clientId;
        return data;
    });
};

exports.setUser = async (user) => {
    return OAuthUsers.create({
        username: user.username,
        password: user.password,
        name: user.name,
    }).then((userResult) => {
        userResult = userResult && typeof userResult == 'object' ? userResult.toJSON() : userResult;
        const data = new Object();
        for (const prop in userResult) data[prop] = userResult[prop];
        return data;
    });
};
