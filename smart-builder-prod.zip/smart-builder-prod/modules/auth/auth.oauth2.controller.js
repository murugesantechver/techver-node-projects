const authServices = require('./services');
const { response } = require('../../helpers');
const { MESSAGES } = require('../../configs');
const { logger } = require('../../utilities');

exports.getAccessToken = async (req, res, next) => {
    try {
        logger.info('oAuth2 Get Access Token Controller Initiated');
        const responsePayload = await authServices.OAuthGetAccessToken(req.body);
        return response.success(res, responsePayload, MESSAGES.AUTH.clientCredsCreated);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.messgae);
        logger.error('Client Credentials Generation Controller Ended With Exception');
        next(error);
    }
};

exports.getClient = async (req, res, next) => {
    try {
        logger.info('oAuth2 Get Client Controller Initiated');
        const responsePayload = await authServices.OAuthGetClient(req.body);
        return response.success(res, responsePayload, MESSAGES.AUTH.clientDetailsFetched);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.messgae);
        logger.error('oAuth2 Get Client Controller Ended With Exception');
        next(error);
    }
};

exports.getRefreshToken = async (req, res, next) => {
    try {
        logger.info('oAuth2 Get RefreshToken Controller Initiated');
        const responsePayload = await authServices.OAuthGetRefreshToken(req.body);
        return response.success(res, responsePayload, MESSAGES.AUTH.refreshTokenFetched);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.messgae);
        logger.error('oAuth2 Get RefreshToken Controller Ended With Exception');
        next(error);
    }
};

exports.getUser = async (req, res, next) => {
    try {
        logger.info('oAuth2 Get User Controller Function Initiated');
        const responsePayload = await authServices.OAuthGetUser(req.body);
        return response.success(res, responsePayload, MESSAGES.AUTH.userFetched);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.messgae);
        logger.error('oAuth2 Get User Controller Ended With Exception');
        next(error);
    }
};

exports.saveToken = async (req, res, next) => {
    try {
        logger.info('oAuth2 Save Token Controller Function Initiated');
        const responsePayload = await authServices.OAuthSaveToken(req.body);
        return response.success(res, responsePayload, MESSAGES.AUTH.tokenSaved);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.messgae);
        logger.error('oAuth2 Save Token Controller Ended With Exception');
        next(error);
    }
};

exports.revokeToken = async (req, res, next) => {
    try {
        logger.info('oAuth2 Revoke Token Controller Function Initiated');
        const responsePayload = await authServices.OAuthSaveToken(req.body);
        return response.success(res, responsePayload, MESSAGES.AUTH.tokenRevoked);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.messgae);
        logger.error('oAuth2 Revoke Token Controller Ended With Exception');
        next(error);
    }
};

exports.setClient = async (req, res, next) => {
    try {
        logger.info('oAuth2 set client Controller Function Initiated');
        const responsePayload = await authServices.OAuthSetClient(req.body);
        return response.success(res, responsePayload, MESSAGES.AUTH.ClientSet);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.messgae);
        logger.error('oAuth2 set client Controller Ended With Exception');
        next(error);
    }
};

// exports.setUser = async (req, res, next) => {
//     try {
//         logger.info('oAuth2 set user Controller Function Initiated');
//         const responsePayload = await authServices.OAuthSetUser(req.body);
//         return response.success(res, responsePayload, MESSAGES.AUTH.rolePermission);
//     } catch (error) {
//         logger.error('Exception Occured');
//         logger.error(error.messgae);
//         logger.error('oAuth2 set user Controller Ended With Exception');
//         next(error);
//     }
// };
