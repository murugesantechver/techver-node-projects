const express = require('express');
const router = express.Router();
const { addRoles, addPermissions, listRoles, listPermission, userRole, rolePermission } = require('./auth.controller');
const { setClient } = require('./auth.oauth2.controller');
const { authMiddleware, validationMiddleware } = require('../../middlewares');
const {
    addRoleValidator,
    addPermissionValidator,
    userRoleValidator,
    rolePermissionValidator,
    setClientValidator,
} = require('./auth.validation');
const OAuthServer = require('express-oauth-server');
const OAuthRepository = require('./oauth2.repository');

router.oauth = new OAuthServer({
    model: OAuthRepository,
});
router.post('/addRole', authMiddleware('SUPERADMIN'), validationMiddleware(addRoleValidator), addRoles);
router.get('/roleList', authMiddleware('SUPERADMIN'), listRoles);
router.post('/addPermission', authMiddleware('SUPERADMIN'), validationMiddleware(addPermissionValidator), addPermissions);
router.get('/permissionList', authMiddleware('SUPERADMIN'), listPermission);
router.post('/userRole', authMiddleware('SUPERADMIN'), validationMiddleware(userRoleValidator), userRole);
router.post('/rolePermission', authMiddleware('SUPERADMIN'), validationMiddleware(rolePermissionValidator), rolePermission);

router.post('/oauth/token', router.oauth.token());
router.post('/oauth/setclient', validationMiddleware(setClientValidator), setClient);
// router.post('/oauth/signup', validationMiddleware(), setUser);

module.exports = router;
