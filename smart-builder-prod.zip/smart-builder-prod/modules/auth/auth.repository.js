const { Roles, Permission, Userrole, Rolepermission, User } = require('../../database/models');

exports.addRoles = async (role, t = null) => {
    return await Roles.create(role, { transaction: t });
};

exports.searchRoles = async (role) => {
    return await Roles.findAll({
        where: {
            role: role,
        },
    });
};

exports.listRoles = async () => {
    return await Roles.findAndCountAll({
        distinct: true,
        attributes: ['id', 'role'],
    });
};

exports.addPermissions = async (permission, t = null) => {
    return await Permission.create(permission, { transaction: t });
};

exports.searchPermission = async (permission) => {
    return await Permission.findAll({
        where: {
            permission: permission,
        },
    });
};

exports.listPermissions = async () => {
    return await Permission.findAndCountAll({
        distinct: true,
        attributes: ['id', 'permission'],
    });
};

exports.getUserById = async (id) => {
    return await User.findOne({
        where: {
            id,
        },
    });
};

exports.getRoleById = async (id) => {
    return await Userrole.findOne({
        where: {
            id,
        },
    });
};

exports.getPermissionById = async (id) => {
    return await Rolepermission.findOne({
        where: {
            id,
        },
    });
};

exports.userExistsWithRoleId = async (userId, roleId) => {
    const count = await Userrole.count({
        where: {
            userId: userId,
            roleId: roleId,
        },
    });
    return count > 0;
};

exports.userRoleCreate = async (userId, roleId, t = null) => {
    return await Userrole.create(userId, roleId, { transaction: t });
};

exports.roleExistsWithPermissionId = async (roleId, permissionId) => {
    const count = await Rolepermission.count({
        where: {
            roleId: roleId,
            permissionId: permissionId,
        },
    });
    return count > 0;
};

exports.rolePermissionCreate = async (roleId, permissionId, t = null) => {
    return await Rolepermission.create(roleId, permissionId, { transaction: t });
};
