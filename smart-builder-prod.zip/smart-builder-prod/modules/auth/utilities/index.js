const oAuthServer = require('./oAuthServer');
const generateClients = require('./generatClientCredentials');

module.exports = {
    oAuthServer,
    generateClients,
};
