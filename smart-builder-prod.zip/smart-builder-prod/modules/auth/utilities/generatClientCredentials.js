exports.generateClientIdAndSecret = () => {
    const clientId = Math.random().toString(36).substring(2, 15);
    const clientSecret = Math.random().toString(36).substring(2, 15);
    return { clientId, clientSecret };
};
