const OAuth2Server = require('oauth2-server');
const {
    OAuthClient,
    OAuthAccessToken,
    OAuthScope,
    OAuthAuthorizationCode,
    OAuthUser,
    OAuthRefreshToken,
} = require('../../../database/models');

const oauthServer = new OAuth2Server({
    model: {
        create: async (clientId, clientSecret) => {
            const client = await OAuthClient.create({
                clientId,
                clientSecret,
                redirectUri: 'http://example.com/callback',
            });
            return client;
        },
        getClient: async (clientId, clientSecret) => {
            const client = await OAuthClient.findOne({
                where: { clientId, clientSecret },
            });
            return client;
        },
        saveToken: async (token, client, user) => {
            await OAuthAccessToken.create({
                accessToken: token.accessToken,
                accessTokenExpiresAt: token.accessTokenExpiresAt,
                scope: token.scope,
                OAuthClientId: client.id,
                OAuthUserId: user.id,
            });
        },
        getAccessToken: async (accessToken) => {
            const token = await OAuthAccessToken.findOne({
                where: { accessToken },
            });
            return token;
        },
        getRefreshToken: async (refreshToken) => {
            const token = await OAuthRefreshToken.findOne({
                where: { refreshToken },
            });
            return token;
        },
        revokeToken: async (token) => {
            await token.destroy();
        },
        saveAuthorizationCode: async (code, client, user) => {
            await OAuthAuthorizationCode.create({
                code: code.authorizationCode,
                expiresAt: code.expiresAt,
                redirectUri: code.redirectUri,
                scope: code.scope,
                OAuthClientId: client.id,
                OAuthUserId: user.id,
            });
        },
        getAuthorizationCode: async (code) => {
            const authCode = await OAuthAuthorizationCode.findOne({
                where: { code },
            });
            return authCode;
        },
        revokeAuthorizationCode: async (code) => {
            await code.destroy();
        },
        getUser: async (username, password) => {
            const user = await OAuthUser.findOne({
                where: { username, password },
            });
            return user;
        },
        getScope: async (scope) => {
            const scopes = await OAuthScope.findAll({
                where: { scope },
            });
            return scopes;
        },
    },
});

module.exports = oauthServer;
