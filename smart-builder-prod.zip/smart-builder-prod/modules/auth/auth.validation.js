const Joi = require('joi');

exports.addRoleValidator = {
    body: Joi.object().keys({
        role: Joi.string().required(),
    }),
};

exports.addPermissionValidator = {
    body: Joi.object().keys({
        permission: Joi.string().required(),
    }),
};

exports.userRoleValidator = {
    body: Joi.object().keys({
        userId: Joi.string().required(),
        roleId: Joi.string().required(),
    }),
};

exports.rolePermissionValidator = {
    body: Joi.object().keys({
        roleId: Joi.string().required(),
        permissionId: Joi.string().required(),
    }),
};

exports.setClientValidator = {
    body: Joi.object().keys({
        clientId: Joi.string().optional(),
        clientSecret: Joi.string().optional(),
        redirectUri: Joi.string().optional(),
        grants: Joi.array().items(Joi.string().valid('password', 'refresh_token')).required(),
        username: Joi.string().required(),
        password: Joi.string().required(),
        name: Joi.string().required(),
    }),
};
