const express = require('express');
const router = express.Router();
const { addConfiguration, deleteConfiguration, listConfigurations, updateConfiguration } = require('./configuration.controller');
const { authMiddleware } = require('../../middlewares');

router.post('/add', authMiddleware('SUPERADMIN'), addConfiguration);
router.delete('/:id', authMiddleware('SUPERADMIN'), deleteConfiguration);
router.get('/list', authMiddleware('SUPERADMIN'), listConfigurations);
router.patch('/:id', authMiddleware('SUPERADMIN'), updateConfiguration);

module.exports = router;
