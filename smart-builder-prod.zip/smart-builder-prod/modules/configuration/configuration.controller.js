const configurationServices = require('./services');
const { response } = require('../../helpers');
const { MESSAGES } = require('../../configs');
const { logger } = require('../../utilities');

exports.addConfiguration = async (req, res, next) => {
    try {
        logger.info('Add Configuration Controller Function Initiated');
        const responsePayload = await configurationServices.addConfiguration(req.body);
        logger.info('Add Configuration Function Ended');
        return response.success(res, responsePayload, MESSAGES.CONFIGURATIONS.configurationAdd);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('Add Configuration Ended With Exception');
        next(error);
    }
};

exports.listConfigurations = async (req, res, next) => {
    try {
        logger.info('List Configuration Controller Function Initiated');
        const responsePayload = await configurationServices.listConfigurations();
        logger.info('List Configuration Function Ended');
        return response.success(res, responsePayload, MESSAGES.CONFIGURATIONS.configurationsList);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('List Configuration Ended With Exception');
        next(error);
    }
};

exports.deleteConfiguration = async (req, res, next) => {
    const { id } = req.params;
    try {
        logger.info('Delete Configuration Controller Function Initiated');
        const responsePayload = await configurationServices.deleteConfiguration(id);
        logger.info('Delete Configuration Function Ended');
        return response.success(res, responsePayload, MESSAGES.CONFIGURATIONS.configurationDelete);
    } catch (error) {
        logger.error('Exception Occured');
        logger.error(error.message);
        logger.error('Delete Configuration Ended With Exception');
        next(error);
    }
};

exports.updateConfiguration = async (req, res, next) => {
    const { id } = req.params;
    try {
        logger.info('Update Configuration Controller Function Initiated');
        const user = await configurationServices.updateConfiguration(req.body, id);
        logger.info('Update Configuration Controller Function Ended');
        return response.success(res, user, MESSAGES.CONFIGURATIONS.configurationUpdate);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Update Configuration Ended With Exception');
        next(error);
    }
};
