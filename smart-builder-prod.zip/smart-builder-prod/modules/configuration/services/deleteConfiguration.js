const { logger } = require('../../../utilities');
const { MESSAGES } = require('../../../configs');
const { NotFoundException } = require('../../../helpers/errorResponse');
const configurationRepository = require('../configuration.repository');
const { decryptData } = require('../../../helpers/encryption');

module.exports = async (id) => {
    logger.info('delete-configuration-service function initiated');

    const decryptedId = decryptData(id);
    const configuration = await configurationRepository.findConfigurationById(decryptedId);

    if (!configuration) {
        throw new NotFoundException(MESSAGES.CONFIGURATIONS.configurationNotFOund);
    }

    await configurationRepository.deleteConfiguration(decryptedId);

    return true;
};
