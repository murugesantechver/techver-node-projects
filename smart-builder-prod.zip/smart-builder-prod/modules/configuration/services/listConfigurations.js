const configurationRepository = require('../configuration.repository');

module.exports = async () => {
    return await configurationRepository.listConfigurations();
};
