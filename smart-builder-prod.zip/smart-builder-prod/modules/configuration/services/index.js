const fetchConfigurations = require('./fetchConfiguration');
const cacheConfigurations = require('./cacheConfigurations');
const addConfiguration = require('./createConfigurations');
const deleteConfiguration = require('./deleteConfiguration');
const listConfigurations = require('./listConfigurations');
const updateConfiguration = require('./updateConfiguration');

module.exports = {
    fetchConfigurations,
    cacheConfigurations,
    addConfiguration,
    deleteConfiguration,
    listConfigurations,
    updateConfiguration,
};
