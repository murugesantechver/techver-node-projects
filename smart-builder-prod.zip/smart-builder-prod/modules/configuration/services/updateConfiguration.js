const { MESSAGES } = require('../../../configs');
const { logger } = require('../../../utilities');
const { decryptData } = require('../../../helpers/encryption');
const { NotFoundException } = require('../../../helpers/errorResponse');
const configurationRepository = require('../configuration.repository');

module.exports = async (data, id) => {
    logger.info('update-configuration-service function initiated');

    const decryptedId = decryptData(id);
    const configuration = await configurationRepository.findConfigurationById(decryptedId);

    if (!configuration) {
        throw new NotFoundException(MESSAGES.CONFIGURATIONS.configurationNotFOund);
    }

    const updateConfiguration = await configurationRepository.updateConfiguration(data, decryptedId);
    return updateConfiguration;
};
