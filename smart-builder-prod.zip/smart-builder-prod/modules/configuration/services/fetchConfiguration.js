const { logger } = require('../../../utilities');
const configurationRepository = require('../configuration.repository');

module.exports = async () => {
    logger.info('Get Configurations Service Initiated');
    const configurations = await configurationRepository.fetchConfigurations();
    return configurations.reduce((acc, config) => {
        acc[config.name] = config.value;
        return acc;
    }, {});
};
