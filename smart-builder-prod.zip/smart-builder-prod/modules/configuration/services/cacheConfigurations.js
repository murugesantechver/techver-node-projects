const { logger } = require('../../../utilities');
const fetchConfiguration = require('./fetchConfiguration');
const { configCache } = require('../../../utilities');

module.exports = async () => {
    logger.info('Cache Configurations Service Initiated');
    const configurations = await fetchConfiguration();
    if (configurations) {
        for (const key in configurations) {
            await configCache.createCache(key, configurations[key]);
        }
    }
    return true;
};
