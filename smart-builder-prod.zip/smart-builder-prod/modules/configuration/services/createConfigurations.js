const { logger } = require('../../../utilities');
const configurationRepository = require('../configuration.repository');
const { BadRequestException } = require('../../../helpers/errorResponse');
const { MESSAGES } = require('../../../configs');

module.exports = async (configurationData) => {
    logger.info('configurations-add-service function initiated');
    const { name, value } = configurationData;
    const nameCapitalized = name.toUpperCase();

    const configurationDetails = {
        name: nameCapitalized,
        value: value,
    };

    const configurationExists = await configurationRepository.searchConfiguration(nameCapitalized);
    if (configurationExists?.length > 0) {
        throw new BadRequestException(MESSAGES.CONFIGURATIONS.configurationsAlreadyExists);
    } else {
        const configurations = await configurationRepository.createConfiguration(configurationDetails);
        return configurations;
    }
};
