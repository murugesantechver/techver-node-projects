const { Configurations } = require('../../database/models');
const { Op } = require('sequelize');

exports.createConfiguration = async (configurationData, t = null) => {
    return await Configurations.create(configurationData, { transaction: t });
};

exports.fetchConfigurations = async () => {
    const attributes = ['name', 'value'];

    return await Configurations.findAll({
        attributes,
    });
};

exports.searchConfiguration = async (name) => {
    return await Configurations.findAll({
        where: {
            name: name,
        },
    });
};

exports.listConfigurations = async () => {
    return await Configurations.findAndCountAll({
        distinct: true,
        attributes: ['id', 'name', 'value'],
    });
};

exports.findConfigurationById = async (id) => {
    return await Configurations.findOne({
        where: {
            id,
        },
    });
};

exports.deleteConfiguration = async (id) => {
    return await Configurations.destroy({
        where: {
            id,
        },
    });
};

exports.updateConfiguration = async (data, id, t = null) => {
    const isUpdated = await Configurations.update(data, { where: { id }, transaction: t, returning: true });
    if (isUpdated[0] === 1) {
        return await this.findConfigurationById(id);
    }
    return {};
};
