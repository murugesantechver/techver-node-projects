const companyRepository = require('../company.repository');
const { logger } = require('../../../utilities');
const { BadRequestException } = require('../../../helpers/errorResponse');
const { MESSAGES } = require('../../../configs');

module.exports = async (companyData) => {
    logger.info('subcompany-add-service function initiated');
    const companyDetails = {
        subCompanyName: companyData.companyName,
    };
    const subCompanyExists = await companyRepository.searchSubCompanies(companyData.companyName);
    if (subCompanyExists?.length > 0) {
        throw new BadRequestException(MESSAGES.COMPANY.subCompanyAlreadyExists);
    } else {
        const company = await companyRepository.createSubCompany(companyDetails);
        return company;
    }
};
