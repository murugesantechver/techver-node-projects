const searchCompany = require('./searchCompanies');
const listCompanies = require('./listCompany');
const addCompany = require('./addCompany');
const addSubCompany = require('./addSubCompanies');
const searchSubCompany = require('./searchSubCompany');
const listSubCompanies = require('./listSubCompaniesByCompany');

module.exports = {
    searchCompany,
    listCompanies,
    addCompany,
    addSubCompany,
    searchSubCompany,
    listSubCompanies,
};
