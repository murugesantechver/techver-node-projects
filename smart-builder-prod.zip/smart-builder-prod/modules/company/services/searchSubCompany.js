const companyRepository = require('../company.repository');

module.exports = async (search) => {
    const searchData = await companyRepository.searchSubCompanies(search);
    return searchData;
};
