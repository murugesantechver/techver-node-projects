const companyRepository = require('../company.repository');
const { logger } = require('../../../utilities');
const { BadRequestException } = require('../../../helpers/errorResponse');
const { MESSAGES } = require('../../../configs');

module.exports = async (companyData) => {
    logger.info('company-add-service function initiated');
    const companyDetails = {
        companyName: companyData.companyName,
    };
    const companyExists = await companyRepository.searchCompanies(companyData.companyName);
    if (companyExists?.length > 0) {
        throw new BadRequestException(MESSAGES.COMPANY.companyAlreadyExists);
    } else {
        const company = await companyRepository.createCompany(companyDetails);
        return company;
    }
};
