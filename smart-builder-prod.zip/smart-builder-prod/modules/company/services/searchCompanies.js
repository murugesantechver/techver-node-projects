const companyRepository = require('../company.repository');

module.exports = async (search) => {
    const searchData = await companyRepository.searchCompanies(search);
    return searchData;
};
