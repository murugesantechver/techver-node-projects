const companyRepository = require('../company.repository');

module.exports = async ({ page, limit }) => {
    const clientData = await companyRepository.findSubCompanies(page, limit);
    return clientData;
};
