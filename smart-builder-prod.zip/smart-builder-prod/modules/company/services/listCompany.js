const companyRepository = require('../company.repository');

module.exports = async ({ page, limit }) => {
    const clientData = await companyRepository.findCompanies(page, limit);
    return clientData;
};
