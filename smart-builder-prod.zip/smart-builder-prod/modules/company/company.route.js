const express = require('express');
const router = express.Router();
const { validationMiddleware, authMiddleware } = require('../../middlewares');
const { listCompanies, searchCompany, addCompanies } = require('./company.controller');
const { searchCompanyValidator, addCompanyValidator, listCompanyValidator } = require('./company.validation');

router.get('/list', authMiddleware('COMPANY-MANAGEMENT'), validationMiddleware(listCompanyValidator), listCompanies);
router.get('/search', authMiddleware('COMPANY-MANAGEMENT'), validationMiddleware(searchCompanyValidator), searchCompany);
router.post('/add', authMiddleware('COMPANY-MANAGEMENT'), validationMiddleware(addCompanyValidator), addCompanies);

module.exports = router;
