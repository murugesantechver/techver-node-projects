const companyServices = require('./services');
const { response } = require('../../helpers');
const { MESSAGES } = require('../../configs');
const { logger } = require('../../utilities');
const commonServices = require('../common/services');

exports.addCompanies = async (req, res, next) => {
    const url = req.baseUrl + req.url;
    const { id: userId } = req.user;
    let type = req.query.type;
    try {
        logger.info('Company Add Controller Function Initiated');
        let responsePayload;
        let action;
        if (type === 'company') {
            responsePayload = await companyServices.addCompany(req.body);
            action = 'Add Company';
        } else {
            responsePayload = await companyServices.addSubCompany(req.body);
            action = 'Add Subcompany';
        }
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.COMPANY.companyAdded);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Company Add Ended With Exception');
        next(error);
    }
};

exports.listCompanies = async (req, res, next) => {
    let type = req.query.type;
    const { id: userId } = req.user;
    const page = req.query.page || 1;
    const limit = parseInt(req.query.limit) || 10;
    const url = req.baseUrl + req.url;
    const queryParams = {
        page,
        limit,
    };
    try {
        logger.info('Company List Controller Function Initiated');
        let responsePayload;
        let action;
        if (type === 'company') {
            responsePayload = await companyServices.listCompanies(queryParams);
            action = 'List Companies';
        } else {
            responsePayload = await companyServices.listSubCompanies(queryParams);
            action = 'List Subcompanies';
        }
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.COMPANY.companyListFetched);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Company List Ended With Exception');
        next(error);
    }
};

exports.searchCompany = async (req, res, next) => {
    const { searchTerm } = req.query;
    const { id: userId } = req.user;
    let type = req.query.type;
    const url = req.baseUrl + req.url;
    try {
        logger.info('Company Search Controller Function Initiated');
        let action;
        if (searchTerm) {
            let searchedItem;
            if (type === 'company') {
                searchedItem = await companyServices.searchCompany(searchTerm);
                action = 'Search Companies';
            } else {
                searchedItem = await companyServices.searchSubCompany(searchTerm);
                action = 'Search Subcompanies';
            }
            logger.info('Company Search Controller Function Ended');
            await commonServices.auditLogs(action, url, userId);
            return response.success(res, searchedItem, MESSAGES.COMPANY.companySearch);
        } else {
            logger.info('Company Search Controller Function Ended');
            await commonServices.auditLogs(action, url, userId);
            return response.badRequest(MESSAGES.CLIENT.notFound);
        }
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Company Search Ended With Exception');
        next(error);
    }
};
