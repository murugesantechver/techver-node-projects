const { Company, Subcompany } = require('../../database/models');
const { Op } = require('sequelize');

exports.createCompany = async (company, t = null) => {
    return await Company.create(company, { transaction: t });
};

exports.createSubCompany = async (company, t = null) => {
    return await Subcompany.create(company, { transaction: t });
};

exports.searchCompanies = async (searchTerm) => {
    const attributes = ['id', 'companyName'];

    return await Company.findAll({
        where: {
            companyName: {
                [Op.iLike]: `%${searchTerm}%`,
            },
        },
        attributes,
    });
};

exports.searchSubCompanies = async (searchTerm) => {
    const attributes = ['id', 'subCompanyName'];
    return await Subcompany.findAll({
        where: {
            subCompanyName: {
                [Op.iLike]: `%${searchTerm}%`,
            },
        },
        attributes,
    });
};

exports.findCompanies = async (page, limit) => {
    return await Company.findAndCountAll({
        offset: (page - 1) * limit,
        limit,
        attributes: ['id', 'companyName'],
    });
};

exports.findCompanyById = async (id) => {
    return await Company.findOne({
        where: {
            id,
        },
        attributes: ['companyName'],
    });
};

exports.findSubCompanies = async (page, limit) => {
    return await Subcompany.findAndCountAll({
        offset: (page - 1) * limit,
        limit,
        attributes: ['id', 'subCompanyName'],
    });
};

exports.findSubCompanyNameBySubCompanyId = async (subCompanyId) => {
    return await Subcompany.findOne({
        where: {
            id: subCompanyId,
        },
        attributes: ['subCompanyName'],
    });
};
