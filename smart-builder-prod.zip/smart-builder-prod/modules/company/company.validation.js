const Joi = require('joi');

exports.searchCompanyValidator = {
    query: Joi.object().keys({
        searchTerm: Joi.string().optional(),
        type: Joi.string().valid('company', 'subCompany').required(),
    }),
};

exports.addCompanyValidator = {
    body: Joi.object().keys({
        companyName: Joi.string()
            .allow(null)
            .trim()
            .regex(/^[a-z ,.'-]+$/i),
    }),
    query: Joi.object().keys({
        type: Joi.string().valid('company', 'subCompany').required(),
    }),
};

exports.listCompanyValidator = {
    query: Joi.object().keys({
        type: Joi.string().valid('company', 'subCompany').required(),
        page: Joi.number().optional(),
        limit: Joi.number().optional(),
    }),
};
