const { Campaign, Field, Survey, Company, Subcompany, campaignUniqueUrls } = require('../../../database/models');
const { Op } = require('sequelize');
const fieldsRepository = require('../fields/fields.respository');
const { CONSTANTS } = require('../../../configs');
const { admin, superAdmin } = CONSTANTS.USER.roles;

exports.createCampaign = async (campaign, t = null) => {
    return await Campaign.create(campaign, { transaction: t });
};

exports.updateCampaign = async (campaign, id, t = null) => {
    const isUpdated = await Campaign.update(campaign, { where: { id }, transaction: t });
    if (isUpdated[0] === 1) {
        return await this.findCampaignById(id);
    }
    return {};
};

exports.deleteCampaignById = async (id, t = null) => {
    const deletedCampaignCount = await Campaign.destroy({ where: { id }, transaction: t });
    if (deletedCampaignCount === 1) {
        return true;
    }
};

exports.addCampaignFields = async ({ fields, campaignId, t = null }) => {
    // get the complete fields list of a specific campaignId
    const existingFields = await Field.findAll({
        where: {
            campaignId: campaignId,
        },
    });

    // Find the fields that need to be added or updated (not present in existingFieldNames or requireFileUpload has changed)
    if (fields) {
        const fieldsToAddOrUpdate = fields.filter((field) => {
            const existingField = existingFields.find((existingField) => existingField.fieldName === field.fieldName);
            return (
                !existingField ||
                existingField.requireFileUpload !== field.requireFileUpload ||
                existingField.displayName !== field.displayName ||
                existingField.isMandatory !== field.isMandatory
            );
        });

        // Find the fields that need to be deleted (not present in fields)
        const fieldsToDelete = existingFields.filter((field) => !fields.some((newField) => newField.fieldName === field.fieldName));
        const { rows } = await fieldsRepository.listAllFieldsMaster();

        // Add new fields or update existing fields
        for (const fieldToAddOrUpdate of fieldsToAddOrUpdate) {
            const existingField = existingFields.find((field) => field.fieldName === fieldToAddOrUpdate.fieldName);

            if (existingField) {
                existingField.requireFileUpload = fieldToAddOrUpdate.requireFileUpload;
                existingField.displayName = fieldToAddOrUpdate.displayName;
                existingField.isMandatory = fieldToAddOrUpdate.isMandatory;
                const fieldType = rows.find((type) => type.fieldName === fieldToAddOrUpdate.fieldName);
                if (fieldType) {
                    existingField.fieldType = fieldType.fieldType;
                }
                await existingField.save();
            } else {
                const fieldType = rows.find((type) => type.fieldName === fieldToAddOrUpdate.fieldName);
                await Field.create({
                    campaignId,
                    fieldName: fieldToAddOrUpdate.fieldName,
                    requireFileUpload: fieldToAddOrUpdate.requireFileUpload,
                    isMandatory: fieldToAddOrUpdate.isMandatory,
                    displayName: fieldToAddOrUpdate.displayName,
                    fieldType: fieldType ? fieldType.fieldType : null, // Assign the field type if found, otherwise null
                });
            }
        }

        // Delete fields
        for (const fieldToDelete of fieldsToDelete) {
            await fieldToDelete.destroy();
        }
    }

    // Return the updated fields
    const campaignFields = await Field.findAll({
        where: { campaignId },
        attributes: ['id', 'fieldName'],
        transaction: t,
    });

    const updatedFields = campaignFields.map((field) => field.fieldName);

    return updatedFields;
};

exports.checkCampaignExists = async (checks) => {
    return await Campaign.findOne({
        where: {
            [Op.or]: checks,
        },
    });
};

exports.findAllCampaigns = async (limit, page) => {
    return await Campaign.findAndCountAll({
        offset: (page - 1) * limit,
        limit,
        distinct: true,
        attributes: ['id', 'issuedDate', 'startDate', 'endDate', 'status', 'publish', 'isActive'],
    });
};

exports.findCampaignById = async (id) => {
    return await Campaign.findOne({
        where: {
            id,
        },
        attributes: ['id', 'issuedDate', 'startDate', 'endDate'],
    });
};

exports.findCampaignsByCompanyName = async (companyId, limit, page) => {
    const { count, rows } = await Campaign.findAndCountAll({
        where: {
            companyId,
        },
        offset: (page - 1) * limit,
        limit,
        distinct: true,
        attributes: ['id', 'campaignName', 'issuedDate', 'startDate', 'endDate', 'status', 'publish', 'isActive'],
    });

    return {
        count,
        campaigns: rows.map((campaign) => campaign.toJSON()),
    };
};

exports.findCampaignsByCampaignId = async (campaignId) => {
    const campaign = await Campaign.findOne({
        where: {
            id: campaignId,
        },
        attributes: ['id', 'issuedDate', 'startDate', 'endDate', 'status', 'publish', 'isActive', 'inviteeAttempts'],
        include: [
            {
                model: Field,
                attributes: ['id', 'fieldName', 'displayName', 'fieldType', 'requireFileUpload', 'isMandatory'], // Add the fields you want to fetch from the Field model
            },
        ],
    });

    if (!campaign) {
        return null; // Return null or handle the case where no campaign is found
    }

    return campaign.toJSON();
};

exports.findMandatoryFieldsById = async (campaignId, t = null) => {
    return await Field.findAll(
        {
            where: {
                campaignId,
            },
            attributes: ['id', 'fieldName', 'fieldType', 'requireFileUpload', 'isMandatory'],
        },
        { transaction: t }
    );
};

exports.createSurvey = async (survey, t = null) => {
    return await Survey.create(survey, { transaction: t });
};

exports.findCampaignsByClientIdAndCompany = async (limit, page, role, companyDetails, id) => {
    const { companyId, subCompanyId } = companyDetails;
    let queryOptions = {
        offset: (page - 1) * limit,
        limit,
        attributes: [
            'id',
            'campaignName',
            'issuedDate',
            'companyId',
            'campaignUrl',
            'subCompanyId',
            'startDate',
            'endDate',
            'status',
            'publish',
            'isActive',
        ],
        include: [
            {
                model: Company,
                attributes: ['companyName'],
                as: 'companyName',
            },
            {
                model: Subcompany,
                attributes: ['subCompanyName'],
                as: 'subCompanyName',
            },
        ],
    };

    if (role.includes(admin) && !role.includes(superAdmin)) {
        const whereClause = {};

        // Check for companyId if it exists
        if (companyId) {
            whereClause.companyId = companyId;
        }

        // Check for subCompanyId if it exists
        if (subCompanyId) {
            whereClause.subCompanyId = subCompanyId;
        }

        // Check for companyOwner if it exists
        if (id) {
            whereClause.campaignOwner = id;
        }
        queryOptions.where = {
            [Op.and]: whereClause,
        };
    } else if (role.includes(superAdmin)) {
        queryOptions.where = { companyId: companyId };
    }

    const { count, rows } = await Campaign.findAndCountAll(queryOptions);
    return {
        count,
        campaigns: rows.map((campaign) => campaign.toJSON()),
    };
};

exports.findCampaignsByCompanyName = async (companyId, limit, page) => {
    const { count, rows } = await Campaign.findAndCountAll({
        where: {
            companyId,
        },
        offset: (page - 1) * limit,
        limit,
        distinct: true,
        attributes: ['id', 'campaignName', 'issuedDate', 'startDate', 'endDate', 'status', 'publish', 'isActive'],
    });

    return {
        count,
        campaigns: rows.map((campaign) => campaign.toJSON()),
    };
};

exports.getCompanyNameByCampaignId = async (campaignId) => {
    const campaign = await Campaign.findOne({
        where: {
            id: campaignId,
        },
        attributes: ['companyId'],
    });
    if (!campaign) {
        // Campaign not found with the given campaignId
        return null;
    }

    // Assuming the foreign key in Campaign model that points to the Company model is named "companyId"
    const companyId = campaign.companyId;

    // Find the company using the companyId
    return Company.findOne({
        where: {
            id: companyId,
        },
        attributes: ['companyName'], // Assuming the attribute storing the company name is named "name"
    });
};

exports.saveUniqueIds = async (uniqueIds, t = null) => {
    return await campaignUniqueUrls.bulkCreate(uniqueIds, { transaction: t });
};

exports.findUniqueIds = async (checks) => {
    return await campaignUniqueUrls.findAndCountAll({
        where: {
            [Op.or]: checks,
        },
    });
};

exports.doesUniqueIdsExists = async (checks) => {
    return await campaignUniqueUrls.findOne({
        where: {
            [Op.or]: checks,
        },
    });
};

exports.updateUniqueIdStatus = async (uniqueId, checks) => {
    const isUpdated = await campaignUniqueUrls.update(uniqueId, {
        where: {
            [Op.or]: checks,
        },
    });
    if (isUpdated[0] === 1) {
        return true;
    }
    return false;
};

exports.checkCompanyExists = async (companyId) => {
    return await Company.findOne({
        where: {
            id: companyId,
        },
    });
};
