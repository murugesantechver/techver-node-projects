const { MESSAGES, CONSTANTS } = require('../../../../configs');
const { BadRequestException, NotFoundException } = require('../../../../helpers/errorResponse');
const { date } = require('../../../../utilities');
const campaignRepository = require('../campaign.repository');
const userRepository = require('../../../user/user.repository');
const { Op } = require('sequelize');
const { uuid } = require('../../../../utilities');
const { decryptData } = require('../../../../helpers/encryption');
const { admin, superAdmin } = CONSTANTS.USER.roles;

module.exports = async (data, id, role) => {
    const { issuedDate, startDate, endDate, isActive, fields, inviteeAttempts } = data;
    let userCompanyDetails;
    const checkRoles = async (role) => {
        return role.includes(admin) && role.includes(superAdmin);
    };
    if (role) {
        if (!(await checkRoles(role))) {
            userCompanyDetails = await userRepository.getUserCompanyDetails(id);
        } else if (await checkRoles(role)) {
            if (!data.companyId) {
                throw new NotFoundException(MESSAGES.CAMPAIGN.companyNameNotProvided);
            }
            const company = decryptData(data.companyId);
            const companyExists = await campaignRepository.checkCompanyExists(company);

            if (!companyExists) {
                throw new NotFoundException(MESSAGES.CAMPAIGN.companyNotFound);
            }

            userCompanyDetails = {};
        }
    }

    // const userCompanyDetails
    const { companyId, subCompanyId } = userCompanyDetails;
    const campaignName = uuid.generateUniqueUUID(CONSTANTS.CAMPAIGN.campaignIdLength);
    const checks = [{ campaignName: { [Op.eq]: campaignName } }];
    let isAlreadyExists = await campaignRepository.checkCampaignExists(checks);

    let company;
    if (data.companyId) {
        company = decryptData(data.companyId);
    }
    if (isAlreadyExists) {
        if (isAlreadyExists.campaignName === campaignName) {
            throw new BadRequestException(MESSAGES.CAMPAIGN.isCampaignNameExists);
        }
    }
    let status;
    if (startDate || endDate) {
        status = await date.getCompaignStatusByDate(startDate, endDate);
    }
    const campaign = await campaignRepository.createCampaign({
        campaignOwner: id,
        campaignName,
        companyId: companyId ? companyId : company,
        subCompanyId: subCompanyId ? subCompanyId : null,
        inviteeAttempts: inviteeAttempts ? inviteeAttempts : 1,
        issuedDate,
        startDate,
        endDate,
        isActive,
        status,
        publish: false,
    });

    // create campaign fields
    const campaignFields = await campaignRepository.addCampaignFields({
        fields: fields,
        campaignId: campaign.id,
    });

    return {
        id: campaign.id,
        campaignName,
        issuedDate: issuedDate ? date.formatDate(issuedDate) : issuedDate,
        startDate: startDate ? date.formatDate(startDate) : startDate,
        endDate: endDate ? date.formatDate(endDate) : endDate,
        status,
        isActive,
        publish: false,
        campaignFields: campaignFields,
    };
};
