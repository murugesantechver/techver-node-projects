const { MESSAGES } = require('../../../../configs');
const { NotFoundException } = require('../../../../helpers/errorResponse');
const { csvUtils } = require('../../../../utilities');
const { Op } = require('sequelize');
const campaignRepository = require('../campaign.repository');

module.exports = async (id) => {
    const checks = [{ campaignId: { [Op.eq]: id } }];
    const doesUniqueIdsExists = await campaignRepository.findUniqueIds(checks);
    if (!doesUniqueIdsExists) throw new NotFoundException(MESSAGES.CAMPAIGN.noUniqueUrlAvailable);

    const formattedRows = doesUniqueIdsExists.rows.map((row) => {
        return {
            id: row.id,
            uniqueId: row.uniqueId,
            campaignurl: row.url,
        };
    });
    const serverUrl = await csvUtils.convertArrayToCsvFile(formattedRows, id, 'campaignurl');
    return serverUrl;
};
