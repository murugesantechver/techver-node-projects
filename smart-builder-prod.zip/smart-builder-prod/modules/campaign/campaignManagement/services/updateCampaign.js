const { MESSAGES, CONSTANTS } = require('../../../../configs');
const { NotFoundException, BadRequestException } = require('../../../../helpers/errorResponse');
const campaignRepository = require('../campaign.repository');
const { formatDate, getCompaignStatusByDate } = require('../../../../utilities/date');
const { superAdmin, admin } = CONSTANTS.USER.roles;
const { decryptData } = require('../../../../helpers/encryption');

module.exports = async (campaignData, id, role) => {
    const { fields, ...rest } = campaignData;
    if (role) {
        if (role.includes(superAdmin)) {
            if (campaignData.companyId) {
                const company = decryptData(campaignData.companyId);
                const companyExists = await campaignRepository.checkCompanyExists(company);

                if (!companyExists) {
                    throw new BadRequestException(MESSAGES.CAMPAIGN.companyNotFound);
                }
            }
        }
    }

    let campaignExists = await campaignRepository.findCampaignById(id);
    const { startDate, endDate } = campaignData;

    if (startDate || endDate) {
        let status;
        status = await getCompaignStatusByDate(startDate, endDate);
        rest.status = status;
    }
    if (!campaignExists) {
        throw new NotFoundException(MESSAGES.CAMPAIGN.campaignDoesNotExist);
    }

    if (campaignData.companyId && !role.includes(admin)) {
        const company = decryptData(campaignData.companyId);
        rest.companyId = company;
    }

    // update campaign
    const campaign = await campaignRepository.updateCampaign(rest, id);

    // create or update campaign fields
    const campaignFields = await campaignRepository.addCampaignFields({
        fields: fields,
        campaignId: id,
    });

    return {
        id: campaign.id,
        campaignName: campaign.campaignName,
        issuedDate: campaign.issuedDate ? formatDate(campaign.issuedDate) : campaign.issuedDate,
        startDate: campaign.startDate ? formatDate(campaign.issuedDate) : campaign.startDate,
        endDate: campaign.endDate ? formatDate(campaign.endDate) : campaign.endDate,
        status: campaign.status,
        publish: campaign.publish,
        campaignFields: campaignFields,
    };
};
