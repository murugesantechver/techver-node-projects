// const { MESSAGES, CONSTANTS } = require('../../../../configs');
// const { NotFoundException, BadRequestException } = require('../../../../helpers/errorResponse');
const campaignRepository = require('../campaign.repository');
// const { formatDate, getCompaignStatusByDate } = require('../../../../utilities/date');
// const { superAdmin, admin } = CONSTANTS.USER.roles;
// const { decryptData } = require('../../../../helpers/encryption');

module.exports = async (id) => {
    const deleteCampaign = await campaignRepository.deleteCampaignById(id);
    if (deleteCampaign) {
        return true;
    }
    return false;
};
