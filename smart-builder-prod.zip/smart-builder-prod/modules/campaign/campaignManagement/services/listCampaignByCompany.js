const campaignRepository = require('../campaign.repository');

module.exports = async ({ page, limit }, companyId) => {
    const campaignList = await campaignRepository.findCampaignsByCompanyName(companyId, limit, page);
    const formattedRows = campaignList.campaigns.map((row) => {
        return {
            id: row.id,
            campaignName: row.campaignName,
            status: row.status,
            publish: row.publish,
            isActive: row.isActive,
            fields: row.Fields,
        };
    });
    return {
        count: campaignList.count,
        campaignData: formattedRows,
    };
};
