const campaignRepository = require('../campaign.repository');
const { Op } = require('sequelize');
const { common } = require('../../../../utilities');
const { logger } = require('../../../../utilities');

module.exports = async ({ count, id }) => {
    const checks = [{ campaignId: { [Op.eq]: id } }];
    const doesUniqueIdsExists = await campaignRepository.findUniqueIds(checks);
    if (doesUniqueIdsExists) {
        logger.info('Generate Unique Id Service - Some UniqueIds already Exists');
        logger.info('New UniqueIds will be added to the previous list');
    }
    const uniqueIds = await common.generateUniqueIdsWithUrls(count, id);
    await campaignRepository.saveUniqueIds(uniqueIds);

    return;
};
