const campaignRepository = require('../campaign.repository');
// const { date } = require('../../../../utilities');
// const { Op } = require('sequelize');
// const { CONSTANTS } = require('../../../../configs');

module.exports = async ({ page, limit }, role, companyDetails, id) => {
    const campaignList = await campaignRepository.findCampaignsByClientIdAndCompany(limit, page, role, companyDetails, id);
    return campaignList;
};
