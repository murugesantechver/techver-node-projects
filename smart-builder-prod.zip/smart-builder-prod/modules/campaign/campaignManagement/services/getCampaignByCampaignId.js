const campaignRepository = require('../campaign.repository');
const fieldRepository = require('../../fields/fields.respository');
const inviteeRepository = require('../../invitee/invitee.repository');
const voucherRepository = require('../../voucher/voucher.repository');
const { BadRequestException } = require('../../../../helpers/errorResponse');
const { MESSAGES } = require('../../../../configs');

module.exports = async (campaignId) => {
    const campaignList = await campaignRepository.findCampaignsByCampaignId(campaignId);
    if (!campaignList) {
        throw new BadRequestException(MESSAGES.CAMPAIGN.notFound);
    }
    // Fetching master fields
    const masterFields = await fieldRepository.listAllFieldsMaster();
    // Filtering the campaign fields based on requireFileUpload condition
    const filteredFields = campaignList.Fields.map((field) => {
        const masterField = masterFields.rows.find((master) => master.fieldName === field.fieldName);
        if (masterField && !masterField.requireFileUpload) {
            // eslint-disable-next-line no-unused-vars
            const { requireFileUpload, ...filteredField } = field;
            return filteredField;
        }
        return field;
    });
    let campaignMetrics = {};
    const { totalInvitees, participatedPersons } = await inviteeRepository.getInviteeMetricsForCampaign(campaignId);
    const { totalVouchers, totalRedeemed } = await voucherRepository.getVoucherMetricsForCampaign(campaignId);

    campaignMetrics.totalInvitees = totalInvitees ? totalInvitees : '0';
    campaignMetrics.participatedPersons = participatedPersons ? participatedPersons : '0';
    campaignMetrics.totalVouchers = totalVouchers ? totalVouchers : '0';
    campaignMetrics.totalRedeemed = totalRedeemed ? totalRedeemed : '0';

    // Updating the campaign fields in the response
    campaignList.Fields = filteredFields;
    campaignList.campaignMetrics = campaignMetrics;

    return campaignList;
};
