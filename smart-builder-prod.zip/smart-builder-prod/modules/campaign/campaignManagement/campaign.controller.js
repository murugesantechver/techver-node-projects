const campaignServices = require('./services');
const { response } = require('../../../helpers');
const { MESSAGES, CONSTANTS, LOGGER_CONFIG } = require('../../../configs');
const { logger } = require('../../../utilities');
const { admin, superAdmin } = CONSTANTS.USER.roles;
const userRepository = require('../../user/user.repository');
const { BadRequestException } = require('../../../helpers/errorResponse');
const { decryptData } = require('../../../helpers/encryption');
const commonServices = require('../../common/services');

exports.createCampaign = async (req, res, next) => {
    const { role } = req.user;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CAMPAIGN.create.action;
    try {
        logger.info('Campaign Create Controller Function Initiated');
        const responsePayload = await campaignServices.createCampaign(req.body, userId, role);
        logger.info('Campaign Create Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.campaignCreated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Create ended with exception');
        next(error);
    }
};

exports.updateCampaign = async (req, res, next) => {
    const { id } = req.params;
    const { role } = req.user;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CAMPAIGN.update.action;
    try {
        logger.info('Campaign Update Controller Function Initiated');
        const responsePayload = await campaignServices.updateCampaign(req.body, id, role);
        logger.info('Campaign Update Controller Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.campaignUpdated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Create ended with exception');
        next(error);
    }
};

exports.deleteCampaign = async (req, res, next) => {
    const { id } = req.params;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CAMPAIGN.delete.action;
    try {
        logger.info('Campaign Delete Controller Function Initiated');
        const responsePayload = await campaignServices.deleteCampaign(id);
        logger.info('Campaign Delete Controller Function Ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.campaignUpdated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Delete ended with exception');
        next(error);
    }
};

exports.listCampaign = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CAMPAIGN.list.action;
    const page = req.query.page || 1;
    const limit = parseInt(req.query.limit) || 10;
    const queryParams = {
        page,
        limit,
    };
    try {
        logger.info('Campaign List For Owner Controller Function Initiated');
        const responsePayload = await campaignServices.listCampaign(queryParams);
        logger.info('Campaign List Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.campaignListed);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Create ended with exception');
        next(error);
    }
};

exports.listCampaignByCompany = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CAMPAIGN.listByCompany.action;
    const { id } = req.params;
    const page = req.query.page || 1;
    const limit = parseInt(req.query.limit) || 10;
    const queryParams = {
        page,
        limit,
    };
    try {
        logger.info('Campaign List By Company Controller Function Initiated');
        const responsePayload = await campaignServices.listCampaignByCompany(queryParams, id);
        logger.info('Campaign List By Company Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.campaignListed);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign By Company ended with exception');
        next(error);
    }
};

exports.listCampaignsOfCampaignOwnerAndCompany = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CAMPAIGN.listCampaignsOfCampaignOwnerAndCompany.action;
    const { role } = req.user;
    try {
        let companyDetails = {};
        if (role.includes(superAdmin)) {
            const { companyId } = req.query;
            if (!companyId) throw new BadRequestException(MESSAGES.CAMPAIGN.companyNameNotProvided);
            companyDetails.companyId = decryptData(companyId);
        }
        if (!role.includes(superAdmin) && role.includes(admin)) {
            const { companyId, subCompanyId } = await userRepository.getUserCompanyDetails(userId);
            companyDetails.companyId = companyId;
            if (subCompanyId) {
                companyDetails.subCompanyId = subCompanyId;
            }
        }
        const page = req.query.page || 1;
        const limit = parseInt(req.query.limit) || 10;
        const queryParams = {
            page,
            limit,
        };
        logger.info('Campaign List Controller Function Initiated');
        const responsePayload = await campaignServices.listCampaignByOwnerAndCompany(queryParams, role, companyDetails, userId);
        logger.info('Campaign List Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.campaignListed);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Create ended with exception');
        next(error);
    }
};

exports.getCampaignDetailsByCampaignId = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CAMPAIGN.listByCampaignId.action;
    const { id } = req.params;
    try {
        logger.info('Campaign List Controller Function Initiated');
        const responsePayload = await campaignServices.getCampaignDetailsByCampaignId(id);
        logger.info('Campaign List Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.campaignListed);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Create ended with exception');
        next(error);
    }
};

exports.generateUniqueUrl = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CAMPAIGN.generateUniqueUrl.action;
    const { id } = req.params;
    const { count } = req.query;
    const queryParams = {
        count,
        id,
    };
    try {
        logger.info('Generating Unique Id Controller Function Initiated');
        const responsePayload = await campaignServices.generateUniqueId(queryParams);
        logger.info('Generating Unique Id Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.generateUniqueId);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Generating Unique Id ended with exception');
        next(error);
    }
};

exports.downloadUniqueUrls = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.CAMPAIGN.downloadUniqueUrl.action;
    const { id } = req.params;
    try {
        logger.info('Generating Campaign URL Controller Function Initiated');
        const responsePayload = await campaignServices.downloadUniqueIds(id);
        logger.info('Download Campaign URL Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.downloadCampaignUrl);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Download Campaign URL ended with exception');
        next(error);
    }
};
