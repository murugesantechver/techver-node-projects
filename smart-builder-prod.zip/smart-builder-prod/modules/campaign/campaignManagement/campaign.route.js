const express = require('express');
const router = express.Router();
const {
    deleteCampaign,
    createCampaign,
    updateCampaign,
    listCampaign,
    listCampaignByCompany,
    getCampaignDetailsByCampaignId,
    listCampaignsOfCampaignOwnerAndCompany,
    generateUniqueUrl,
    downloadUniqueUrls,
} = require('./campaign.controller');
const { validationMiddleware, authMiddleware, decryptIds } = require('../../../middlewares');
const {
    createCampaignValidator,
    updateCampaignValidator,
    getCampaignsValidator,
    generateUniqueIdValidator,
} = require('./campaign.validation');

router.post('/create', authMiddleware('CAMPAIGN-MANAGEMENT'), validationMiddleware(createCampaignValidator), createCampaign);
router.delete('/:id', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, deleteCampaign);
router.patch('/:id', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, validationMiddleware(updateCampaignValidator), updateCampaign);
router.get('/', authMiddleware('SUPERADMIN'), validationMiddleware(getCampaignsValidator), listCampaign);
router.get('/company/:id', authMiddleware('SUPERADMIN'), decryptIds, validationMiddleware(getCampaignsValidator), listCampaignByCompany);
router.get('/:id/details', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, getCampaignDetailsByCampaignId);
router.get(
    '/list',
    authMiddleware('CAMPAIGN-MANAGEMENT'),
    validationMiddleware(getCampaignsValidator),
    listCampaignsOfCampaignOwnerAndCompany
);
router.post(
    '/:id/uniqueurl/generate',
    authMiddleware('CAMPAIGN-MANAGEMENT'),
    decryptIds,
    validationMiddleware(generateUniqueIdValidator),
    generateUniqueUrl
);
router.get('/:id/uniqueurl/download', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, downloadUniqueUrls);

module.exports = router;
