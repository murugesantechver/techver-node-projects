const Joi = require('joi');
const { MESSAGES } = require('../../../configs');

exports.createCampaignValidator = {
    body: Joi.object().keys({
        endDate: Joi.date().required(),
        issuedDate: Joi.date().required(),
        startDate: Joi.date()
            .required()
            .max(Joi.ref('issuedDate')) // Set maximum date as the startDate
            .messages({
                'date.max': MESSAGES.CAMPAIGN.startDateValidation,
            }),
        companyId: Joi.string().optional(),
        campaignMode: Joi.string().valid('NORMAL', 'WHATSAPP').optional(),
        inviteeAttempts: Joi.number().optional(),
        isActive: Joi.boolean().required(),
        fields: Joi.array()
            .items(
                Joi.object().keys({
                    fieldName: Joi.string().required(),
                    displayName: Joi.string().required(),
                    requireFileUpload: Joi.boolean().optional(),
                    isMandatory: Joi.boolean().optional(),
                })
            )
            .required()
            .messages({
                'string.pattern.base': MESSAGES.CAMPAIGN.fieldValidation,
            }),
    }),
};

exports.updateCampaignValidator = {
    body: Joi.object().keys({
        endDate: Joi.date().optional(),
        issuedDate: Joi.date().optional(),
        companyId: Joi.string().optional(),
        startDate: Joi.date()
            .optional()
            .max(Joi.ref('issuedDate')) // Set maximum date as the startDate
            .messages({
                'date.max': MESSAGES.CAMPAIGN.startDateValidation,
            }),
        isActive: Joi.boolean().optional(),
        publish: Joi.boolean().optional(),
        campaignMode: Joi.string().valid('NORMAL', 'WHATSAPP').optional(),
        campaignUrl: Joi.string()
            .trim()
            .uri({ scheme: ['http', 'https'] })
            .max(255)
            .optional(),
        inviteeAttempts: Joi.number().optional(),
        fields: Joi.array().optional().messages({
            'string.pattern.base': MESSAGES.CAMPAIGN.fieldValidation,
        }),
    }),
};

exports.getCampaignsValidator = {
    query: Joi.object().keys({
        page: Joi.number().optional(),
        limit: Joi.number().optional(),
        companyId: Joi.string().optional(),
    }),
};

exports.generateUniqueIdValidator = {
    query: Joi.object().keys({
        count: Joi.number().required().min(1),
    }),
};
