const fieldServices = require('./services');
const { response } = require('../../../helpers');
const { MESSAGES, LOGGER_CONFIG } = require('../../../configs');
const { logger } = require('../../../utilities');
const commonServices = require('../../common/services');

exports.listFields = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.FIELDS.list.action;
    try {
        logger.info('Fields List Controller Function Initiated');
        const responsePayload = await fieldServices.listFields();
        logger.info('Fields List Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.FIELDS.fieldsFetch);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Fields List ended with exception');
        next(error);
    }
};

exports.addField = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.FIELDS.add.action;
    try {
        logger.info('Add Field Controller Function Initiated');
        const responsePayload = await fieldServices.addField(req.body);
        logger.info('Add Field Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.FIELDS.fieldsAdd);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Add Field ended with exception');
        next(error);
    }
};
