const { Fieldmaster } = require('../../../database/models');
const { Op } = require('sequelize');

exports.listAllFieldsMaster = async () => {
    return await Fieldmaster.findAndCountAll({
        distinct: true,
        attributes: ['id', 'fieldName', 'displayName', 'fieldType', 'requireFileUpload'],
    });
};

exports.addFieldMaster = async (field, t = null ) => {
    return await Fieldmaster.create(field, { transaction: t });
};

exports.searchFieldMaster = async (checks) => {
    return await Fieldmaster.findAll({
        where: {
            [Op.or]: checks,
        },
    });
};
