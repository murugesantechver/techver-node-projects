const fieldRepository = require('../fields.respository');

module.exports = async () => {
    return await fieldRepository.listAllFieldsMaster();
};
