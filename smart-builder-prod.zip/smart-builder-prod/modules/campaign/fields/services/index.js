const listFields = require('./listFields');
const addField = require('./addField');

module.exports = {
    listFields,
    addField,
};
