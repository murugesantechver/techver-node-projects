const { logger } = require('../../../../utilities');
const fieldRepository = require('../fields.respository');
const { BadRequestException } = require('../../../../helpers/errorResponse');
const { Op } = require('sequelize');
const { MESSAGES } = require('../../../../configs');

module.exports = async (fieldData) => {
    logger.info('field-add-service function initiated');
    const fieldDetails = {
        fieldName: fieldData.fieldName,
        displayName: fieldData.displayName,
        requireFileUpload: fieldData.requireFileUpload || false,
        fieldType: fieldData.fieldType,
    };
    const checks = [{ fieldName: { [Op.like]: fieldData.fieldName } }];
    const fieldExists = await fieldRepository.searchFieldMaster(checks);
    if (fieldExists?.length > 0) {
        throw new BadRequestException(MESSAGES.FIELDS.fieldAlreadyExists);
    } else {
        const field = await fieldRepository.addFieldMaster(fieldDetails);
        return field;
    }
};
