const Joi = require('joi');

exports.addFieldValidator = {
    body: Joi.object().keys({
        fieldName: Joi.string().required(),
        displayName: Joi.string().required(),
        requireFileUpload: Joi.boolean().optional(),
        fieldType: Joi.string().valid('NORMAL', 'REWARD').required(),
    }),
};
