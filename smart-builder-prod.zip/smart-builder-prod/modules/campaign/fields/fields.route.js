const express = require('express');
const router = express.Router();
const { listFields, addField } = require('./fields.controller');
const { authMiddleware, validationMiddleware } = require('../../../middlewares');
const { addFieldValidator } = require('./fields.validation');

router.get('/fields/list', authMiddleware('CAMPAIGN-MANAGEMENT'), listFields);
router.post('/fields/add', authMiddleware('SUPERADMIN'), validationMiddleware(addFieldValidator), addField);

module.exports = router;
