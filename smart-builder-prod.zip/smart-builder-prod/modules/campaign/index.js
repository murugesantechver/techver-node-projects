const express = require('express');
const router = express.Router();

const campaignManagementRoutes = require('./campaignManagement/campaign.route');
const inviteeRoutes = require('./invitee/invitee.route');
const voucherRoutes = require('./voucher/voucher.route');
const surveyRoutes = require('./survey/survey.route');
const otpRoutes = require('./otp/otp.route');
const fieldRoutes = require('./fields/fields.route');
const paymentRoutes = require('./payment/payment.route');

router.use(campaignManagementRoutes);
router.use(otpRoutes);
router.use(inviteeRoutes);
router.use(voucherRoutes);
router.use(surveyRoutes);
router.use(fieldRoutes);
router.use(paymentRoutes);
module.exports = router;
