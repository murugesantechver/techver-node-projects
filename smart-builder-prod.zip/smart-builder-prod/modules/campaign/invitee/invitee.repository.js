const { Invitee } = require('../../../database/models');
const { fn, literal } = require('sequelize');
exports.createInvitee = async (invitee, t = null) => {
    return await Invitee.create(invitee, { transaction: t });
};

exports.bulkCreateInvitees = async (invitees, t = null) => {
    return await Invitee.bulkCreate(invitees, { transaction: t });
};

exports.updateInvitee = async (invitee, id, t = null) => {
    const isUpdated = await Invitee.update(invitee, { where: { id }, transaction: t });
    if (isUpdated[0] === 1) {
        return await this.findInviteeById(id);
    }
    return {};
};

exports.changeInviteeStatus = async (status, attempts, participated, phone, t = null) => {
    const updatedInvitee = await Invitee.update(
        { participated: participated, status: status, attempts: attempts }, // Updated status to 'participated'
        { where: { phone: phone }, transaction: t }
    );
    if (updatedInvitee[0] === 1) {
        return true;
    }

    return false;
};

exports.findInviteeById = async (id) => {
    return await Invitee.findOne({
        where: {
            id,
        },
        attributes: ['id', 'name', 'phone', 'status'],
    });
};

exports.getInviteeMetricsForCampaign = async (campaignId) => {
    const inviteeMetrics = await Invitee.findAll({
        where: { campaignId },
        attributes: [
            [fn('COUNT', literal('DISTINCT id')), 'totalInvitees'],
            [fn('SUM', literal(`CASE WHEN participated = true THEN 1 ELSE 0 END`)), 'participatedPersons'],
        ],
        raw: true,
    });
    return inviteeMetrics[0];
};

exports.findAll = async (whereClause) => {
    return await Invitee.findAll({
        where: whereClause,
        attributes: ['id', 'name', 'phone', 'status'],
    });
};

exports.findAllInviteesByCampaignId = async (campaignId, page, limit) => {
    return await Invitee.findAndCountAll({
        where: { campaignId },
        offset: (page - 1) * limit,
        limit,
        distinct: true,
        attributes: ['id', 'name', 'phone', 'status', 'createdAt', 'updatedAt', 'campaignId'],
    });
};

exports.findAllInviteesByCampaignId = async (campaignId, page, limit) => {
    return await Invitee.findAndCountAll({
        where: { campaignId },
        offset: (page - 1) * limit,
        limit,
        distinct: true,
        attributes: ['id', 'name', 'phone', 'status', 'createdAt', 'updatedAt', 'campaignId'],
    });
};

exports.checkInviteeExists = async (checks) => {
    return await Invitee.findOne({
        where: checks,
    });
};

exports.deleteInviteeByCampaignIdAndInviteeId = async (campaignId, inviteeId) => {
    return await Invitee.destroy({
        where: {
            campaignId: campaignId,
            id: inviteeId,
        },
    });
};

exports.deleteInviteesByCampaignId = async (campaignId) => {
    return await Invitee.destroy({
        where: {
            campaignId: campaignId,
        },
    });
};

exports.deleteInviteeById = async (inviteeId) => {
    return await Invitee.destroy({
        where: {
            id: inviteeId,
        },
    });
};
