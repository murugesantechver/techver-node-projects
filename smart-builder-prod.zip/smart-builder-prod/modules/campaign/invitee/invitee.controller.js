const inviteeServices = require('./services');
const { parse } = require('csv-parse');
const { response } = require('../../../helpers');
const { MESSAGES, CONSTANTS, LOGGER_CONFIG } = require('../../../configs');
const { logger } = require('../../../utilities');
const { BadRequestException } = require('../../../helpers/errorResponse');
const libphonenumber = require('libphonenumber-js');
const commonServices = require('../../common/services')

exports.createInvitees = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.INVITEES.create.action;
    const { id: campaignId } = req.params;
    try {
        logger.info('Campaign Create Controller: createInvitees Function Initiated');

        if (!req.files || !req.files[0]) {
            throw new Error('No file uploaded');
        }

        const file = req.files[0];

        const parts = file.originalname.split('_');
        let type;
        if (!parts[1]) {
            throw new BadRequestException(MESSAGES.CAMPAIGN.incorrectFileNamingForInvitee);
        } else {
            if (CONSTANTS.ENUMS.rewardFrame.includes(parts[1].toUpperCase())) {
                type = parts[1].toUpperCase();
            } else {
                throw new BadRequestException(MESSAGES.CAMPAIGN.incorrectFileNamingForInvitee);
            }
        }
        // Initialize the parser
        const parser = parse({
            delimiter: ',',
        });

        let records = [];
        let isFirstRow = true; // Variable to track the header row
        // Use the readable stream api to consume records
        parser.on('readable', function () {
            let record;
            while ((record = parser.read()) !== null) {
                if (isFirstRow) {
                    isFirstRow = false;
                    continue; // Skip the first row (header)
                }
                records.push(record);
            }
        });

        parser.on('error', function (err) {
            throw err;
        });

        parser.write(file.buffer);
        parser.end();

        // TODO: Do something with records
        let inviteesData = [];
        for (let index = 0; index < records.length; index++) {
            const record = records[index];
            const phoneNumber = record[9];

            if (!phoneNumber) {
                const message = `Phone number not provided on line ${index + 1}`;
                throw new BadRequestException(message);
            }

            // Validate the phone number
            const parsedPhoneNumber = libphonenumber.parsePhoneNumberFromString(phoneNumber, 'IN'); // Change 'US' to your country code
            if (parsedPhoneNumber && parsedPhoneNumber.isValid()) {
                inviteesData.push({
                    name: record[0] ? record[0] : 'No Name',
                    phone: phoneNumber,
                    status: 'ACTIVE',
                    rewardType: type,
                    campaignId,
                });
            } else {
                // Invalid phone number, handle the error or skip it
                const message = `Invalid phone number on line ${index + 1}`;
                throw new BadRequestException(`${message}`);
                // Handle or log the error message
            }
        }

        const responsePayload = await inviteeServices.createInvitee(inviteesData, campaignId);
        logger.info('Campaign createInvitees Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.inviteeCreated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Create ended with exception');
        next(error);
    }
};

exports.getInviteeData = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.INVITEES.data.action;
    const { id: campaignId } = req.params;
    try {
        logger.info('Campaign listInvitee Controller Function Initiated');
        const responsePayload = await inviteeServices.getInviteeData({ campaignId });
        logger.info('Campaign listInvitee Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.inviteeListed);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign List Invitees ended with exception');
        next(error);
    }
};

exports.downloadInviteeByCampaignId = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.INVITEES.downloadInviteeByCampaignId.action;
    const { id: campaignId } = req.params;
    const { template } = req.query;
    try {
        logger.info('Invitee Download Controller Function Initiated');
        const responsePayload = await inviteeServices.downloadInvitee(campaignId, template);
        logger.info('Invitee Download Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.inviteeListed);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Invitees Download ended with exception');
        next(error);
    }
};

exports.deleteInvitees = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.INVITEES.deleteInvitees.action;
    const { id: campaignId, inviteeId } = req.params;
    try {
        logger.info('Campaign deleteInvitees Controller Function Initiated');
        const responsePayload = await inviteeServices.deleteInvitee({ campaignId, inviteeId });
        logger.info('Campaign deleteInvitees Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.inviteeDeleted);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Delete Invitees ended with exception');
        next(error);
    }
};
