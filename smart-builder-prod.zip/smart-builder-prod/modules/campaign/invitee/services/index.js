const createInvitee = require('./createInvitee');
const getInviteeData = require('./listInvitee');
const deleteInvitee = require('./deleteInvitee');
const downloadInvitee = require('./downloadInvitee');

module.exports = {
    createInvitee,
    getInviteeData,
    deleteInvitee,
    downloadInvitee,
};
