const { BadRequestException } = require('../../../../helpers/errorResponse');
const { Op } = require('sequelize');
const inviteeRepository = require('../invitee.repository');

// module.exports = async (inviteesData, campaignId) => {
//     // Validate invitees data
//     if (!inviteesData || inviteesData.length === 0) {
//         throw new BadRequestException('No invitee data provided');
//     }

//     // Add campaignId to each invitee object
//     const processedInviteesData = inviteesData.map((invitee) => ({ ...invitee, campaignId }));

//     // Check if any of the invitees already exist
//     const phoneNumbers = processedInviteesData.map((invitee) => invitee.phone);

//     const existingInvitees = await inviteeRepository.findAll({
//         phone: { [Op.in]: phoneNumbers },
//         campaignId: { [Op.eq]: campaignId },
//     });

//     if (existingInvitees && existingInvitees.length > 0) {
//         // Filter out existing invitees from the incoming data
//         const newInviteesData = inviteesData.filter((invitee) => {
//             return !existingInvitees.some((existingInvitee) => {
//                 return existingInvitee.phone === invitee.phone;
//             });
//         });

//         if (newInviteesData.length === 0) {
//             throw new BadRequestException('All invitees already exist in this campaign');
//         }

//         // Add campaignId to each new invitee object
//         const processedInviteesData = newInviteesData.map((invitee) => ({
//             ...invitee,
//             campaignId,
//         }));

//         // Bulk create new invitees
//         const createdInvitees = await inviteeRepository.bulkCreateInvitees(processedInviteesData);

//         return createdInvitees;
//     } else {
//         // Add campaignId to each invitee object
//         const processedInviteesData = inviteesData.map((invitee) => ({
//             ...invitee,
//             campaignId,
//         }));

//         // Bulk create invitees
//         const createdInvitees = await inviteeRepository.bulkCreateInvitees(processedInviteesData);

//         return createdInvitees;
//     }
// };

module.exports = async (inviteesData, campaignId) => {
    // Validate invitees data
    if (!inviteesData || inviteesData.length === 0) {
        throw new BadRequestException('No invitee data provided');
    }

    // Check if any of the invitees already exist
    const phoneNumbers = inviteesData.map((invitee) => invitee.phone);

    const existingInvitees = await inviteeRepository.findAll({
        phone: { [Op.in]: phoneNumbers },
        campaignId: { [Op.eq]: campaignId },
    });
    if (existingInvitees && existingInvitees.length > 0) {
        // Filter out existing invitees from the incoming data
        const newInviteesData = inviteesData.filter((invitee) => {
            return !existingInvitees.some((existingInvitee) => {
                return existingInvitee.phone === invitee.phone;
            });
        });

        if (newInviteesData.length === 0) {
            throw new BadRequestException('All invitees already exist in this campaign');
        }

        // Bulk create invitees
        const createdInvitees = await inviteeRepository.bulkCreateInvitees(newInviteesData);

        return createdInvitees;
    } else {
        // Add campaignId to each invitee object
        const processedInviteesData = inviteesData.map((invitee) => ({
            ...invitee,
            campaignId,
        }));

        // Bulk create invitees
        const createdInvitees = await inviteeRepository.bulkCreateInvitees(processedInviteesData);

        return createdInvitees;
    }
};
