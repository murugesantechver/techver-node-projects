const inviteeRepository = require('../invitee.repository');

module.exports = async ({ campaignId, inviteeId }) => {
    let deleteCount = 0;

    if (campaignId && inviteeId) {
        deleteCount = await inviteeRepository.deleteInviteeByCampaignIdAndInviteeId(campaignId, inviteeId);
    } else if (campaignId) {
        deleteCount = await inviteeRepository.deleteInviteesByCampaignId(campaignId);
    } else if (inviteeId) {
        deleteCount = await inviteeRepository.deleteInviteeById(inviteeId);
    }

    return { deleteCount };
};
