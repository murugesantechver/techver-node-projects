const inviteeRepository = require('../invitee.repository');
module.exports = async ({ campaignId }) => {
    const inviteeMetrics = await inviteeRepository.getInviteeMetricsForCampaign(campaignId);
    let metrics;
    if (inviteeMetrics) {
        metrics = {
            totalInvitees: inviteeMetrics.totalInvitees,
            participated: inviteeMetrics.participatedPersons == null ? '0' : inviteeMetrics.participatedPersons,
        };
    } else {
        metrics = {
            totalInvitees: 0,
            participated: 0,
        };
    }
    return metrics;
};
