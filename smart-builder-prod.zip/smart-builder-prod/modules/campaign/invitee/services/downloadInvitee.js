const { MESSAGES } = require('../../../../configs');
const { NotFoundException } = require('../../../../helpers/errorResponse');
const { csvUtils } = require('../../../../utilities');
const inviteeRepository = require('../invitee.repository');

module.exports = async (campaignId, template) => {
    const inviteeCount = await inviteeRepository.getInviteeMetricsForCampaign(campaignId);
    if (!inviteeCount) {
        throw new NotFoundException(MESSAGES.CAMPAIGN.inviteeFileNotFound);
    }
    const page = 1;
    const limit = inviteeCount.totalInvitees;
    const inviteeList = await inviteeRepository.findAllInviteesByCampaignId(campaignId, page, limit);
    const formattedRows = inviteeList.rows.map((row) => {
        return {
            id: row.id,
            name: row.name,
            phone: row.phone,
            status: row.status,
            createdAt: row.createdAt,
            updatedAt: row.updatedAt,
            campaignId: row.campaignId,
        };
    });
    const serverUrl = await csvUtils.convertArrayToCsvFile(formattedRows, campaignId, 'invitee', template);
    return serverUrl;
};
