const express = require('express');
const router = express.Router();
const { createInvitees, downloadInviteeByCampaignId, getInviteeData, deleteInvitees } = require('./invitee.controller');
const { authMiddleware, getUploadMiddleware, decryptIds } = require('../../../middlewares');

router.post('/:id/invitees', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, getUploadMiddleware('memory', ['csv']), createInvitees);
router.get('/:id/invitees', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, getUploadMiddleware('memory', ['csv']), getInviteeData);
router.get(
    '/:id/invitees/download/',
    authMiddleware('CAMPAIGN-MANAGEMENT'),
    decryptIds,
    getUploadMiddleware('memory', ['csv']),
    downloadInviteeByCampaignId
);
router.delete('/:id/invitees', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, getUploadMiddleware('memory', ['csv']), deleteInvitees);
router.delete(
    '/:id/invitees/:inviteeId',
    authMiddleware('CAMPAIGN-MANAGEMENT'),
    decryptIds,
    getUploadMiddleware('memory', ['csv']),
    deleteInvitees
);

module.exports = router;
