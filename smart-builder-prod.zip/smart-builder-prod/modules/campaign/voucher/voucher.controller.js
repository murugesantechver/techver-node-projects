const voucherServices = require('./services');
const { parse } = require('csv-parse');
const { response } = require('../../../helpers');
const { MESSAGES, LOGGER_CONFIG } = require('../../../configs');
const { logger } = require('../../../utilities');
const commonServices = require('../../common/services');
const { promisify } = require('util');
const parseAsync = promisify(parse);
exports.createVouchers = async (req, res, next) => {
    const { id: campaignId } = req.params;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.VOUCHERS.create.action;
    try {
        logger.info('Campaign Create Controller: createVoucher Function Initiated');

        if (!req.files || !req.files[0]) {
            throw new Error('No file uploaded');
        }

        const file = req.files[0];
        const records = await parseAsync(file.buffer, { delimiter: ',' });
        let vouchersData = records.map((arr) => {
            return {
                voucherNumber: arr[0],
                status: 'AVAILABLE',
                denomination: arr[1] ? arr[1] : 0, // TODO Check for the default status. Assuming all vouchers are unused initially
                campaignId,
            };
        });
        const responsePayload = await voucherServices.createVoucher(vouchersData, campaignId);
        logger.info('Campaign Create Voucher Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.voucherCreated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Create ended with exception');
        next(error);
    }
};

exports.listVoucher = async (req, res, next) => {
    const { id: campaignId } = req.params;
    const page = req.query.page || 1;
    const limit = parseInt(req.query.limit) || 10;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.VOUCHERS.list.action;
    try {
        logger.info('Campaign List Voucher Controller Function Initiated');
        const responsePayload = await voucherServices.listVoucher({ campaignId, page, limit });
        logger.info('Campaign List Voucher Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.voucherListed);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign List Vouchers ended with exception');
        next(error);
    }
};

exports.deleteVouchers = async (req, res, next) => {
    const { id: campaignId, voucherId } = req.params;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.VOUCHERS.delete.action;
    try {
        logger.info('Campaign Delete Vouchers Controller Function Initiated');
        const responsePayload = await voucherServices.deleteVoucher({ campaignId, voucherId });
        logger.info('Campaign Delete Vouchers Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.voucherDeleted);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Campaign Delete Vouchers ended with exception');
        next(error);
    }
};

exports.downloadVoucherByCampaignId = async (req, res, next) => {
    const { id: campaignId } = req.params;
    const { template } = req.query;
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.VOUCHERS.download.action;
    try {
        logger.info('Voucher Download Controller Function Initiated');
        const responsePayload = await voucherServices.downloadVoucher(campaignId, template);
        logger.info('Voucher Download Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.CAMPAIGN.voucherListed);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Voucher Download ended with exception');
        next(error);
    }
};
