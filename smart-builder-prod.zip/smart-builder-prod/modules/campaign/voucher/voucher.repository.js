const { Voucher } = require('../../../database/models');
const { fn, literal } = require('sequelize');

exports.createVoucher = async (voucher, t = null) => {
    return await Voucher.create(voucher, { transaction: t });
};

exports.bulkcreateVoucher = async (vouchers, t = null) => {
    return await Voucher.bulkCreate(vouchers, { transaction: t });
};

exports.updateVoucher = async (voucher, id, t = null) => {
    const isUpdated = await Voucher.update(voucher, { where: { id }, transaction: t });
    if (isUpdated[0] === 1) {
        return await this.findVoucherById(id);
    }
    return {};
};

exports.findVoucherByCampaignId = async (campaignId, voucherNumber) => {
    return await Voucher.findOne({
        where: {
            voucherNumber: voucherNumber,
            campaignId: campaignId,
        },
        attributes: ['id', 'voucherNumber', 'status', 'campaignId'],
    });
};

exports.findVoucherById = async (id) => {
    return await Voucher.findOne({
        where: {
            id,
        },
        attributes: ['id', 'voucherNumber', 'status', 'campaignId'],
    });
};

exports.findVoucherByVoucherNumber = async (campaignId, voucherNumber) => {
    return await Voucher.findOne({
        where: {
            campaignId: campaignId,
            voucherNumber: voucherNumber,
        },
        attributes: ['id'],
    });
};

exports.findVoucherByName = async (voucher) => {
    return await Voucher.findOne({
        where: {
            voucherNumber: voucher,
        },
        attributes: ['id', 'voucherNumber', 'status'],
    });
};

exports.findAll = async (whereClause) => {
    return await Voucher.findAll({
        where: whereClause,
        attributes: ['id', 'voucherNumber', 'status', 'campaignId'],
    });
};

exports.findAllVouchersByCampaignId = async (campaignId, page, limit) => {
    return await Voucher.findAndCountAll({
        where: { campaignId },
        offset: (page - 1) * limit,
        limit,
        distinct: true,
        attributes: ['id', 'voucherNumber', 'denomination', 'status', 'createdAt', 'updatedAt', 'campaignId'],
    });
};

exports.checkVoucherExists = async (checks) => {
    return await Voucher.findOne({
        where: checks,
    });
};

exports.deleteVoucherByCampaignIdAndVoucherId = async (campaignId, voucherId) => {
    return await Voucher.destroy({
        where: {
            campaignId: campaignId,
            id: voucherId,
        },
    });
};

exports.deleteVouchersByCampaignId = async (campaignId) => {
    return await Voucher.destroy({
        where: {
            campaignId: campaignId,
        },
    });
};

exports.deleteVoucherById = async (voucherId) => {
    return await Voucher.destroy({
        where: {
            id: voucherId,
        },
    });
};

exports.changeVoucherStatus = async (status, voucherCode, t = null) => {
    const updatedInvitee = await Voucher.update(
        { status: status }, // Updated status to 'redeemed'
        { where: { voucherNumber: voucherCode }, transaction: t }
    );
    if (updatedInvitee[0] === 1) {
        return true;
    }

    return false;
};

exports.getVoucherMetricsForCampaign = async (campaignId) => {
    const voucherMetrics = await Voucher.findAll({
        where: { campaignId },
        attributes: [
            [fn('COUNT', literal('DISTINCT id')), 'totalVouchers'],
            [fn('SUM', literal(`CASE WHEN status = 'REDEEMED' THEN 1 ELSE 0 END`)), 'totalRedeemed'],
        ],
        raw: true,
    });
    return voucherMetrics[0];
};
