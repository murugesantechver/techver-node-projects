const createVoucher = require('./createVoucher');
const listVoucher = require('./listVoucher');
const deleteVoucher = require('./deleteVoucher');
const downloadVoucher = require('./downloadVoucher');

module.exports = {
    createVoucher,
    listVoucher,
    deleteVoucher,
    downloadVoucher,
};
