const voucherRepository = require('../voucher.repository');

module.exports = async ({ campaignId, page, limit }) => {
    const voucherList = await voucherRepository.findAllVouchersByCampaignId(campaignId, page, limit);

    const formattedRows = voucherList.rows.map((row) => {
        return {
            id: row.id,
            voucherNumber: row.voucherNumber,
            status: row.status,
            createdAt: row.createdAt,
            updatedAt: row.updatedAt,
            campaignId: row.campaignId,
        };
    });

    return {
        count: voucherList.count,
        voucherData: formattedRows,
    };
};
