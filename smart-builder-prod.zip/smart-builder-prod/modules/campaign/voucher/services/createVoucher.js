const { BadRequestException } = require('../../../../helpers/errorResponse');
const { Op } = require('sequelize');
const voucherRepository = require('../voucher.repository');
const { MESSAGES } = require('../../../../configs');

module.exports = async (vouchersData, campaignId) => {
    // Validate vouchers data
    if (!vouchersData || vouchersData.length === 0) {
        throw new BadRequestException('No voucher data provided');
    }

    // Add campaignId to each voucher object
    const processedVouchersData = vouchersData.map((voucher) => ({ ...voucher, campaignId }));

    // Check if any of the vouchers already exist
    const voucherNumbers = processedVouchersData.map((voucher) => voucher.voucherNumber);

    const existingVouchers = await voucherRepository.findAll({
        voucherNumber: { [Op.in]: voucherNumbers },
    });

    if (existingVouchers && existingVouchers.length > 0) {
        const newVouchersData = vouchersData.filter((voucher) => {
            return !existingVouchers.some((existingVoucher) => {
                return existingVoucher.voucherNumber === voucher.voucherNumber;
            });
        });
        if (newVouchersData.length === 0) {
            throw new BadRequestException(MESSAGES.CAMPAIGN.voucherExistsForCampaign);
        }
        // Bulk create invitees
        const createdVouchers = await voucherRepository.bulkcreateVoucher(newVouchersData);

        return createdVouchers;
    } else {
        // Bulk create vouchers
        const createdVouchers = await voucherRepository.bulkcreateVoucher(processedVouchersData);

        return createdVouchers;
    }
};
