const { MESSAGES } = require('../../../../configs');
const { NotFoundException } = require('../../../../helpers/errorResponse');
const voucherRepository = require('../voucher.repository');
const { csvUtils } = require('../../../../utilities');

module.exports = async (campaignId, template) => {
    const voucherCount = await voucherRepository.getVoucherMetricsForCampaign(campaignId);

    if (!voucherCount) {
        throw new NotFoundException(MESSAGES.CAMPAIGN.voucherFileNotFound);
    }
    const page = 1;
    const limit = voucherCount.totalVouchers;
    const vouchersList = await voucherRepository.findAllVouchersByCampaignId(campaignId, page, limit);
    const formattedRows = vouchersList.rows.map((row) => {
        return {
            id: row.id,
            voucherNumber: row.voucherNumber,
            denomination: row.denomination,
            status: row.status,
            updatedAt: row.updatedAt,
            campaignId: row.campaignId,
        };
    });
    const serverUrl = await csvUtils.convertArrayToCsvFile(formattedRows, campaignId, 'voucher', template);
    return serverUrl;
};
