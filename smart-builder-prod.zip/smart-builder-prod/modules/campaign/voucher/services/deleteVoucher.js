const voucherRepository = require('../voucher.repository');

module.exports = async ({ campaignId, voucherId }) => {
    let deleteCount = 0;

    if (campaignId && voucherId) {
        deleteCount = await voucherRepository.deleteVoucherByCampaignIdAndVoucherId(campaignId, voucherId);
    } else if (campaignId) {
        deleteCount = await voucherRepository.deleteVouchersByCampaignId(campaignId);
    } else if (voucherId) {
        deleteCount = await voucherRepository.deleteVoucherById(voucherId);
    }

    return { deleteCount };
};
