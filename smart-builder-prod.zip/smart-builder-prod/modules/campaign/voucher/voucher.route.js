const express = require('express');
const router = express.Router();
const { createVouchers, listVoucher, deleteVouchers, downloadVoucherByCampaignId } = require('./voucher.controller');
const { authMiddleware, getUploadMiddleware, decryptIds } = require('../../../middlewares');

router.post('/:id/vouchers', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, getUploadMiddleware('memory', ['csv']), createVouchers);
router.get('/:id/vouchers', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, getUploadMiddleware('memory', ['csv']), listVoucher);
router.delete('/:id/vouchers', authMiddleware('CAMPAIGN-MANAGEMENT'), decryptIds, getUploadMiddleware('memory', ['csv']), deleteVouchers);
router.get(
    '/:id/vouchers/download/',
    authMiddleware('CAMAPAIGN-MANAGEMENT'),
    decryptIds,
    getUploadMiddleware('memory', ['csv']),
    downloadVoucherByCampaignId
);
router.delete(
    '/:id/vouchers/:voucherId',
    authMiddleware('CAMAPAIGN-MANAGEMENT'),
    decryptIds,
    getUploadMiddleware('memory', ['csv']),
    deleteVouchers
);

module.exports = router;
