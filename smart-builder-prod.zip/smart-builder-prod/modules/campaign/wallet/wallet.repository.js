const e = require('cors');
const { MESSAGES } = require('../../../configs');
const { Denomination, sequelize } = require('../../../database/models');

exports.createDenomination = async (denomination) => {
    let transaction;

    try {
        transaction = await sequelize.transaction();
        const existingDenomination = await Denomination.findOne({
            where: {
                campaignId: denomination.campaignId,
                value: denomination.value,
            },
            transaction: transaction,
        });
        if (existingDenomination) {
            throw new Error(MESSAGES.WALLET.denominationExists);
        }
        const createdDenomination = await Denomination.create(denomination, { transaction: transaction });

        await transaction.commit();

        return createdDenomination;
    } catch (error) {
        if (transaction) await transaction.rollback();
        throw error;
    }
};

exports.deletedDenomination = async (denomination) => {
    let transaction;

    try {
        transaction = await sequelize.transaction();
        const existingDenomination = await Denomination.findOne({
            where: {
                campaignId: denomination.campaignId,
                value: denomination.value,
            },
            transaction: transaction,
        });
        if (!existingDenomination) {
            throw new Error(MESSAGES.WALLET.denominationDoesNotExists);
        }
        // Perform the delete operation
        await existingDenomination.destroy({ transaction: transaction });
        await transaction.commit();
        return existingDenomination;
    } catch (error) {
        if (transaction) await transaction.rollback();
        throw error;
    }
};

exports.updatedDenomination = async (denomination, isRedemption) => {
    let transaction;
    try {
        transaction = await sequelize.transaction();
        const existingDenomination = await Denomination.findOne({
            where: {
                campaignId: denomination.campaignId,
                value: denomination.value,
            },
            transaction: transaction,
        });
        if (!existingDenomination) {
            throw new Error(MESSAGES.WALLET.denominationDoesNotExists);
        }
        // Update the count
        if (isRedemption) {
            if (existingDenomination.count < existingDenomination.redeemedCount) {
                throw new Error(MESSAGES.WALLET.denominationLimitReached);
            }
            if (existingDenomination.redeemedCount < existingDenomination.count) {
                existingDenomination.redeemedCount++;
                if (existingDenomination.count == existingDenomination.redeemedCount) {
                    existingDenomination.isRedeemable = false;
                }
            }
        }
        if (denomination.count) {
            if (denomination.count < existingDenomination.redeemedCount) {
                throw new Error(MESSAGES.WALLET.userAlreadyRedeemedMore);
            }
            existingDenomination.count = denomination.count;
        }

        await existingDenomination.save({ transaction: transaction });

        // Commit the transaction
        await transaction.commit();

        // Return the updated denomination
        return existingDenomination;
    } catch (error) {
        if (transaction) await transaction.rollback();
        throw error;
    }
};

exports.getWalletBalance = async (campaignId) => {
    const denominations = await Denomination.findAll({
        where: {
            campaignId: campaignId,
        },
    });

    const totalBalance = denominations.reduce((sum, denomination) => {
        return sum + denomination.value * denomination.count;
    }, 0);

    return totalBalance;
};

exports.getDenominationsByCampaignId = async (campaignId) => {
    const denominations = await Denomination.findAll({
        where: {
            campaignId: campaignId,
        },
        attributes: ['value', 'count'],
    });

    return denominations;
};

exports.getDenomDataByCampaignId = async (campaignId, denomination) => {
    const denominations = await Denomination.findOne({
        where: {
            campaignId: campaignId,
            value: denomination,
        },
    });

    return denominations;
};
