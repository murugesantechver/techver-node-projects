const { BadRequestException } = require('../../../../helpers/errorResponse');
const walletRepository = require('../wallet.repository');

module.exports = async (denomination, campaignId, isRedemption) => {
    denomination.campaignId = campaignId;
    try {
        const updatedDenomination = await walletRepository.updatedDenomination(denomination, isRedemption);
        return updatedDenomination;
    } catch (error) {
        throw new BadRequestException(error);
    }
};
