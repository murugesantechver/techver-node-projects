const { BadRequestException } = require('../../../../helpers/errorResponse');
const walletRepository = require('../wallet.repository');

module.exports = async (denomination, campaignId) => {
    denomination.campaignId = campaignId;
    try {
        const deletedDenomination = await walletRepository.deletedDenomination(denomination);
        return deletedDenomination;
    } catch (error) {
        throw new BadRequestException(error);
    }
};
