const { BadRequestException } = require('../../../../helpers/errorResponse');
const walletRepository = require('../wallet.repository');

module.exports = async (campaignId) => {
    try {
        const denomsList = await walletRepository.getDenominationsByCampaignId(campaignId);
        return denomsList;
    } catch (error) {
        throw new BadRequestException(error);
    }
};
