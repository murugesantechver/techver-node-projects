const { BadRequestException } = require('../../../../helpers/errorResponse');
const walletRepository = require('../wallet.repository');

module.exports = async (campaignId) => {
    const walletBalance = await walletRepository.getWalletBalance(campaignId);
    return walletBalance;
};
