const { MESSAGES } = require('../../../../configs');
const { pwsBadRequestException } = require('../../../../helpers/errorResponse');
const walletRepository = require('../wallet.repository');

module.exports = async (campaignId, denomination) => {
    const denomsList = await walletRepository.getDenomDataByCampaignId(campaignId, denomination);
    if (!denomsList) {
        throw new pwsBadRequestException(MESSAGES.WALLET.denominationDoesNotExists);
    }
    if (denomsList) {
        if (!denomsList.dataValues.isRedeemable) {
            throw new pwsBadRequestException(MESSAGES.WALLET.denominationLimitReached);
        } else {
            return true;
        }
    }
};
