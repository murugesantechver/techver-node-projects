const createDenomination = require('./createDenomination');
const listDenomination = require('./listDenominations');
const deleteDenomination = require('./deleteDenomination');
const updateDenomination = require('./updateDenomination');
const getBalance = require('./getWalletBalance');
const validateDenomsAvailability = require('./validateDenominationAvailability');

module.exports = {
    createDenomination,
    listDenomination,
    deleteDenomination,
    updateDenomination,
    getBalance,
    validateDenomsAvailability,
};
