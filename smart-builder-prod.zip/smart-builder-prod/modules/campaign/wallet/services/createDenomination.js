const { BadRequestException } = require('../../../../helpers/errorResponse');
const walletRepository = require('../wallet.repository');

module.exports = async (denomination, campaignId) => {
    denomination.campaignId = campaignId;
    try {
        const createdDenomination = await walletRepository.createDenomination(denomination);
        return createdDenomination;
    } catch (error) {
        throw new BadRequestException(error);
    }
};
