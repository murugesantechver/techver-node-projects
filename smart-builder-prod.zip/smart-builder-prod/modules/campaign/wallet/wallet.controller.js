const walletServices = require('./services');
const { response } = require('../../../helpers');
const { MESSAGES, LOGGER_CONFIG } = require('../../../configs');
const { logger } = require('../../../utilities');
const commonServices = require('../../common/services');

exports.addDenomination = async (req, res, next) => {
    const { id: campaignId } = req.params;
    // const { id: userId } = req.user;
    // const url = req.baseUrl + req.url;
    // const action = LOGGER_CONFIG.wallet.createDenomination.action;
    try {
        logger.info('Denomination Create Controller Function Initiated');
        const responsePayload = await walletServices.createDenomination(req.body, campaignId);
        logger.info('Denomination Create Function ended');
        // await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.WALLET.denominationAdd);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Denomination Create ended with exception');
        next(error);
    }
};

exports.deleteDenomination = async (req, res, next) => {
    const { id: campaignId } = req.params;
    // const { id: userId } = req.user;
    // const url = req.baseUrl + req.url;
    // const action = LOGGER_CONFIG.wallet.createDenomination.action;
    try {
        logger.info('Denomination Delete Controller Function Initiated');
        const responsePayload = await walletServices.deleteDenomination(req.body, campaignId);
        logger.info('Denomination Delete Function ended');
        // await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.WALLET.denominationDelete);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Denomination Delete ended with exception');
        next(error);
    }
};

exports.updateDenomination = async (req, res, next) => {
    const { id: campaignId } = req.params;
    // const { id: userId } = req.user;
    // const url = req.baseUrl + req.url;
    // const action = LOGGER_CONFIG.wallet.createDenomination.action;
    try {
        logger.info('Denomination Update Controller Function Initiated');
        const responsePayload = await walletServices.updateDenomination(req.body, campaignId, false);
        logger.info('Denomination Update Function ended');
        // await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.WALLET.denominationUpdated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Denomination Update ended with exception');
        next(error);
    }
};

exports.getWalletBalance = async (req, res, next) => {
    const { id: campaignId } = req.params;
    // const { id: userId } = req.user;
    // const url = req.baseUrl + req.url;
    // const action = LOGGER_CONFIG.wallet.createDenomination.action;
    try {
        logger.info('Wallet balance Controller Function Initiated');
        const responsePayload = await walletServices.getBalance(campaignId);
        logger.info('Wallet balance Function ended');
        // await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.WALLET.balanceFetched);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Wallet balance ended with exception');
        next(error);
    }
};

exports.listDenominations = async (req, res, next) => {
    const { id: campaignId } = req.params;
    // const { id: userId } = req.user;
    // const url = req.baseUrl + req.url;
    // const action = LOGGER_CONFIG.wallet.createDenomination.action;
    try {
        logger.info('Denomination Fetch Controller Function Initiated');
        const responsePayload = await walletServices.listDenomination('100', campaignId);
        logger.info('Denomination Fetch Function ended');
        // await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.WALLET.denomsFetched);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Denomination Fetch ended with exception');
        next(error);
    }
};
