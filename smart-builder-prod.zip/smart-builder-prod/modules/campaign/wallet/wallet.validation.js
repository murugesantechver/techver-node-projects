const Joi = require('joi');

exports.addDenominationValidator = {
    params: Joi.object().keys({
        id: Joi.string().required(),
    }),
    body: Joi.object().keys({
        value: Joi.number().integer().required(),
        count: Joi.number().integer().required(),
    }),
};

exports.deleteDenominationValidator = {
    params: Joi.object().keys({
        id: Joi.string().required(),
    }),
    body: Joi.object().keys({
        value: Joi.number().integer().required(),
    }),
};

exports.updateDenominationValidator = {
    params: Joi.object().keys({
        id: Joi.string().required(),
    }),
    body: Joi.object().keys({
        value: Joi.number().integer().required(),
        count: Joi.number().integer().required(),
    }),
};

exports.getbalanceValidator = {
    params: Joi.object().keys({
        id: Joi.string().required(),
    }),
};
