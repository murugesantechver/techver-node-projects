const express = require('express');
const router = express.Router();
const { authMiddleware, validationMiddleware, decryptIds } = require('../../../middlewares');
const {
    addDenominationValidator,
    getbalanceValidator,
    deleteDenominationValidator,
    updateDenominationValidator,
} = require('./wallet.validation');
const { addDenomination, deleteDenomination, updateDenomination, getWalletBalance, listDenominations } = require('./wallet.controller');
router.post('/:id/denomination', validationMiddleware(addDenominationValidator), decryptIds, addDenomination);
router.delete('/:id/denomination', validationMiddleware(deleteDenominationValidator), decryptIds, deleteDenomination);
router.put('/:id/denomination', validationMiddleware(updateDenominationValidator), decryptIds, updateDenomination);
router.get('/:id/balance', validationMiddleware(getbalanceValidator), decryptIds, getWalletBalance);
router.get('/:id/denomination', validationMiddleware(getbalanceValidator), decryptIds, listDenominations);

module.exports = router;
