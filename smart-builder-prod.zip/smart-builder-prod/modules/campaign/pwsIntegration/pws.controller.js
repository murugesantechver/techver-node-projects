const surveyServices = require('../survey/services');
const walletServices = require('../wallet/services');
const paymentServices = require('../payment/services');
const { response } = require('../../../helpers');
const { logger } = require('../../../utilities');
const { BadRequestException, pwsBadRequestException } = require('../../../helpers/errorResponse');
const { MESSAGES } = require('../../../configs');
const { decryptData, encryptData } = require('../../../helpers/encryption');
const pwsUtils = require('./utilities');

exports.pwsCreateSurvey = async (req, res, next) => {
    const { campaignId, voucherCode, mobileNumber } = req.params;
    try {
        logger.info('PWS Survey Create Controller Function Initiated');
        var files;
        let responsePayload;
        let uniqueId;
        const queryParams = {
            uniqueId,
        };
        const surveyData = {
            voucherCode,
            mobileNumber,
        };
        // TODO check if survey exists with same mobileNumber for a specific campaignId
        const doesSurveyExists = await surveyServices.doesSurveyExist(mobileNumber, campaignId);
        if (doesSurveyExists) {
            throw new pwsBadRequestException(MESSAGES.PWS.rewardRedeemed);
        }
        responsePayload = await surveyServices.createSurvey(surveyData, campaignId, queryParams, true, files, false);
        logger.info('PWS Survey Create Create Function ended');
        const surveyId = encryptData(responsePayload.id);
        const responseInFormat = await pwsUtils.pwsResponseUtils.createSuccessResponse(MESSAGES.PWS.voucherValid, surveyId);
        return response.pwsSuccess(res, responseInFormat);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('PWS Survey Create ended with exception');
        error.type = 'pwsError';
        next(error);
    }
};

exports.pwsSurveyPayment = async (req, res, next) => {
    try {
        logger.info('PWS Survey Payment Initiate Controller Function Initiated');
        const { campaignId, mobileNumber, paymentMode } = req.params;
        // getSurveyId using mobile number
        const surveyId = await surveyServices.getSurveyId(mobileNumber);
        if (!surveyId) {
            throw new pwsBadRequestException(MESSAGES.SURVEY.pwsSurveyIdNotFound);
        }
        const isPayableByDenomination = await walletServices.validateDenomsAvailability(campaignId, '10');
        if (!isPayableByDenomination) {
            throw new pwsBadRequestException(MESSAGES.WALLET.denominationLimitReached);
        }
        let paymentParams;
        if (isPayableByDenomination) {
            if (paymentMode == 'vpa') {
                paymentParams = {
                    skuNo: 'pay1',
                    amount: '10',
                };
            }
            if (paymentMode == 'phonePe') {
                paymentParams = {
                    skuNo: 'pay1',
                    amount: '10',
                };
            }
            let paymentData = {};
            // if (paymentMode == 'vpa') {
            //     let { vpa } = req.params;
            //     paymentData.vpa = vpa;
            // }
            // if (paymentMode == 'phonePe') {
            //     let { mobileNumber } = req.params;
            //     paymentData.mobileNumber = mobileNumber;
            // }
            paymentData.accountNumber = '4563564764563576';
            paymentData.ifscCode = 'RAZR0000001';
            await paymentServices.surveyPayment(paymentData, campaignId, surveyId, paymentParams, false);
        }
        const responseInFormat = await pwsUtils.pwsResponseUtils.createSuccessResponse(MESSAGES.PWS.paymentProcessing, surveyId);
        logger.info('PWS Survey Payment Initiate Function ended');
        return response.pwsSuccess(res, responseInFormat);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('PWS Survey Payment Initiate ended with exception');
        error.type = 'pwsError';
        next(error);
    }
};
