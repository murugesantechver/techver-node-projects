exports.createSuccessResponse = async (message, data) => {
    const responseData = {
        code: 200,
        status: 'success',
        type: 'text',
        data: `${message}`,
    };
    return responseData;
};
