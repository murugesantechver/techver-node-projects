const Joi = require('joi');
const { MESSAGES } = require('../../../configs');

exports.createPwsSurveyValidator = {
    params: Joi.object().keys({
        campaignId: Joi.string().required(),
        voucherCode: Joi.string().required(),
        mobileNumber: Joi.string()
            .length(12) // Total length, including country code
            .pattern(/^(91)[0-9]{10}$/) // Matches "91" followed by exactly 10 digits
            .required()
    }).messages({
        'string.pattern.base': 'Enter a valid mobile number. Only Indian mobile numbers are supported.',
        'string.length': 'Enter a valid mobile number with the country code. Only Indian mobile numbers are supported.',
        'any.required': 'Mobile number is required.'
    })
};
exports.initiatePwsPaymentValidator = {
    params: Joi.object().keys({
        campaignId: Joi.string().required(),
        paymentMode: Joi.string().valid('vpa', 'phonePe').required(),
        mobileNumber: Joi.string()
            .length(12) // Total length, including country code
            .pattern(/^(91)[0-9]{10}$/) // Matches "91" followed by exactly 10 digits
            .required(),
        paymentParam: Joi.when('paymentMode', {
            is: 'vpa',
            then: Joi.string()
                .trim()
                .regex(/^[\w.@]+$/)
                .prefs({ convert: true })
                .label('UPI ID')
                .required()
                .messages({
                    'string.pattern.base': MESSAGES.SURVEY.upiIdValidation,
                }),
            otherwise: Joi.string().allow('').optional(),
        }),
    }).messages({
        'string.pattern.base': 'Enter a valid mobile number. Only Indian mobile numbers are supported.',
        'string.length': 'Enter a valid mobile number with the country code. Only Indian mobile numbers are supported.',
        'any.required': 'Mobile number is required.',
    })
};
