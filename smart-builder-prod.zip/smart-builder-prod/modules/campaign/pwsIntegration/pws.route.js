const express = require('express');
const router = express.Router();
const { pwsCreateSurvey, pwsSurveyPayment } = require('./pws.controller');
const { decryptIds, pwsValidationMiddleware, pwsWhitelist } = require('../../../middlewares');
const { createPwsSurveyValidator, initiatePwsPaymentValidator } = require('./pws.validation');
const OAuthServer = require('express-oauth-server');
const OAuthRepository = require('../../auth/oauth2.repository');
// Payment Routes Just Use for Testing Purpose
router.oauth = new OAuthServer({
    model: OAuthRepository,
});
router.post('/survey/:campaignId/:voucherCode/:mobileNumber', pwsValidationMiddleware(createPwsSurveyValidator), decryptIds, pwsCreateSurvey);
router.post('/payment/:campaignId/:paymentMode/:mobileNumber/:paymentParam?', pwsValidationMiddleware(initiatePwsPaymentValidator), decryptIds, pwsSurveyPayment);

module.exports = router;
