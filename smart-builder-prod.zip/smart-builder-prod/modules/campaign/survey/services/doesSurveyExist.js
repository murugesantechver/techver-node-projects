const surveyRepository = require('../survey.repository');
const { Op } = require('sequelize');

module.exports = async (mobileNumber, campaignId) => {
    const checks = [{ campaignId: { [Op.eq]: campaignId } }, { mobileNumber: { [Op.eq]: mobileNumber } }];
    const value = await surveyRepository.checkIfRefnoExists(checks);
    if (!value?.id) {
        return false;
    }
    return true;
};
