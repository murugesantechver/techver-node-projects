const surveyRepository = require('../survey.repository');
const { Op } = require('sequelize');

module.exports = async (mobileNumber) => {
    const checks = [{ mobileNumber: { [Op.eq]: mobileNumber } }];
    const value = await surveyRepository.checkIfRefnoExists(checks);
    if (!value?.id) {
        return false;
    }
    return value.id;
};
