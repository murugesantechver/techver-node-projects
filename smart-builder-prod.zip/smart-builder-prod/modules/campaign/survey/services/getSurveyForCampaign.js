const { MESSAGES } = require('../../../../configs');
const { decryptData } = require('../../../../helpers/encryption');
const { BadRequestException, UnauthorizedException } = require('../../../../helpers/errorResponse');
const surveyRepository = require('../survey.repository');
const campaignRepository = require('../../campaignManagement/campaign.repository');
const inviteeRepository = require('../../invitee/invitee.repository');
const voucherRepository = require('../../voucher/voucher.repository');
const { Op } = require('sequelize');
const { date } = require('../../../../utilities');

module.exports = async (id, { page, limit, startDate, endDate }) => {
    const checks = [{ id: { [Op.eq]: id } }];
    const doesCampaignExists = await campaignRepository.checkCampaignExists(checks);
    if (!doesCampaignExists) throw new BadRequestException(MESSAGES.CAMPAIGN.campaignDoesNotExist);
    let dateCheck;
    if (startDate && endDate) {
        dateCheck = [{ campaignId: { [Op.eq]: id }, createdAt: { [Op.between]: [startDate, endDate] } }];
    } else {
        dateCheck = [{ campaignId: { [Op.eq]: id } }];
    }
    const surveyData = await surveyRepository.getSurveyDetailsForCampaign(dateCheck, page, limit);

    let campaignMetrics = {};
    const { totalInvitees, participatedPersons } = await inviteeRepository.getInviteeMetricsForCampaign(id);
    const { totalVouchers, totalRedeemed } = await voucherRepository.getVoucherMetricsForCampaign(id);

    campaignMetrics.totalInvitees = totalInvitees;
    campaignMetrics.participatedPersons = participatedPersons == null ? 0 : participatedPersons;
    campaignMetrics.totalVouchers = totalVouchers;
    campaignMetrics.totalRedeemed = totalRedeemed == null ? 0 : totalRedeemed;

    if (surveyData) {
        const reports = surveyData.map((survey) => {
            const decryptedSurvey = { ...survey };
            Object.keys(decryptedSurvey).forEach((key) => {
                if (
                    key !== 'id' &&
                    key !== 'campaignId' &&
                    key !== 'Surveyimages' &&
                    key !== 'updatedAt' &&
                    key !== 'createdAt' &&
                    key !== 'inviteePhone' &&
                    key !== 'voucherUsed' &&
                    key !== 'orderId' &&
                    key !== 'mobileNumber'
                ) {
                    decryptedSurvey[key] = decryptData(decryptedSurvey[key]);
                }
                if (key == 'updatedAt') {
                    decryptedSurvey[key] = date.formatDate(decryptedSurvey[key]);
                }
                if (key == 'createdAt') {
                    decryptedSurvey[key] = date.formatDate(decryptedSurvey[key]);
                }
            });
            return decryptedSurvey;
        });
        return { reports, campaignMetrics };
    }
    let reports = [];
    return { reports, campaignMetrics };
};
