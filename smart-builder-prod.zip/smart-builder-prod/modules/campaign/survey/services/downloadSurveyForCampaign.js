const { decryptData } = require('../../../../helpers/encryption');
const surveyRepository = require('../survey.repository');
const { Op } = require('sequelize');
const { date, csvUtils } = require('../../../../utilities');

module.exports = async (id, { startDate, endDate }) => {
    let page = 1;
    let limit = 100;
    let dateCheck;
    if (startDate && endDate) {
        dateCheck = [{ campaignId: { [Op.eq]: id }, createdAt: { [Op.between]: [startDate, endDate] } }];
    }
    const surveyData = await surveyRepository.getSurveyDetailsForCampaign(dateCheck, page, limit);

    if (surveyData) {
        const reports = surveyData.map((survey) => {
            const decryptedSurvey = { ...survey };
            Object.keys(decryptedSurvey).forEach((key) => {
                if (
                    key !== 'id' &&
                    key !== 'campaignId' &&
                    key !== 'Surveyimages' &&
                    key !== 'updatedAt' &&
                    key !== 'createdAt' &&
                    key !== 'inviteePhone' &&
                    key !== 'voucherUsed' &&
                    key !== 'orderId'
                ) {
                    decryptedSurvey[key] = decryptData(decryptedSurvey[key]);
                }
                if (key == 'updatedAt') {
                    decryptedSurvey[key] = date.formatDate(decryptedSurvey[key]);
                }
                if (key == 'createdAt') {
                    decryptedSurvey[key] = date.formatDate(decryptedSurvey[key]);
                }
            });

            return decryptedSurvey;
        });
        const reportUrl = await csvUtils.convertArrayToCsvFile(reports, id, 'survey');
        return { reportUrl };
    }
};
