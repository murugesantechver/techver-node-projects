const { MESSAGES } = require('../../../../configs');
const { decryptData, encryptData } = require('../../../../helpers/encryption');
const { BadRequestException, UnauthorizedException, pwsBadRequestException } = require('../../../../helpers/errorResponse');
const campaignRepository = require('../../campaignManagement/campaign.repository');
const inviteeRepository = require('../../invitee/invitee.repository');
const voucherRepository = require('../../voucher/voucher.repository');
const surveyRepository = require('../survey.repository');
const { Op } = require('sequelize');

module.exports = async (data, id, { uniqueId }, create, files, isEncrypted) => {
    const mandatoryFields = await campaignRepository.findMandatoryFieldsById(id);
    const filesCompare = mandatoryFields
        .filter((field) => field.requireFileUpload)
        .map((field) => ({
            fieldName: `${field.fieldName}`,
        }));
    if (isEncrypted) {
        if (files?.length > 0) {
            const fieldNameFound = filesCompare.some((compareField) => {
                return files.some((file) => file.imageType === compareField.fieldName);
            });
            if (!fieldNameFound) throw new BadRequestException(MESSAGES.SURVEY.fileFieldsNotProvided);
            const extraFields = files.filter((file) => {
                return !filesCompare.some((compareField) => compareField.fieldName === file.imageType);
            });
            if (!extraFields) throw new BadRequestException(MESSAGES.SURVEY.extraFieldsNotSupported);
        }
    }

    const checks = [{ id: { [Op.eq]: id } }];
    const isCampaignActive = await campaignRepository.checkCampaignExists(checks);
    if (!isCampaignActive) {
        //TODO isEncrypted
        if (!isEncrypted) {
            throw new pwsBadRequestException(MESSAGES.CAMPAIGN.offerEnded);
        } else {
            throw new BadRequestException(MESSAGES.CAMPAIGN.notFound);
        }
    }
    if (isEncrypted) {
        if (isCampaignActive) {
            if (!isCampaignActive.publish) throw new BadRequestException(MESSAGES.CAMPAIGN.notPublished);
            if (!isCampaignActive.isActive) throw new BadRequestException(MESSAGES.CAMPAIGN.campaignNotActive);
            if (isCampaignActive.status) {
                if (isCampaignActive.status === 'COMPLETED') throw new BadRequestException(MESSAGES.CAMPAIGN.campaignEnded);
                if (isCampaignActive.status === 'UPCOMING') throw new BadRequestException(MESSAGES.CAMPAIGN.campaignNotStarted);
            }
        }
    }

    const doesCampaignHaveInvitee = await inviteeRepository.findAllInviteesByCampaignId(id, 1, 1); // Passing page limits
    let mobileNumber;
    let voucherCode;
    if (isEncrypted) {
        mobileNumber = decryptData(data.mobileNumber);
        voucherCode = decryptData(data.voucherCode);
    } else {
        mobileNumber = data.mobileNumber;
        voucherCode = data.voucherCode;
    }
    let attempts;
    let participated = false;
    if (isEncrypted) {
        if (doesCampaignHaveInvitee.count > 0) {
            const campaignAttempts = isCampaignActive.inviteeAttempts;
            //check if req invitees are part of the doescampaignInvitees list
            // if they are part of the list, add them to the invitees list as participated true
            // if they are not part of the list throw error
            if (mobileNumber) {
                const checks = [{ phone: { [Op.eq]: mobileNumber } }];
                const isInviteePartOfCampaign = await inviteeRepository.checkInviteeExists(checks);
                if (!isInviteePartOfCampaign) {
                    throw new UnauthorizedException(MESSAGES.CAMPAIGN.notAinvitee);
                }
                if (isInviteePartOfCampaign) {
                    if (campaignAttempts === isInviteePartOfCampaign.attempts) {
                        participated = true;
                        throw new BadRequestException(MESSAGES.CAMPAIGN.inviteeMaxAttemptsReached);
                    } else {
                        participated = false;
                        attempts = isInviteePartOfCampaign.attempts + 1;
                        if (attempts === campaignAttempts) {
                            participated = true;
                        }
                    }
                    if (isInviteePartOfCampaign.status === 'DISABLED') {
                        throw new UnauthorizedException(MESSAGES.CAMPAIGN.inviteeAlreadyParticipated);
                    }
                }
            }
        }
    }
    const doesCampaignHaveVoucher = await voucherRepository.findAllVouchersByCampaignId(id, 1, 1);
    if (voucherCode) {
        if (!doesCampaignHaveVoucher.count > 0) {
            //TODO isEncrypted
            if (!isEncrypted) {
                throw new pwsBadRequestException(MESSAGES.CAMPAIGN.VoucherNotValid);
            } else {
                throw new BadRequestException(MESSAGES.CAMPAIGN.VoucherNotValid);
            }
        }
        // if()
        //Check if the received voucher is part of vouchers list
        // if they are part of the list, check if there has been any redemptions made on that voucher
        // If there are no redemptions made on the voucher, Process payment for the voucher
        if (doesCampaignHaveVoucher) {
            const isVoucherProvidedValid = await voucherRepository.findVoucherByName(voucherCode);
            if (isVoucherProvidedValid) {
                if (isVoucherProvidedValid.status === 'REDEEMED') {
                    //TODO isEncrypted
                    if (!isEncrypted) {
                        throw new pwsBadRequestException(MESSAGES.CAMPAIGN.voucherRedeemed);
                    } else {
                        throw new BadRequestException(MESSAGES.CAMPAIGN.voucherRedeemed);
                    }
                }
            } else {
                //TODO isEncrypted
                if (!isEncrypted) {
                    throw new pwsBadRequestException(MESSAGES.CAMPAIGN.incorrectVoucherCode);
                } else {
                    throw new BadRequestException(MESSAGES.CAMPAIGN.incorrectVoucherCode);
                }
            }
        } else {
            //TODO isEncrypted
            if (!isEncrypted) {
                throw new pwsBadRequestException(MESSAGES.CAMPAIGN.incorrectVoucherCode);
            } else {
                throw new BadRequestException(MESSAGES.CAMPAIGN.incorrectVoucherCode);
            }
        }
    }
    if (create) {
        data.campaignId = id;
        if (isEncrypted) {
            data.mobileNumber = decryptData(data.mobileNumber);
        }
        if (!isEncrypted) {
            data.voucherCode = encryptData(data.voucherCode);
        }
        const survey = await surveyRepository.createSurvey(data);
        //TODO isEncrypted
        if (isEncrypted) {
            if (!mobileNumber && uniqueId) {
                const checks = [{ campaignId: { [Op.eq]: id }, uniqueId: { [Op.eq]: uniqueId } }];
                const update = {
                    isRedeemed: true,
                };
                await campaignRepository.updateUniqueIdStatus(update, checks);
            }
            if (doesCampaignHaveInvitee.count > 0 && mobileNumber) {
                let status = 'ACTIVE';
                if (participated == true) {
                    status = 'DISABLED';
                }
                const inviteeUpdate = await inviteeRepository.changeInviteeStatus(status, attempts, participated, mobileNumber);
                if (!inviteeUpdate) {
                    throw new BadRequestException(MESSAGES.CAMPAIGN.inviteeUpdateFailed);
                }
                const checks = [{ campaignId: { [Op.eq]: id }, uniqueId: { [Op.eq]: uniqueId } }];
                const update = {
                    isRedeemed: true,
                    inviteePhone: mobileNumber,
                };
                await campaignRepository.updateUniqueIdStatus(update, checks);
            }
        }
        if (doesCampaignHaveVoucher.count > 0) {
            if (voucherCode) {
                const voucherUpdate = await voucherRepository.changeVoucherStatus('REDEEMED', voucherCode);
                //TODO isEncrypted
                if (isEncrypted) {
                    if (!voucherUpdate) {
                        throw new BadRequestException(MESSAGES.CAMPAIGN.voucherUpdateFailed);
                    }
                }
            }
        }
        if (survey?.id) {
            if (files?.length > 0) {
                const surveyId = survey.id;
                const filesWithSurveyId = files.map((file) => ({
                    ...file,
                    surveyId: surveyId,
                }));
                await surveyRepository.addSurveyImages(filesWithSurveyId);
            }
            const updateData = {
                voucherUsed: voucherCode ? voucherCode : 'No Voucher Used',
                inviteePhone: mobileNumber ? mobileNumber : 'No Mobile Number',
            };
            await surveyRepository.updateSurvey(survey.id, updateData);
        }
        return {
            id: survey.id,
        };
    }
    return true;
};
