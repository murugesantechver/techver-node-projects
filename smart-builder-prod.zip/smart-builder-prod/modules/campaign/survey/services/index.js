const createSurvey = require('./createSurvey');
const getSurveyForCampaign = require('./getSurveyForCampaign');
const downloadSurveyForCampaign = require('./downloadSurveyForCampaign');
const getSurveyId = require('./getSurveyIdentifier');
const doesSurveyExist = require('./doesSurveyExist');

module.exports = {
    createSurvey,
    getSurveyForCampaign,
    downloadSurveyForCampaign,
    getSurveyId,
    doesSurveyExist,
};
