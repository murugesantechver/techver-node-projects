const { Survey, Surveyimages } = require('../../../database/models');
const { Op } = require('sequelize');

exports.createSurvey = async (survey, t = null) => {
    return await Survey.create(survey, { transaction: t });
};

exports.surveyExists = async (checks) => {
    return await Survey.findOne({
        where: {
            [Op.or]: checks,
        },
        attributes: ['id', 'paymentStatus'],
    });
};

exports.addSurveyImages = async (imageDataArray, t = null) => {
    return await Surveyimages.bulkCreate(imageDataArray, { transaction: t });
};

exports.getSurveyDetailsForCampaign = async (checks, page, limit) => {
    const { count, rows } = await Survey.findAndCountAll({
        where: {
            [Op.or]: checks,
        },
        offset: (page - 1) * limit,
        limit,
        distinct: true,
        attributes: { exclude: ['updatedAt', 'campaignId'] },
    });
    if (count === 0) {
        return null;
    }
    const surveyDataProcessed = rows.map((survey) => survey.toJSON());
    const processedFilteredData = surveyDataProcessed.map((surveyData) =>
        Object.fromEntries(Object.entries(surveyData).filter(([_, value]) => value !== null))
    );

    return processedFilteredData;
};

exports.updateSurvey = async (id, surveyUpdate, t = null) => {
    const isUpdated = await Survey.update(surveyUpdate, { where: { id }, transaction: t });
    if (isUpdated[0] === 1) {
        return true;
    }
    return false;
};

exports.updateOrder = async (orderId, orderUpdateData, t = null) => {
    const isUpdated = await Survey.update(orderUpdateData, { where: { orderId: orderId }, transaction: t });
    if (isUpdated[0] === 1) {
        return true;
    }
    return false;
};

exports.checkIfOrderExists = async (checks) => {
    return await Survey.findOne({
        where: {
            [Op.or]: checks,
        },
        attributes: ['orderId', 'paymentStatus', 'beneficiaryId'],
    });
};

exports.checkIfRefnoExists = async (checks) => {
    return await Survey.findOne({
        where: {
            [Op.and]: checks,
        },
        attributes: ['id'],
    });
};
