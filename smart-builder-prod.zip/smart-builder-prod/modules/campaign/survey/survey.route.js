const express = require('express');
const router = express.Router();
const { createSurvey, validateSurvey, fetchSurveyReportForCampaign, downloadSurveyReportForCampaign } = require('./survey.controller');
const { decryptIds, campaignValidationMiddleware, surveyFileUploader, authMiddleware } = require('../../../middlewares');

router.post('/:id/survey', decryptIds, surveyFileUploader('disk', ['jpg', 'png', 'jpeg']), campaignValidationMiddleware(), createSurvey);
router.post(
    '/:id/survey/validate',
    decryptIds,
    surveyFileUploader('disk', ['jpg', 'png', 'jpeg']),
    campaignValidationMiddleware(),
    validateSurvey
);
router.get('/:id/survey/report', authMiddleware('SURVEY-REPORTING'), decryptIds, fetchSurveyReportForCampaign);
router.get('/:id/survey/download', authMiddleware('SURVEY-REPORTING'), decryptIds, downloadSurveyReportForCampaign);

module.exports = router;
