const surveyServices = require('./services');
const paymentServices = require('../payment/services');
const { response } = require('../../../helpers');
const { MESSAGES, LOGGER_CONFIG } = require('../../../configs');
const { logger } = require('../../../utilities');
const { decryptData } = require('../../../helpers/encryption');
const campaignRepository = require('../campaignManagement/campaign.repository');
const { Op } = require('sequelize');
const { BadRequestException } = require('../../../helpers/errorResponse');
const commonServices = require('../../common/services');
const walletServices = require('../wallet/services');

exports.createSurvey = async (req, res, next) => {
    const { id } = req.params;
    const { type, uniqueId } = req.query;
    try {
        if (uniqueId) {
            const checks = [{ campaignId: { [Op.eq]: id }, uniqueId: { [Op.eq]: uniqueId } }];
            const doesUniqueIdExist = await campaignRepository.doesUniqueIdsExists(checks);
            if (!doesUniqueIdExist) {
                throw new BadRequestException(MESSAGES.SURVEY.uniqueIdIncorrect);
            }
            if (doesUniqueIdExist) {
                if (doesUniqueIdExist.isRedeemed) throw new BadRequestException(MESSAGES.SURVEY.uniqueIdUsedAlready);
            }
        }
        var files;

        if (req.files) {
            const filesMap = {};

            for (const fieldName in req.files) {
                const files = req.files[fieldName];

                files.forEach((file) => {
                    const fieldNameWithoutFile = fieldName.replace(/File$/, '');
                    const imageUrl = `http://localhost:4000/files/${file.filename}`;
                    if (!filesMap[fieldNameWithoutFile]) {
                        filesMap[fieldNameWithoutFile] = {
                            imageType: fieldNameWithoutFile,
                            imageUrl: {},
                        };
                    }

                    const index = Object.keys(filesMap[fieldNameWithoutFile].imageUrl).length + 1;
                    filesMap[fieldNameWithoutFile].imageUrl[index] = imageUrl;
                });
            }

            files = Object.values(filesMap);
            // 'files' array now contains objects with 'fieldName' and 'imageUrl'
        }
        logger.info('Survey Controller Function Initiated');
        let responsePayload;
        if (type === 'survey') {
            const queryParams = {
                type,
                uniqueId,
            };
            responsePayload = await surveyServices.createSurvey(req.body, id, queryParams, true, files);
            logger.info('Survey Create Function ended');
        } else if (type === 'payment') {
            // Check if the amount is part of denominations for the specific campaign
            // if denomination limit is reached directly stop the specific payment
            const { surveyId, skuNo, amount } = req.query;

            const isPayableByDenomination = await walletServices.validateDenomsAvailability(id, amount ? amount : '10');
            if (!isPayableByDenomination) {
                throw new BadRequestException(MESSAGES.WALLET.denominationLimitReached);
            }
            if (isPayableByDenomination) {
                const paymentParams = {
                    skuNo: skuNo ? skuNo : 'pay1',
                    amount: amount ? amount : '10',
                };
                responsePayload = await paymentServices.surveyPayment(req.body, id, decryptData(surveyId), paymentParams, true);
            }

            logger.info('Survey Payment Function ended');
        }
        return response.success(res, responsePayload, MESSAGES.SURVEY.surveyCreated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Survey Create ended with exception');
        next(error);
    }
};

exports.validateSurvey = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.SURVEY.validate.action;
    const { id } = req.params;
    try {
        logger.info('Survey Validate Controller Function Initiated');
        const responsePayload = await surveyServices.createSurvey(req.body, id, false);
        logger.info('Survey Validate Function ended');
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, MESSAGES.SURVEY.fieldsValidated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Survey Validate ended with exception');
        next(error);
    }
};

exports.fetchSurveyReportForCampaign = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.SURVEY.report.action;
    const { id } = req.params;
    const page = req.query.page || 1;
    const limit = parseInt(req.query.limit) || 100;
    const startDate = req.query.startDate || null;
    const endDate = req.query.endDate || null;
    const queryParams = {
        page,
        limit,
        startDate,
        endDate,
    };

    try {
        logger.info('Survey Validate Controller Function Initiated');
        const responsePayload = await surveyServices.getSurveyForCampaign(id, queryParams);
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, next);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Fetch Survey Report ended with exception');
        next(error);
    }
};

exports.downloadSurveyReportForCampaign = async (req, res, next) => {
    const { id: userId } = req.user;
    const url = req.baseUrl + req.url;
    const action = LOGGER_CONFIG.SURVEY.download.action;
    const { id } = req.params;
    const page = req.query.page || 1;
    const limit = parseInt(req.query.limit) || 100;
    const startDate = req.query.startDate || null;
    const endDate = req.query.endDate || null;
    const queryParams = {
        page,
        limit,
        startDate,
        endDate,
    };
    try {
        logger.info('Survey Download Controller Function Initiated');
        const responsePayload = await surveyServices.downloadSurveyForCampaign(id, queryParams);
        await commonServices.auditLogs(action, url, userId);
        return response.success(res, responsePayload, next);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Survey Download Controller Function ended with exception');
        next(error);
    }
};
