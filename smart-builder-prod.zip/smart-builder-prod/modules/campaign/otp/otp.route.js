const express = require('express');
const router = express.Router();
const { decryptIds, validationMiddleware } = require('../../../middlewares');
const { sendOTP, verifyOTP } = require('./otp.controller');
const { verifyOTPValidator, generateOTPValidator } = require('./otp.validation');

router.post('/:id/otp/generate', decryptIds, validationMiddleware(generateOTPValidator), sendOTP);
router.post('/:id/otp/verify', decryptIds, validationMiddleware(verifyOTPValidator), verifyOTP);

module.exports = router;
