const optServices = require('./services');
const { response } = require('../../../helpers');
const { logger } = require('../../../utilities');
const { MESSAGES } = require('../../../configs');

exports.sendOTP = async (req, res, next) => {
    const { id } = req.params;
    try {
        logger.info('OTP Generate Controller Function Initiated');
        const responsePayload = await optServices.generateAndSendOTP(req.body, id);
        logger.info('OTP Generate Function ended');

        return response.success(res, responsePayload, MESSAGES.OTP.otpSend);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('OTP Generate ended with exception');
        next(error);
    }
};

exports.verifyOTP = async (req, res, next) => {
    const { id } = req.params;
    try {
        logger.info('OTP Verify Controller Function Initiated');
        const responsePayload = await optServices.verifyOTP(req.body, id);
        logger.info('OTP Verify Controller Function Ended');
        return response.success(res, responsePayload, MESSAGES.OTP.otpVerified);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('OTP Verify ended with exception');
        next(error);
    }
};
