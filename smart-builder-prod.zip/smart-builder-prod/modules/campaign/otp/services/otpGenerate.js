const otpRepository = require('../otp.repository');
const voucherRepository = require('../../voucher/voucher.repository');
const companyRepository = require('../../../company/company.repository');
const campaignRepository = require('../../campaignManagement/campaign.repository');
const { BadRequestException, ErrorResponse } = require('../../../../helpers/errorResponse');
const { otp } = require('../../../../utilities');
const { CONSTANTS, MESSAGES } = require('../../../../configs');
const { Op } = require('sequelize');

module.exports = async (data, id) => {
    const { mobileNumber, voucherCode } = data;
    const updatedMobileNumber = `91${mobileNumber}`;
    const expirationMinutes = CONSTANTS.OTP.expiryMinutes || 5;
    const checks = [{ id: { [Op.eq]: id } }];
    if (id) {
        const doesCampaignExists = await campaignRepository.checkCampaignExists(checks);
        if (!doesCampaignExists) throw new BadRequestException(MESSAGES.CAMPAIGN.campaignDoesNotExist);
    } else {
        throw new BadRequestException(MESSAGES.CAMPAIGN.campaignIdNotProvided);
    }
    if (voucherCode) {
        const isVoucherRedeemedOrExists = await voucherRepository.findVoucherByCampaignId(id, voucherCode);
        if (!isVoucherRedeemedOrExists) {
            throw new BadRequestException(MESSAGES.CAMPAIGN.VoucherNotValid);
        }
        if (isVoucherRedeemedOrExists) {
            if (isVoucherRedeemedOrExists.status === 'REDEEMED') {
                throw new BadRequestException(MESSAGES.CAMPAIGN.voucherRedeemed);
            }
        }
    }
    let { expired, exists } = await otpRepository.checkOTPExpiry(updatedMobileNumber, id, expirationMinutes);
    const { clientData } = await otpRepository.getCompanyname(id);
    let companyName;
    if (clientData) {
        companyName = await companyRepository.findCompanyById(clientData.companyId);
    } else {
        companyName = 'Smart Builder';
    }
    if (!exists) {
        const randomOtp = await otp.generate();
        await otpRepository.addOTPForPhone({
            campaignId: id,
            mobileNumber: updatedMobileNumber,
            otp: randomOtp,
            timestamp: new Date(),
        });
        await otp.sendOtpToPhone(updatedMobileNumber, randomOtp, companyName);
        return {
            expiresIn: `${expirationMinutes} Minutes`,
        };
    } else if (exists && expired) {
        const randomOtp = await otp.generate();
        const update = await otpRepository.updateOTPForPhone({
            campaignId: id,
            mobileNumber: updatedMobileNumber,
            otp: randomOtp,
            timestamp: new Date(),
        });
        if (update) {
            await otp.sendOtpToPhone(updatedMobileNumber, randomOtp, companyName);
            return {
                expiresIn: `${expirationMinutes} Minutes`,
            };
        } else {
            throw new ErrorResponse(MESSAGES.OTP.errorSending);
        }
    } else if (exists && !expired) {
        throw new BadRequestException(MESSAGES.OTP.alreadyRequested);
    }
};
