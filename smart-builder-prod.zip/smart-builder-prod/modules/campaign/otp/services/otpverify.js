const otpRepository = require('../otp.repository');
const { ErrorResponse } = require('../../../../helpers/errorResponse');
const { MESSAGES } = require('../../../../configs');

module.exports = async (data, id) => {
    const { mobileNumber, otp } = data;
    const updatedMobileNumber = `91${mobileNumber}`;

    const { expired, valid } = await otpRepository.verifyOTP(updatedMobileNumber, id, otp);
    if (expired) throw new ErrorResponse(MESSAGES.OTP.otpExpired);
    if (!valid) throw new ErrorResponse(MESSAGES.OTP.incorrectOTP);
    return true;
};
