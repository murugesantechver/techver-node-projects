const generateAndSendOTP = require('./otpGenerate');
const verifyOTP = require('./otpverify');

module.exports = {
    generateAndSendOTP,
    verifyOTP,
};
