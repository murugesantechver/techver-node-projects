const { Otp, Campaign, User } = require('../../../database/models');
const { BadRequestException } = require('../../../helpers/errorResponse');

// const expirationMinutes = CONSTANTS.OTP.expiryMinutes || 5;

exports.addOTPForPhone = async (details, t = null) => {
    return await Otp.create(details, { transaction: t });
};

exports.updateOTPForPhone = async (details, t = null) => {
    const { mobileNumber } = details;
    const isUpdated = await Otp.update(details, { where: { mobileNumber }, transaction: t });
    if (isUpdated[0] === 1) {
        return true;
    }
    return {};
};

exports.verifyOTP = async (mobileNumber, campaignId, enteredOTP) => {
    let otpStatus = {
        expired: false,
        valid: true,
    };
    const otp = await Otp.findOne({
        where: {
            mobileNumber,
            campaignId,
        },
        attributes: ['id', 'otp', 'timestamp'],
    });

    if (!otp) {
        throw new BadRequestException('OTP not found, Request a new OTP');
    }

    // const expirationTime = new Date(otp.timestamp.getTime() + expirationMinutes * 60000); // Add expirationMinutes in milliseconds
    // const currentTime = new Date();

    // if (currentTime > expirationTime) {
    //     console.log('Curent Time', currentTime);
    //     console.log('Expiration Time', expirationTime);
    //     otpStatus.expired = true;
    //     otpStatus.valid = false;
    //     return otpStatus;
    // }
    if (otp.otp !== enteredOTP) {
        throw new BadRequestException('Invalid OTP.');
    }

    // OTP is valid
    return otpStatus;
};

exports.findOtpByPhone = async (mobileNumber, campaignId) => {
    return await Otp.findOne({
        where: {
            mobileNumber,
            campaignId,
        },
        attributes: ['id', 'otp'],
    });
};

exports.deleteOTPByPhonenumberAndCampaign = async (mobileNumber, campaignId) => {
    return await Otp.destroy({
        where: {
            campaignId: campaignId,
            mobileNumber: mobileNumber,
        },
    });
};

exports.getCompanyname = async (campaignId) => {
    return await Campaign.findByPk(campaignId, {
        include: {
            model: User,
            as: 'ownerData', // This should match the 'as' value defined in the Campaign model association
            attributes: ['companyId'], // Only include the companyName attribute from the client model
        },
        attributes: [], // Exclude all attributes from the Campaign model
    });
};

exports.checkOTPExpiry = async (mobileNumber, campaignId) => {
    let otpStatus = {
        expired: false,
        exists: false,
    };
    const otp = await Otp.findOne({
        where: {
            mobileNumber,
            campaignId,
        },
        attributes: ['id', 'otp', 'timestamp'],
    });
    if (otp?.otp) {
        otpStatus.exists = true;
        otpStatus.expired = true;
        return otpStatus; // OTP does not exist
    }

    // const expirationTime = Number(new Date(otp.timestamp.getTime() + expirationMinutes * 60000)); // Add expirationMinutes in milliseconds
    // const currentTime = Number(new Date());
    // const differenceInMinutes = Math.ceil((expirationTime - currentTime) / (1000 * 60));
    // console.log('Time remaining:', differenceInMinutes, 'minutes');

    // if (differenceInMinutes >= 0 || differenceInMinutes >= -1) {
    //     otpStatus.exists = true;
    //     otpStatus.expired = true;
    //     return otpStatus; // OTP is expired
    // }

    return otpStatus; // OTP exists and is not expired
};
