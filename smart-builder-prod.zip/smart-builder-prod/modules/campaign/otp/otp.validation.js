const Joi = require('joi');

exports.generateOTPValidator = {
    body: Joi.object().keys({
        mobileNumber: Joi.string()
            .length(10) // The total length should be 10 digits
            .pattern(/^[0-9]{10}$/) // Matches a string consisting of exactly 10 digits
            .required(),
        voucherCode: Joi.string().trim().alphanum().optional(),
    }),
};

exports.verifyOTPValidator = {
    body: Joi.object().keys({
        otp: Joi.string()
            .length(4)
            .pattern(/^[0-9]+$/)
            .required(),
        mobileNumber: Joi.string()
            .length(10) // The total length should be 10 digits
            .pattern(/^[0-9]{10}$/) // Matches a string consisting of exactly 10 digits
            .required(),
    }),
};
