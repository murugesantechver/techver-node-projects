const express = require('express');
const router = express.Router();
const { surveyPayment } = require('./payment.controller');
const { decryptIds, campaignValidationMiddleware } = require('../../../middlewares');
const OAuthServer = require('express-oauth-server');
const OAuthRepository = require('../../auth/oauth2.repository');
// Payment Routes Just Use for Testing Purpose
router.oauth = new OAuthServer({
    model: OAuthRepository,
});
router.post(':id', router.oauth.authenticate(), decryptIds, campaignValidationMiddleware(), surveyPayment);
router.get('/secret', router.oauth.authenticate(), function (req, res) {
    res.json('Secret Area');
});

module.exports = router;
