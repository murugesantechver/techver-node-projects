const paymentServices = require('./services');
const { response } = require('../../../helpers');
const { MESSAGES } = require('../../../configs');
const { logger } = require('../../../utilities');

exports.surveyPayment = async (req, res, next) => {
    const { id } = req.params;
    const { surveyId } = req.query;
    try {
        logger.info('Survey Validate Controller Function Initiated');
        const responsePayload = await paymentServices.surveyPayment(req.body, id, surveyId);
        logger.info('Survey Validate Function ended');
        return response.success(res, responsePayload, MESSAGES.SURVEY.fieldsValidated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Survey Validate ended with exception');
        next(error);
    }
};

exports.submitPayment = async (req, res, next) => {
    const { id } = req.params;
    try {
        logger.info('Survey Validate Controller Function Initiated');
        const responsePayload = await paymentServices.surveyPayment(req.body, id);
        logger.info('Survey Validate Function ended');
        return response.success(res, responsePayload, MESSAGES.SURVEY.fieldsValidated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Survey Validate ended with exception');
        next(error);
    }
};

exports.getAccessToken = async (req, res, next) => {
    try {
        const token = await paymentServices.getAccessToken();
        return response.success(res, token);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Generate Access Token Ended With Exception');
        next(error);
    }
};

exports.createOrder = async (req, res, next) => {
    const { id } = req.params;
    const { surveyId } = req.query;
    const data = {
        body: req.body,
    };
    try {
        logger.info('Create Order Controller Function Initiated');
        const responsePayload = await paymentServices.createOrder(data, id, surveyId);
        logger.info('Survey Validate Function ended');
        return response.success(res, responsePayload, MESSAGES.SURVEY.fieldsValidated);
    } catch (error) {
        logger.error('Exception Occurred');
        logger.error(error.message);
        logger.error('Survey Validate ended with exception');
        next(error);
    }
};
