const surveyRepository = require('../../survey/survey.repository');
const campaignRepository = require('../../campaignManagement/campaign.repository');
const paymentRepository = require('../payment.repository');
const { Op } = require('sequelize');
const { BadRequestException } = require('../../../../helpers/errorResponse');
const { MESSAGES, CONSTANTS } = require('../../../../configs');
const { decryptJsonValue, encryptJsonValue } = require('../../../../helpers/encryption');
const md5 = require('md5');
const { publishToQueue } = require('../../../../utilities/queueUtils');

module.exports = async (data, campaignId, surveyId, paymentOptions) => {
    // need to create a survey first or add payment to that survey itself
    let responseBody = {
        body: data,
        surveyId: surveyId,
        paymentDetails: paymentOptions,
    };

    // add beneficiary
    let beneficiaryDetails;
    if (responseBody.body.vpa) {
        beneficiaryDetails = md5(responseBody.body.vpa);
    }
    if (responseBody.body.accountNumber) {
        beneficiaryDetails = md5(responseBody.body.accountNumber);
    }
    // Check Beneficiary Exists
    const checkbeneficiary = [{ beneficiaryDetails: { [Op.eq]: beneficiaryDetails } }];
    const beneficiaryExists = await paymentRepository.checkExistsOnBeneficiary(checkbeneficiary);
    let surveyData = {};
    console.log('beneficiary Exists', beneficiaryExists);
    if (beneficiaryExists) {
        const beneficiaryData = {
            beneficiaryId: beneficiaryExists.beneficiaryId,
        };
        const encryptedSurvey = encryptJsonValue(beneficiaryData);
        await surveyRepository.createSurvey(encryptedSurvey);
        if (beneficiaryExists.isBeneficiaryValidated) {
            await publishToQueue(CONSTANTS.QUEUE.LIST.createOrder, responseBody);
        }
        if (!beneficiaryExists.isBeneficiaryValidated) {
            responseBody.body.beneficiaryId = beneficiaryExists.beneficiaryId;
            await publishToQueue(CONSTANTS.QUEUE.LIST.validateBeneficiary, responseBody);
        }
        return {
            paymentStatus: CONSTANTS.ENUMS.paymentStatus[2],
            message: 'Payment Processing',
        };
    } else {
        await publishToQueue(CONSTANTS.QUEUE.LIST.createBeneficiary, responseBody);
        const beneficiaryData = {
            paymentStatus: CONSTANTS.ENUMS.paymentStatus[0],
            message: 'Payment Processing',
        };
        const encryptedSurvey = encryptJsonValue(beneficiaryData);
        await surveyRepository.createSurvey(encryptedSurvey);
        return beneficiaryData;
    }
};
