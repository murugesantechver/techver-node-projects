const { MESSAGES } = require('../../../../configs');
const { BadRequestException } = require('../../../../helpers/errorResponse');
const { logger, date } = require('../../../../utilities');
const paymentRepository = require('../payment.repository');
const generateBearerToken = require('./oath2GenerateBearerToken');

module.exports = async (requiresReGeneration) => {
    logger.info('Get Bearer Token Service Initiated');
    const { bearerToken, expiresOn, requireNewTokenGeneration } = await paymentRepository.getTokenDetails();
    let newToken;
    if (requireNewTokenGeneration || requiresReGeneration) {
        newToken = await generateBearerToken();
        return newToken;
    } else {
        if (expiresOn) {
            const isExpired = date.hasDaysElapsed(expiresOn);
            if (isExpired) {
                logger.info('Old Bearer Token Expired, Generating New');
                newToken = await generateBearerToken();
                logger.info('Get Bearer Token Service Ended');
                return newToken;
            } else {
                logger.info('Get Bearer Token Service Ended');
                return bearerToken;
            }
        } else {
            logger.info('Get Bearer Token Service Ended With Exception');
            throw new BadRequestException(MESSAGES.PAYMENT.failedToGetBearerToken);
        }
    }
};
