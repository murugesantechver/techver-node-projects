const axios = require('axios');
const { CONSTANTS } = require('../../../../configs');
const { logger, date } = require('../../../../utilities');
const { consumerKey, consumerSecret } = CONSTANTS.QWIKGIFTAPI.sandBoxCredentials;
const { baseUrl } = CONSTANTS.QWIKGIFTAPI.sandBoxBaseUrl;
const { generateBearerToken } = CONSTANTS.QWIKGIFTAPI.apiRoutes;
const { dayGap } = CONSTANTS.QWIKGIFTAPI.tokenGenerationOptions;
const paymentRepository = require('../payment.repository');
const generateAuthorizationCode = require('./oath2GenerateAuthorizationCode');

module.exports = async () => {
    logger.info('Generating Bearer Token, Since Six Days Elapsed');
    try {
        logger.info('Generating Authorization Code Initiated');
        const authorizationCode = await generateAuthorizationCode();
        logger.info('Generating Authorization Code Ended');
        const requestUrl = `${baseUrl}${generateBearerToken}`;
        const requestBody = {
            clientId: consumerKey,
            clientSecret: consumerSecret,
            authorizationCode: authorizationCode,
        };
        const { data } = await axios({
            method: 'post',
            headers: { 'content-type': 'application/json' },
            url: requestUrl,
            data: requestBody,
        });
        if (data?.token) {
            const expiresOn = await date.addDaysToDate(dayGap);
            const updateBearerToken = {
                bearerToken: data.token,
                expiresOn: expiresOn,
                requireNewTokenGeneration: false,
            };
            await paymentRepository.updateAccessToken(updateBearerToken);
        }
        logger.info('Generate Bearer Token Ended');
        return data.token;
    } catch (error) {
        console.log('############# Generate Bearer Token Error START #############');
        console.log('********* Generate Bearer Token Error *********', error);
        console.log('############# Generate Bearer Token Error END #############');
        logger.info('Generate Bearer Token Ended With Exception');
    }
};
