const surveyRepository = require('../../survey/survey.repository');
const campaignRepository = require('../../campaignManagement/campaign.repository');
const paymentRepository = require('../payment.repository');
const { Op } = require('sequelize');
const { BadRequestException, pwsBadRequestException } = require('../../../../helpers/errorResponse');
const { MESSAGES, CONSTANTS } = require('../../../../configs');
const { decryptJsonValue, encryptJsonValue, decryptData } = require('../../../../helpers/encryption');
const md5 = require('md5');
const { publishToQueue } = require('../../../../utilities/queueUtils');

module.exports = async (data, campaignId, surveyId, paymentOptions, isEncrypted) => {
    const checks = [{ id: { [Op.eq]: surveyId } }];
    const doesSurveyExists = await surveyRepository.surveyExists(checks);
    if (!doesSurveyExists) {
        if (!isEncrypted) {
            throw new pwsBadRequestException(MESSAGES.PAYMENT.surveyDoesNotExists);
        } else {
            throw new BadRequestException(MESSAGES.PAYMENT.surveyDoesNotExists);
        }
    }
    console.log('does survey exists', doesSurveyExists);
    if (doesSurveyExists) {
        if (doesSurveyExists.dataValues.paymentStatus) {
            if (decryptData(doesSurveyExists.paymentStatus) === CONSTANTS.ENUMS.paymentStatus[3]) {
                if (!isEncrypted) {
                    throw new pwsBadRequestException(MESSAGES.PAYMENT.paymentAlreadyComplete);
                } else {
                    throw new BadRequestException(MESSAGES.PAYMENT.paymentAlreadyComplete);
                }
            }
            if (decryptData(doesSurveyExists.paymentStatus) === CONSTANTS.ENUMS.paymentStatus[1]) {
                if (!isEncrypted) {
                    throw new pwsBadRequestException(MESSAGES.PAYMENT.paymentFailed);
                } else {
                    throw new BadRequestException(MESSAGES.PAYMENT.paymentFailed);
                }
            }
            if (decryptData(doesSurveyExists.paymentStatus) === CONSTANTS.ENUMS.paymentStatus[0]) {
                if (!isEncrypted) {
                    throw new pwsBadRequestException(MESSAGES.PAYMENT.paymentProcessing);
                } else {
                    throw new BadRequestException(MESSAGES.PAYMENT.paymentProcessing);
                }
            }
            if (decryptData(doesSurveyExists.paymentStatus) === CONSTANTS.ENUMS.paymentStatus[2]) {
                if (!isEncrypted) {
                    throw new pwsBadRequestException(MESSAGES.PAYMENT.paymentProcessing);
                } else {
                    throw new BadRequestException(MESSAGES.PAYMENT.paymentProcessing);
                }
            }
        }
    }
    let { companyName } = await campaignRepository.getCompanyNameByCampaignId(campaignId);
    if (!companyName) companyName = 'SMARTBUILDER';
    let responseBody = {
        companyName: companyName,
        surveyId: surveyId,
        campaignId: campaignId,
        paymentDetails: paymentOptions,
    };
    if (isEncrypted) {
        responseBody.body = decryptJsonValue(data);
    } else {
        responseBody.body = data;
    }

    // add beneficiary
    let beneficiaryDetails;
    if (responseBody.body.vpa) {
        beneficiaryDetails = md5(responseBody.body.vpa);
    }
    if (responseBody.body.accountNumber) {
        beneficiaryDetails = md5(responseBody.body.accountNumber);
    }
    // Check Beneficiary Exists
    const checkbeneficiary = [{ beneficiaryDetails: { [Op.eq]: beneficiaryDetails } }];
    const beneficiaryExists = await paymentRepository.checkExistsOnBeneficiary(checkbeneficiary);
    if (beneficiaryExists) {
        const beneficiaryData = {
            beneficiaryId: beneficiaryExists.beneficiaryId,
        };
        const encryptedSurvey = encryptJsonValue(beneficiaryData);
        await surveyRepository.updateSurvey(surveyId, encryptedSurvey);
        if (beneficiaryExists.isBeneficiaryValidated) {
            await publishToQueue(CONSTANTS.QUEUE.LIST.createOrder, responseBody);
        }
        if (!beneficiaryExists.isBeneficiaryValidated) {
            responseBody.body.beneficiaryId = beneficiaryExists.beneficiaryId;
            await publishToQueue(CONSTANTS.QUEUE.LIST.validateBeneficiary, responseBody);
        }
        return {
            paymentStatus: CONSTANTS.ENUMS.paymentStatus[2],
            message: 'Payment Processing',
        };
    } else {
        if (responseBody.body.accountNumber || responseBody.body.vpa) {
            await publishToQueue(CONSTANTS.QUEUE.LIST.createBeneficiary, responseBody);
            const beneficiaryData = {
                paymentStatus: CONSTANTS.ENUMS.paymentStatus[0],
                message: 'Payment Processing',
            };
            const encryptedSurvey = encryptJsonValue(beneficiaryData);
            await surveyRepository.updateSurvey(surveyId, encryptedSurvey);
            return beneficiaryData;
        } else {
            await publishToQueue(CONSTANTS.QUEUE.LIST.createOrder, responseBody);
            return true;
        }
    }
};
