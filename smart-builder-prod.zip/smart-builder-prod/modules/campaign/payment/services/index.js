const surveyPayment = require('./surveyPayment');
const getAccessToken = require('./oath2GetAccessToken');
const generateAuthorizationCode = require('./oath2GenerateAuthorizationCode');
const generateBearerToken = require('./oath2GenerateBearerToken');
const createOrder = require('./qwikgiftOrderCreate');
const validateBeneficiary = require('./qwikgiftBeneficiaryValidate');
const createBeneficiary = require('./qwikgiftBeneficiaryCreate');

module.exports = {
    surveyPayment,
    getAccessToken,
    generateAuthorizationCode,
    generateBearerToken,
    createOrder,
    validateBeneficiary,
    createBeneficiary,
};
