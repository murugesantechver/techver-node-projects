const axios = require('axios');
const { CONSTANTS, HTTP_CODES, MESSAGES } = require('../../../../configs');
const { BadRequestException, ErrorResponse } = require('../../../../helpers/errorResponse');
const { logger } = require('../../../../utilities');
const { createDateAtClient, createSignature, createRequestBodyForCreateOrder } = require('../utilities');
const { baseUrl } = CONSTANTS.QWIKGIFTAPI.sandBoxBaseUrl;
const { createOrder } = CONSTANTS.QWIKGIFTAPI.apiRoutes;
const getAccessToken = require('./oath2GetAccessToken');
const surveyRepository = require('../../survey/survey.repository');
const { encryptJsonValue } = require('../../../../helpers/encryption');
const { Op } = require('sequelize');
const updateDenomination = require('../../wallet/services/updateDenomination');

module.exports = async (orderData) => {
    logger.info('Create Order Service Function Initiated');
    try {
        const { surveyId, campaignId } = orderData;
        const checks = [{ id: { [Op.eq]: surveyId } }];
        const doesSurveyExists = await surveyRepository.surveyExists(checks);
        if (!doesSurveyExists) throw new BadRequestException(MESSAGES.PAYMENT.surveyDoesNotExists);
        if (doesSurveyExists) {
            if (doesSurveyExists?.paymentStatus) {
                if (doesSurveyExists.paymentStatus === CONSTANTS.ENUMS.paymentStatus[3]) {
                    throw new BadRequestException(MESSAGES.PAYMENT.paymentAlreadyComplete);
                }
                if (doesSurveyExists.paymentStatus === CONSTANTS.ENUMS.paymentStatus[0]) {
                    throw new BadRequestException(MESSAGES.PAYMENT.paymentProcessing);
                }
                if (doesSurveyExists.paymentStatus === CONSTANTS.ENUMS.paymentStatus[2]) {
                    throw new BadRequestException(MESSAGES.PAYMENT.paymentProcessing);
                }
            }
        }
        const bearerToken = await getAccessToken(false);
        const requestUrl = `${baseUrl}${createOrder}`;
        const requestBody = await createRequestBodyForCreateOrder(orderData);
        console.log('Request Body Complete', JSON.stringify(requestBody));
        console.log('### Create Order Request Body is ###', requestBody);
        console.log('### Create Order Request Body Product ###', requestBody.products[0]);
        console.log('### Create Order Payment Request Body is ###', requestBody.products[0].payout);
        logger.info('Constructing Request Body');
        const dateAtClient = await createDateAtClient();
        const signatureData = {
            absApiUrl: requestUrl,
            requestBody: requestBody,
            requestHttpMethod: 'POST',
        };
        const signature = await createSignature(signatureData);
        logger.info('Signature Generated');
        const headers = {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${bearerToken}`,
            signature: signature,
            dateAtClient: dateAtClient,
        };
        const config = {
            method: 'POST',
            url: requestUrl,
            data: requestBody,
            headers,
        };
        const response = axios(config)
            .then(async (result) => {
                if (result) {
                    const { data } = result;
                    logger.info('Order Was Created Successfully');
                    if (data) {
                        // Update wallet after successfull redemption
                        await updateDenomination(requestBody.payments[0].amount, campaignId, true);
                        console.log('Order Data is', data);
                        console.log('Order Data Status', data.status);
                        if (data?.status === 'COMPLETE') {
                            const survey = {
                                bookingId: data.refno,
                                skuNumber: requestBody.products[0].sku,
                                amount: requestBody.payments[0].amount,
                                paymentStatus: CONSTANTS.ENUMS.paymentStatus[3],
                                message: 'Payment Completed',
                            };
                            var encryptedSurvey = encryptJsonValue(survey);
                            (encryptedSurvey.orderId = data.orderId), await surveyRepository.updateSurvey(surveyId, encryptedSurvey);
                            return;
                        }
                        if (data?.status === 'PROCESSING') {
                            const survey = {
                                bookingId: data.refno,
                                skuNumber: requestBody.products[0].sku,
                                amount: requestBody.payments[0].amount,
                                paymentStatus: CONSTANTS.ENUMS.paymentStatus[0],
                                message: 'Payment Processing',
                            };

                            encryptedSurvey = encryptJsonValue(survey);
                            (encryptedSurvey.orderId = data.orderId),
                                await surveyRepository.updateSurvey(orderData.surveyId, encryptedSurvey);
                            return;
                        }
                        return;
                    }
                    return;
                }
            })
            .catch(async (error) => {
                console.log('############# Order Create Error START #############');
                console.log('********* Order Create Error *********', error);
                console.log('############# Order Create Error END #############');
                logger.info('Error Occured while creating Order');
                if (error) {
                    if (!error?.response?.data) {
                        throw new BadRequestException(MESSAGES.PAYMENT.ipNotWhitelisted);
                    }
                    const { data } = error.response;
                    if (data.code == 401 && data.message === 'oauth_problem=token_rejected') {
                        await getAccessToken(true);
                        //Call the same whole function by passing order data
                        return await module.exports(orderData);
                    }
                    const survey = {
                        bookingId: requestBody.refno,
                        skuNumber: requestBody.products[0].sku,
                        paymentStatus: CONSTANTS.ENUMS.paymentStatus[1],
                        message: data.message,
                    };
                    const encryptedSurvey = encryptJsonValue(survey);
                    await surveyRepository.updateSurvey(orderData.surveyId, encryptedSurvey);
                    if (data.code == 5308) {
                        throw new ErrorResponse(data.message, HTTP_CODES.FAILED_DEPENDENCY, data.code);
                    }
                    if (data.code == 5313) {
                        throw new ErrorResponse(data.message, HTTP_CODES.BAD_REQUEST, data.code);
                    }
                    if (data.code == 11274) {
                        throw new ErrorResponse(data.message, HTTP_CODES.BAD_REQUEST, data.code);
                    }
                    if (data.code == 11230) {
                        throw new ErrorResponse(data.message, HTTP_CODES.BAD_REQUEST, data.code);
                    }
                    throw new BadRequestException(data.message);
                }
            });
        logger.info('Create Order Service Ended');
        return response;
    } catch (error) {
        logger.info('Create order service Ended With Exception');
    }
};
