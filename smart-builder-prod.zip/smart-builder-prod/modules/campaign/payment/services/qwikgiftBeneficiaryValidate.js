const axios = require('axios');
const { CONSTANTS, MESSAGES } = require('../../../../configs');
const { BadRequestException } = require('../../../../helpers/errorResponse');
const { logger } = require('../../../../utilities');
const { createDateAtClient, createSignature } = require('../utilities');
const { baseUrl } = CONSTANTS.QWIKGIFTAPI.sandBoxBaseUrl;
const { validateBeneficiary } = CONSTANTS.QWIKGIFTAPI.apiRoutes;
const getAccessToken = require('./oath2GetAccessToken');
const surveyRepository = require('../../survey/survey.repository');
const paymentRepository = require('../payment.repository');
const { encryptJsonValue } = require('../../../../helpers/encryption');
const { createReqBodyForValidateBeneficiary } = require('../utilities');
const { publishToQueue } = require('../../../../utilities/queueUtils');

module.exports = async (validationData) => {
    logger.info('Validate Beneficiary Service Function Initiated');
    try {
        const bearerToken = await getAccessToken(false);
        const requestUrl = `${baseUrl}${validateBeneficiary}`;
        const requestBody = await createReqBodyForValidateBeneficiary(validationData);
        console.log('Request Body for Validate Beneficiary is', requestBody);
        logger.info('Constructing Request Body');
        const dateAtClient = await createDateAtClient();
        const signatureData = {
            absApiUrl: requestUrl,
            requestBody: requestBody,
            requestHttpMethod: 'POST',
        };
        const signature = await createSignature(signatureData);
        logger.info('Signature Generated');
        const headers = {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${bearerToken}`,
            signature: signature,
            dateAtClient: dateAtClient,
        };
        const config = {
            method: 'POST',
            url: requestUrl,
            data: requestBody,
            headers,
        };
        const response = axios(config)
            .then(async (result) => {
                if (result) {
                    const { data } = result;
                    logger.info('Beneficiary Validated Successfully');
                    let beneficiaryData = {
                        isBeneficiaryValidated: true,
                    };
                    const validateBeneficiary = await paymentRepository.updateBeneficiary(
                        beneficiaryData,
                        validationData.body.beneficiaryId
                    );
                    console.log('Validate beneficiary is', validateBeneficiary);
                    await publishToQueue(CONSTANTS.QUEUE.LIST.createOrder, validationData);
                    return data;
                }
            })
            .catch(async (error) => {
                console.log('############# Beneficiary Validate Error START #############');
                console.log('********* Beneficiary Validate Error *********', error);
                console.log('############# Beneficiary Validate Error END #############');
                logger.info('Error Occured while Validating Beneficiary');
                if (error) {
                    if (!error?.response?.data) {
                        throw new BadRequestException(MESSAGES.PAYMENT.ipNotWhitelisted);
                    }
                    const { data } = error.response;
                    if (data.code === 11236) {
                        // Beneficiary Details not available
                        // Temporarily bypassing this for testing
                        // This error happens on sandbox and needs bypassing
                        // Change this on production and have other conditions
                        let beneficiaryData = {
                            isBeneficiaryValidated: true,
                        };
                        await paymentRepository.updateBeneficiary(beneficiaryData, validationData.body.beneficiaryId);
                        await publishToQueue(CONSTANTS.QUEUE.LIST.createOrder, validationData);
                        return true;
                    }
                    if (data.code === 11251) {
                        let beneficiaryData = {
                            isBeneficiaryValidated: true,
                        };
                        await paymentRepository.updateBeneficiary(beneficiaryData, validationData.body.beneficiaryId);
                        await publishToQueue(CONSTANTS.QUEUE.LIST.createOrder, validationData);
                        return true;
                    }
                    if (data.code == 401 && data.message === 'oauth_problem=token_rejected') {
                        await getAccessToken(true);
                        //Call the same whole function by passing order data
                        return await module.exports(validationData);
                    }
                    const beneficiary = {
                        beneficiaryStatus: 'Validation Failed',
                        paymentStatus: CONSTANTS.ENUMS.paymentStatus[2],
                        message: data.message,
                    };
                    const encryptedSurvey = encryptJsonValue(beneficiary);
                    await surveyRepository.updateSurvey(validationData.surveyId, encryptedSurvey);
                    throw new BadRequestException(data.message);
                }
            });
        logger.info('Validate Beneficiary Service Ended');
        return response;
    } catch (error) {
        logger.info('Validate Beneficiary Service Ended With Exception');
    }
};
