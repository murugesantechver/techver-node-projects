const axios = require('axios');
const { CONSTANTS, MESSAGES } = require('../../../../configs');
const { logger } = require('../../../../utilities');
const { consumerKey, username, password } = CONSTANTS.QWIKGIFTAPI.sandBoxCredentials;
const { baseUrl } = CONSTANTS.QWIKGIFTAPI.sandBoxBaseUrl;
const { generateAuthorizationCode } = CONSTANTS.QWIKGIFTAPI.apiRoutes;
const paymentRepository = require('../payment.repository');
const { BadRequestException } = require('../../../../helpers/errorResponse');

module.exports = async () => {
    logger.info('Generating Authorization Code');
    try {
        const requestUrl = `${baseUrl}${generateAuthorizationCode}`;
        const requestBody = {
            clientId: consumerKey,
            username: username,
            password: password,
        };
        const { data } = await axios({
            method: 'post',
            headers: { 'content-type': 'application/json' },
            url: requestUrl,
            data: requestBody,
        });
        if (data?.authorizationCode) {
            const updateAuthorizationCode = {
                authorizationCode: data.authorizationCode,
            };
            logger.info('Authorization Token Was Generated');
            await paymentRepository.updateAccessToken(updateAuthorizationCode);
        } else {
            logger.info('Generate Authorization Code Ended With Exception');
            throw new BadRequestException(MESSAGES.PAYMENT.failedGeneratingAUthorizationCode);
        }
        logger.info('Generate Authorization Code Ended');
        return data.authorizationCode;
    } catch (error) {
        console.log('############# Beneficiary Authorization Code Error START #############');
        console.log('********* Generate Authorization Code Error *********', error);
        console.log('############# Generate Authorization Code Error END #############');
        logger.info('Generate Authorization Code Ended With Exception');
        throw new BadRequestException(MESSAGES.PAYMENT.failedGeneratingAUthorizationCode);
    }
};
