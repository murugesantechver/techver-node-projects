const axios = require('axios');
const { CONSTANTS, MESSAGES } = require('../../../../configs');
const { BadRequestException } = require('../../../../helpers/errorResponse');
const { logger } = require('../../../../utilities');
const { createDateAtClient, createSignature } = require('../utilities');
const { baseUrl } = CONSTANTS.QWIKGIFTAPI.sandBoxBaseUrl;
const { createBeneficiary } = CONSTANTS.QWIKGIFTAPI.apiRoutes;
const getAccessToken = require('./oath2GetAccessToken');
const surveyRepository = require('../../survey/survey.repository');
const paymentRepository = require('../payment.repository');
const { encryptJsonValue, encryptData } = require('../../../../helpers/encryption');
const { createRequestBodyForCreateBeneficiary } = require('../utilities');
const { publishToQueue } = require('../../../../utilities/queueUtils');
const md5 = require('md5');
module.exports = async (orderData) => {
    logger.info('Create Beneficiary Service Function Initiated');
    try {
        const bearerToken = await getAccessToken(false);
        const requestUrl = `${baseUrl}${createBeneficiary}`;
        const requestBody = await createRequestBodyForCreateBeneficiary(orderData);
        console.log('### Beneficiary Create Request Body ### ', requestBody);
        const dateAtClient = await createDateAtClient();
        const signatureData = {
            absApiUrl: requestUrl,
            requestBody: requestBody,
            requestHttpMethod: 'POST',
        };
        const signature = await createSignature(signatureData);
        logger.info('Signature Generated');
        const headers = {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${bearerToken}`,
            signature: signature,
            dateAtClient: dateAtClient,
        };
        const config = {
            method: 'POST',
            url: requestUrl,
            data: requestBody,
            headers,
        };
        const response = axios(config)
            .then(async (result) => {
                if (result) {
                    const { data } = result;
                    logger.info('Beneficiary Created Successfully');
                    orderData.body.beneficiaryId = data.beneficiaries.id;
                    let beneficiaryData = {
                        isBeneficiaryValidated: false,
                    };
                    beneficiaryData.beneficiaryId = data.beneficiaries.id;
                    if (requestBody.type === requestBody.type) {
                        beneficiaryData.accountType = requestBody.type;
                        beneficiaryData.beneficiaryDetails = md5(requestBody.accountNumber);
                    }
                    if (requestBody.type === 'UPI') {
                        beneficiaryData.accountType = requestBody.type;
                        beneficiaryData.beneficiaryDetails = md5(requestBody.vpa);
                        beneficiaryData.beneficiaryShortName = requestBody.shortName;
                    }
                    const beneficiaryId = data.beneficiaries.id;
                    const surveyData = {
                        beneficiaryId: encryptData(beneficiaryId),
                    };
                    await surveyRepository.updateSurvey(orderData.surveyId, surveyData);
                    await paymentRepository.addbeneficiary(beneficiaryData);
                    await publishToQueue(CONSTANTS.QUEUE.LIST.validateBeneficiary, orderData);
                    return data;
                }
            })
            .catch(async (error) => {
                console.log('############# Beneficiary Create Error START #############');
                console.log('********* Beneficiary Create Error *********', error);
                console.log('############# Beneficiary Create Error END #############');
                logger.info('Error Occured while creating Beneficiary');
                if (error) {
                    if (!error?.response?.data) {
                        throw new BadRequestException(MESSAGES.PAYMENT.ipNotWhitelisted);
                    }
                    const { data } = error.response;
                    let beneficiary = {
                        beneficiaryStatus: 'Creation Failed',
                        paymentStatus: CONSTANTS.ENUMS.paymentStatus[0],
                        message: 'Beneficiary Creation Failed',
                    };
                    if (data.code == 11291) {
                        await publishToQueue(CONSTANTS.QUEUE.LIST.validateBeneficiary, orderData);
                        beneficiary = {
                            beneficiaryStatus: 'Payment Initiated',
                            paymentStatus: CONSTANTS.ENUMS.paymentStatus[0],
                        };
                    }
                    if (data.code == 11237) {
                        // This Bank Account is already validated and associated with the user
                        // Check if the user is already validated
                        // if not validated, push queue to validate else createorder
                        await publishToQueue(CONSTANTS.QUEUE.LIST.createOrder, orderData);
                        beneficiary = {
                            beneficiaryStatus: 'Payment Initiated',
                            paymentStatus: CONSTANTS.ENUMS.paymentStatus[0],
                        };
                    }
                    // Rare Cases
                    if (data.code == 401 && data.message === 'oauth_problem=token_rejected') {
                        await getAccessToken(true);
                        //Call the same whole function by passing order data
                        // this is a rare condition..
                        return await module.exports(orderData);
                    }
                    if (data.code == 11290) {
                        // this code refers that the beneficiary shortcode has already been used and this error is only for UPI type
                        // this needs to be kept as a configuration if required
                        await publishToQueue(CONSTANTS.QUEUE.LIST.validateBeneficiary, orderData);
                        beneficiary = {
                            beneficiaryStatus: 'Payment Initiated',
                            paymentStatus: CONSTANTS.ENUMS.paymentStatus[0],
                        };
                    }
                    const encryptedSurvey = encryptJsonValue(beneficiary);
                    await surveyRepository.updateSurvey(orderData.surveyId, encryptedSurvey);
                    throw new BadRequestException(data.message);
                }
            });
        logger.info('Create Beneficiary Service Ended');
        return response;
    } catch (error) {
        logger.info('Create Beneficiary Service Ended With Exception');
    }
};
