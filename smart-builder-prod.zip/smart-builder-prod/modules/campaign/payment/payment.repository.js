const { Survey, Credentials, Beneficiary } = require('../../../database/models');
const { Op } = require('sequelize');

exports.addPaymentDetails = async (id, surveyUpdate, t = null) => {
    return await Survey.update(surveyUpdate, { where: { id }, transaction: t });
};

exports.getTokenDetails = async () => {
    return await Credentials.findOne({
        where: { id: 1 },
        attributes: ['authorizationCode', 'bearerToken', 'expiresOn', 'requireNewTokenGeneration'],
    });
};

exports.updateAccessToken = async (credentials, t = null) => {
    const data = await Credentials.update(credentials, { where: { id: 1 }, transaction: t });
    return data;
};

exports.addbeneficiary = async (beneficiaryDetails, t = null) => {
    return await Beneficiary.create(beneficiaryDetails, { transaction: t });
};

exports.updateBeneficiary = async (beneficiaryDetails, id, t = null) => {
    return await Beneficiary.update(beneficiaryDetails, { where: { beneficiaryId: id }, transaction: t });
};

exports.checkExistsOnBeneficiary = async (checks) => {
    const isbeneficiaryAvailable = await Beneficiary.findOne({
        where: {
            [Op.or]: checks,
        },
    });
    return isbeneficiaryAvailable;
};
