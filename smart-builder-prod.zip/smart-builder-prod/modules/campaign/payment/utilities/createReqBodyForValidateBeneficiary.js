const { common } = require('../../../../utilities');

module.exports = async (data) => {
    console.log('Data is', data);
    let requestBody = {};
    if (data.body) {
        const body = data.body;
        const referenceNo = await common.generateBookingId('BENEFICIARY');
        if (referenceNo) {
            requestBody.refno = referenceNo;
        }
        if (body?.beneficiaryId) {
            requestBody.id = body.beneficiaryId;
        }
    }
    return requestBody;
};
