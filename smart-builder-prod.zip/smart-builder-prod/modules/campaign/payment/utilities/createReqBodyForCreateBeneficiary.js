const { generateUniqueShortNameForBeneficiary } = require('../../../../utilities/common');

module.exports = async (data) => {
    let requestBody = {
        type: 'BANK_ACCOUNT',
        name: 'alrahiyan',
        telephone: '+917395904703',
        email: 'alrahiyan.r@qwikcilver.com',
        isDefault: true,
        isActive: true,
    };
    if (data.body) {
        const body = data.body;
        if (body?.mobileNumber) {
            requestBody.telephone = body.mobileNumber;
        }
        if (body?.email) {
            requestBody.email = body.email;
        }
        if (body?.firstName) {
            requestBody.name = body.firstName;
        }
        if (body?.accountNumber) {
            requestBody.type = 'BANK_ACCOUNT';
            requestBody.shortName = await generateUniqueShortNameForBeneficiary('alrahiyan');
            requestBody.ifscCode = body?.ifscCode ? body?.ifscCode : 'RAZR0000001';
            requestBody.accountNumber = body.accountNumber ? body.accountNumber : '232323007999568916';
        }
        if (body?.vpa) {
            requestBody.type = 'UPI';
            requestBody.shortName = await generateUniqueShortNameForBeneficiary('alrahiyan');
            requestBody.vpa = body.vpa;
        }
    }
    return requestBody;
};
