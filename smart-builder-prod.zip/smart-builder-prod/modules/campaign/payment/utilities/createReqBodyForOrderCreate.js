const { common } = require('../../../../utilities');

module.exports = async (data) => {
    let requestBody = {
        billing: {
            firstname: 'vineeth',
            lastname: 'mn',
            email: 'vineeth.mn@qwikcilver.com',
            telephone: '+919740581587',
            line1: 'hsr layout work',
            line2: 'something',
            city: 'bangalore',
            region: 'karnataka',
            country: 'IN',
            postcode: '560061',
            company: 'test',
        },
        address: {
            firstname: 'vineeth',
            lastname: 'mn',
            telephone: '+919740581587',
            email: 'vineeth.mn@qwikcilver.com',
            line1: 'test',
            line2: 'testttt',
            city: 'bangalore',
            company: 'sdadasda',
            region: 'karnataka',
            country: 'IN',
            postcode: '560061',
            billToThis: false,
        },
        remarks: 'issue testing',
        payments: [
            {
                code: 'svc',
                amount: '400',
                card_number: 'adad',
                card_pin: 'das',
                poNumber: '1232131',
            },
        ],
        refno: 'AL-124Y6U2RG',
        syncOnly: false,
        deliveryMode: 'EMAIL',
        storeId: '3',
        isConsolidated: false,
        orderType: 'PAYOUT',
        products: [
            {
                sku: 'pay1',
                qty: '1',
                price: '100',
                transactionType: 'IMPS',
                currency: '356',
                payout: {
                    type: 'BANK_ACCOUNT',
                    name: 'alrahiyan',
                    telephone: '+917395904703',
                    email: 'alrahiyan.r@qwikcilver.com',
                },
            },
        ],
    };
    if (data.body) {
        const body = data.body;
        const companyName = data.companyName;
        const bookingId = await common.generateBookingId('HCEL');
        if (bookingId) {
            requestBody.refno = bookingId;
        }
        if (body?.firstName) {
            requestBody.address.firstname = body.firstName;
        }
        if (body?.lastname) {
            requestBody.address.lastname = body.lastName;
        }
        if (body?.mobileNumber) {
            requestBody.address.telephone = body.mobileNumber;
        }
        if (body?.city) {
            requestBody.address.city = body.city;
        }
        if (body?.pinCode) {
            requestBody.address.postcode = body.pincode;
        }
        if (body?.addressLine1) {
            requestBody.address.line1 = body.addressLine1;
        }
        if (body?.addressLine2) {
            requestBody.address.line2 = body.addressLine2;
        }
        if (body?.accountNumber) {
            requestBody.products[0].payout.type = 'BANK_ACCOUNT';
            requestBody.products[0].payout.ifscCode = body?.ifscCode ? body?.ifscCode : 'RAZR0000001';
            requestBody.products[0].payout.name = 'alrahiyan';
            requestBody.products[0].payout.accountNumber = body.accountNumber;
            requestBody.products[0].payout.telephone = '+917395904703';
            requestBody.products[0].payout.email = 'alrahiyan.r@qwikcilver.com';
            requestBody.products[0].payout.transactionType = 'IMPS';
        }
        if (body?.vpa) {
            requestBody.products[0].payout.type = 'UPI';
            requestBody.products[0].payout.vpa = body.vpa;
            requestBody.products[0].payout.name = 'alrahiyan';
        }
    }
    if (data.paymentDetails) {
        const paymentOptions = data.paymentDetails;
        if (paymentOptions.skuNo) {
            requestBody.products[0].sku = paymentOptions.skuNo;
        }
        if (paymentOptions.amount) {
            requestBody.products[0].price = paymentOptions.amount;
            requestBody.payments[0].amount = paymentOptions.amount;
        }
    }
    return requestBody;
};
