const moment = require('moment');

module.exports = async () => {
    return moment().toISOString();
};
