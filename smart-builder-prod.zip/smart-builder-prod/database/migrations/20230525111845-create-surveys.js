'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Surveys', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                campaignId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Campaigns',
                        key: 'id',
                    },
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'campaignData',
                },
                bookingId: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                orderId: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                skuNumber: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                amount: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                paymentStatus: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                beneficiaryId: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                message: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                mobileNumber: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                name: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                otp: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                firstName: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                lastName: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                pinCode: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                panCard: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                dob: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                state: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                city: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                address1: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                address2: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                email: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                aadharCard: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                ifscCode: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                accountNumber: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                vpa: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                voucherCode: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                paytm: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                images: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                date: {
                    type: Sequelize.DATE,
                    allowNull: true,
                },
                voucherUsed: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                inviteePhone: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Surveys', ['campaignId']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Surveys');
    },
};
