'use strict';

const { CONSTANTS } = require('../../configs');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Vouchers', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                campaignId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Campaigns',
                        key: 'id',
                    },
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'campaignData',
                },
                voucherNumber: {
                    type: Sequelize.STRING,
                    unique: true,
                    allowNull: false,
                },
                denomination: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                status: {
                    type: Sequelize.ENUM(CONSTANTS.ENUMS.voucherStatus),
                    allowNull: false,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Vouchers', ['campaignId']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Vouchers');
    },
};
