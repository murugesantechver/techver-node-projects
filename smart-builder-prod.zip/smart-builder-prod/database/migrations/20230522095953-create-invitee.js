'use strict';

const { CONSTANTS } = require('../../configs');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Invitees', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                campaignId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Campaigns',
                        key: 'id',
                    },
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'campaignData',
                },
                name: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                phone: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                participated: {
                    type: Sequelize.BOOLEAN,
                    defaultValue: false,
                    allowNull: false,
                },
                attempts: {
                    type: Sequelize.INTEGER,
                    allowNull: false,
                    defaultValue: 0,
                },
                rewardType: {
                    type: Sequelize.ENUM(CONSTANTS.ENUMS.rewardFrame),
                    allowNull: false,
                },
                status: {
                    type: Sequelize.ENUM(CONSTANTS.ENUMS.inviteeStatus),
                    allowNull: false,
                },
                verified: {
                    type: Sequelize.BOOLEAN,
                    defaultValue: false,
                    allowNull: false,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Invitees', ['campaignId']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Invitees');
    },
};
