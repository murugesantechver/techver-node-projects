'use strict';
const { CONSTANTS } = require('../../configs');
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Fields', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                campaignId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Campaigns',
                        key: 'id',
                    },
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'campaignData',
                },
                fieldName: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                displayName: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                requireFileUpload: {
                    type: Sequelize.BOOLEAN,
                    allowNull: true,
                    defaultValue: false,
                },
                isMandatory: {
                    type: Sequelize.BOOLEAN,
                    allowNull: true,
                    defaultValue: true,
                },
                fieldType: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                rewardMode: {
                    type: Sequelize.ENUM(CONSTANTS.ENUMS.rewardFrame),
                    allowNull: true,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Fields', ['id']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Fields');
    },
};
