'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Rolepermissions', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                roleId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Roles',
                        key: 'id',
                    },
                    allowNull: false,
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'roleName',
                },
                permissionId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Permissions',
                        key: 'id',
                    },
                    allowNull: false,
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'permissionName',
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Rolepermissions', ['id']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Rolepermissions');
    },
};
