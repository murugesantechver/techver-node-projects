'use strict';
const { CONSTANTS } = require('../../configs');
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Campaigns', {
                id: {
                    type: Sequelize.INTEGER,
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                },
                campaignOwner: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Users',
                        key: 'id',
                    },
                    allowNull: false,
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'ownerData',
                },
                companyId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Companies',
                        key: 'id',
                    },
                    allowNull: false,
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'companyName',
                },
                subCompanyId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Subcompanies',
                        key: 'id',
                    },
                    allowNull: true,
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'subCompanyName',
                },
                campaignUrl: {
                    type: Sequelize.STRING,
                    unique: true,
                    allowNull: true,
                },
                campaignMode: {
                    type: Sequelize.STRING,
                    allowNull: true,
                    defaultValue: CONSTANTS.ENUMS.campaignModes[0],
                },
                campaignName: {
                    type: Sequelize.STRING,
                    unique: true,
                    allowNull: false,
                },
                inviteeAttempts: {
                    type: Sequelize.INTEGER,
                    allowNull: false,
                    defaultValue: 1,
                },
                issuedDate: {
                    type: Sequelize.DATE,
                    allowNull: false,
                },
                startDate: {
                    type: Sequelize.DATE,
                    allowNull: false,
                },
                endDate: {
                    type: Sequelize.DATE,
                    allowNull: false,
                },
                status: {
                    type: Sequelize.ENUM(CONSTANTS.ENUMS.campaignStatus),
                    allowNull: false,
                },
                publish: {
                    type: Sequelize.BOOLEAN,
                    allowNull: false,
                },
                isActive: {
                    type: Sequelize.BOOLEAN,
                    allowNull: false,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Campaigns', ['id']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Campaigns');
    },
};
