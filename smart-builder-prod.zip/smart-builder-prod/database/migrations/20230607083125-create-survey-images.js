'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Surveyimages', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                surveyId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Surveys',
                        key: 'id',
                    },
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'surveyData',
                },
                imageUrl: {
                    type: Sequelize.JSON,
                    allowNull: true,
                },
                imageType: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Surveyimages');
    },
};
