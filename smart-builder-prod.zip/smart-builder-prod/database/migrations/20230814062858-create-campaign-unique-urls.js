'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('campaignUniqueUrls', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                uniqueId: {
                    type: Sequelize.STRING,
                    allowNull: false,
                    unique: true,
                },
                url: {
                    type: Sequelize.STRING,
                    allowNull: false,
                    unique: true,
                },
                campaignId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Campaigns',
                        key: 'id',
                    },
                    allowNull: false,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'campaignId',
                },
                inviteePhone: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                isRedeemed: {
                    type: Sequelize.BOOLEAN,
                    allowNull: true,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('campaignUniqueUrls', ['id']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('campaignUniqueUrls');
    },
};
