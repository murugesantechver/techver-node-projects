'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Credentials', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                authorizationCode: {
                    type: Sequelize.STRING,
                    unique: true,
                    allowNull: true,
                },
                bearerToken: {
                    type: Sequelize.STRING,
                    unique: true,
                    allowNull: true,
                },
                requireNewTokenGeneration: {
                    type: Sequelize.BOOLEAN,
                    defaultValue: true,
                    allowNull: true,
                },
                expiresOn: {
                    type: Sequelize.DATE,
                    allowNull: true,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Credentials', ['id']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Credentials');
    },
};
