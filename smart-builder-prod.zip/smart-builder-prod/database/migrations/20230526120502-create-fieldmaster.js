'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Fieldmasters', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                fieldName: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                displayName: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                requireFileUpload: {
                    type: Sequelize.BOOLEAN,
                    allowNull: true,
                },
                fieldType: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Fieldmasters', ['id']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Fieldmasters');
    },
};
