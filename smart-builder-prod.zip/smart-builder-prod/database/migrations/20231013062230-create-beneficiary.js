'use strict';

const { CONSTANTS } = require('../../configs');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Beneficiary', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                beneficiaryShortName: {
                    allowNull: true,
                    type: Sequelize.STRING,
                },
                beneficiaryId: {
                    allowNull: false,
                    type: Sequelize.STRING,
                },
                accountType: {
                    allowNull: false,
                    type: Sequelize.ENUM(CONSTANTS.ENUMS.paymentType),
                },
                beneficiaryDetails: {
                    allowNull: false,
                    type: Sequelize.STRING,
                },
                isBeneficiaryValidated: {
                    allowNull: false,
                    type: Sequelize.BOOLEAN,
                    default: false,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Beneficiary', ['beneficiaryDetails']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Beneficiary');
    },
};
