'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable('OAuthClients', {
            id: {
                allowNull: false,
                autoIncrement: true,
                primaryKey: true,
                type: Sequelize.INTEGER,
            },
            clientId: {
                type: Sequelize.STRING,
                allowNull: false,
            },
            clientSecret: {
                type: Sequelize.STRING,
                allowNull: false,
            },
            redirectUri: {
                type: Sequelize.STRING,
                allowNull: false,
            },
            grants: {
                type: Sequelize.ARRAY(Sequelize.STRING),
                allowNull: false,
            },
            createdAt: {
                allowNull: false,
                type: Sequelize.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: Sequelize.DATE,
            },
        });
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('OAuthClients');
    },
};
