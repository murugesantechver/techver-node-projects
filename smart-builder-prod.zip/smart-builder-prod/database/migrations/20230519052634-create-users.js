'use strict';
const { CONSTANTS } = require('../../configs');
/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return Promise.all([
            await queryInterface.createTable('Users', {
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER,
                },
                firstName: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                lastName: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                userName: {
                    type: Sequelize.STRING,
                    unique: true,
                    allowNull: true,
                },
                email: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                password: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                mobile: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                companyId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Companies',
                        key: 'id',
                    },
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'companyName',
                    allowNull: true,
                },
                subCompanyId: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'Subcompanies',
                        key: 'id',
                    },
                    constraints: true,
                    onDelete: 'cascade',
                    onUpdate: 'cascade',
                    as: 'subCompanyName',
                    allowNull: true,
                },
                contactPersonName: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                country: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                location: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                status: {
                    type: Sequelize.ENUM(CONSTANTS.ENUMS.userStatus),
                    allowNull: false,
                },
                wrongPasswordAttempts: {
                    type: Sequelize.INTEGER,
                    allowNull: true,
                    defaultValue: 0,
                },
                verifyOtp: {
                    type: Sequelize.INTEGER,
                    allowNull: true,
                },
                emailSent: {
                    type: Sequelize.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
            }),
            await queryInterface.addIndex('Users', ['id']),
        ]);
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('Users');
    },
};
