'use strict';

const { CONSTANTS } = require('../../configs');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.bulkInsert('Campaigns', [
            {
                campaignOwner: 1,
                companyId: 2,
                campaignName: 'Sample Campaign',
                inviteeAttempts: 1,
                campaignMode: CONSTANTS.ENUMS.campaignModes[1],
                issuedDate: new Date(),
                startDate: new Date(),
                endDate: new Date(),
                status: 'ONGOING',
                publish: true,
                isActive: true,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
        ]);
    },

    async down(queryInterface, Sequelize) {
        await queryInterface.bulkDelete('Campaigns', null, {});
    },
};
