'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.bulkInsert('Userrole', [
            {
                roleId: 1,
                userId: 1,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                roleId: 2,
                userId: 1,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                roleId: 2,
                userId: 2,
                createdAt: new Date(),
                updatedAt: new Date(),
            }
            //add More data here
        ]);
    },

    async down(queryInterface, Sequelize) {
        await queryInterface.bulkDelete('Userrole', null, {});
    },
};
