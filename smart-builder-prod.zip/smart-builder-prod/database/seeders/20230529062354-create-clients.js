'use strict';
const { bcrypt } = require('../../utilities');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        const encodedPassword = await bcrypt.generatePassword('passWORD@123');

        await queryInterface.bulkInsert('Users', [
            {
                userName: 'Colgate',
                email: 'colgateadmin@yopmail.com',
                mobile: '9876543431',
                companyId: 2,
                contactPersonName: 'Jacob Thomas',
                password: encodedPassword,
                country: 'India',
                location: 'Trivandrum',
                status: 'INACTIVE',
                createdAt: new Date(),
                updatedAt: new Date(),
            }
        ]);
    },

    async down(queryInterface, Sequelize) {
        await queryInterface.bulkDelete('Users', null, {});
    },
};
