'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.bulkInsert('Denomination', [
            {
                campaignId: 1,
                value: 50,
                count: 20,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                campaignId: 1,
                value: 100,
                count: 20,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
        ]);
    },

    async down(queryInterface, Sequelize) {
        await queryInterface.bulkDelete('Denomination', null, {});
    },
};
