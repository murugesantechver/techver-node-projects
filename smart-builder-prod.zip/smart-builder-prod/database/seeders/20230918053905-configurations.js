'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.bulkInsert('Configurations', [
            {
                name: 'JWT_SECRET',
                value: 'G&#JDSJKH*800GnjbsL',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'JWT_TOKEN_EXPIRY_IN',
                value: '1d',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'JWT_ACCESS_TOKEN_EXPIRES_IN',
                value: '1h',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'JWT_REFRESH_TOKEN_EXPIRES_IN',
                value: '1d',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'OTP_EXPIRY_MINUTES',
                value: '1d',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'TWILIO_ACCOUNT_SID',
                value: 'AC4a9d3520b6b9a4e5e96a2bf7b37b3974',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'TWILIO_AUTH_TOKEN',
                value: 'a9b7858b1dc4df95f31c529f9817ea72',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'TWILIO_FROM_PHONE',
                value: '+12295455049',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'SENDER_EMAIL',
                value: 'smartbuilderdemo@gmail.com',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'SENDER_PASSWORD',
                value: 'smartbuilder@2023',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'SANDBOX_QWIKGIFTAPI_CONSUMER_KEY',
                value: '6fe231badbd8a11c1ab74905cbca9d9d',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'SANDBOX_QWIKGIFTAPI_CONSUMER_SECRET',
                value: '0fb52b977a503e5412512b1dfd2ae57a',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'SANDBOX_QWIKGIFTAPI_USERNAME',
                value: 'hcelresellerapisandboxb2b@woohoo.in',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'SANDBOX_QWIKGIFTAPI_PASSWORD',
                value: 'hcelapib2b@123',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'SANDBOX_QWIKGIFTAPI_BASE_URL',
                value: 'https://sandbox.woohoo.in',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'SANDBOX_QWIKGIFTAPI_CUSTOMERID',
                value: '6362',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'RMQ_CONN_URL',
                value: 'amqp://localhost:5672',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'ENCRYPTION_SECRET',
                value: 'JHJHGL^&%&1igjbkjb&^',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                name: 'USER_INCORRECT_PASSWORD_THRESHOLD',
                value: '4',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
        ]);
    },

    async down(queryInterface, Sequelize) {
        await queryInterface.bulkDelete('Configurations', null, {});
    },
};
