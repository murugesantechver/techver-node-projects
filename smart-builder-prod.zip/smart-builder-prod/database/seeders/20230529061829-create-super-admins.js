'use strict';
const { bcrypt } = require('../../utilities');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        const encodedPassword = await bcrypt.generatePassword('passWORD@123');

        await queryInterface.bulkInsert('Users', [
            {
                firstName: 'Pinelabs',
                lastName: 'Admin',
                userName: 'smsuperadmin',
                email: 'psmadmin@yopmail.com',
                password: encodedPassword,
                status: 'ACTIVE',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            //add More data here
        ]);
    },

    async down(queryInterface, Sequelize) {
        await queryInterface.bulkDelete('Users', null, {});
    },
};
