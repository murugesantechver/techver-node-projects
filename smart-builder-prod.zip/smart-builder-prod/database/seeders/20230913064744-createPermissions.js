'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.bulkInsert('Permissions', [
            {
                permission: 'BASIC',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                permission: 'ADMIN-MANAGEMENT',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                permission: 'SUPERADMIN',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                permission: 'CAMPAIGN-MANAGEMENT',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                permission: 'COMPANY-MANAGEMENT',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                permission: 'SURVEY-REPORTING',
                createdAt: new Date(),
                updatedAt: new Date(),
            },
        ]);
    },

    async down(queryInterface, Sequelize) {
        await queryInterface.bulkDelete('Permissions', null, {});
    },
};
