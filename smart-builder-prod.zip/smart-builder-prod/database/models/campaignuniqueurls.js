'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class campaignUniqueUrls extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            campaignUniqueUrls.belongsTo(models.Campaign, {
                foreignKey: 'campaignId',
                constrains: true,
                allowNull: false,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'CampaignReference',
            });
        }
    }
    campaignUniqueUrls.init(
        {
            uniqueId: {
                type: DataTypes.STRING,
                allowNull: false,
                unique: true,
            },
            url: {
                type: DataTypes.STRING(255),
                allowNull: false,
                unique: true,
            },
            campaignId: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
            inviteePhone: {
                type: DataTypes.STRING(12),
                allowNull: true,
            },
            isRedeemed: {
                type: DataTypes.BOOLEAN,
                allowNull: true,
            },
        },
        {
            sequelize,
            modelName: campaignUniqueUrls.name,
            tableName: 'campaignUniqueUrls',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return campaignUniqueUrls;
};
