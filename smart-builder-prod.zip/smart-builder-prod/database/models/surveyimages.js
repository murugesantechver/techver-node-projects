'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Surveyimages extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            Surveyimages.belongsTo(models.Survey, {
                foreignKey: 'surveyId',
                constrains: true,
                allowNull: false,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'surveyData',
            });
        }
    }
    Surveyimages.init(
        {
            imageUrl: {
                type: DataTypes.JSON,
                allowNull: false,
            },
            imageType: {
                type: DataTypes.STRING(20),
                allowNull: false,
            },
        },
        {
            sequelize,
            modelName: Surveyimages.name,
            tableName: 'Surveyimages',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Surveyimages;
};
