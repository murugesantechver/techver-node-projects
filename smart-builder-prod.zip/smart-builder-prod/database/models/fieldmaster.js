'use strict';
const { Model } = require('sequelize');
const { CONSTANTS } = require('../../configs');
module.exports = (sequelize, DataTypes) => {
    class Fieldmaster extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            // define association here
        }
    }
    Fieldmaster.init(
        {
            fieldName: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            displayName: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            requireFileUpload: {
                type: DataTypes.BOOLEAN,
                allowNull: true,
            },
            fieldType: {
                type: DataTypes.STRING,
                allowNull: true,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.fieldType],
                        msg: 'Invalid field type',
                    },
                },
            },
        },
        {
            sequelize,
            modelName: Fieldmaster.name,
            tableName: 'Fieldmasters',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Fieldmaster;
};
