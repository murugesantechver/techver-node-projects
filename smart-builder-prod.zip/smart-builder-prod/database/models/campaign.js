'use strict';
const { Model } = require('sequelize');
const { CONSTANTS } = require('../../configs');
module.exports = (sequelize, DataTypes) => {
    class Campaign extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            Campaign.belongsTo(models.User, {
                foreignKey: 'campaignOwner',
                constrains: true,
                allowNull: false,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'ownerData',
            });
            Campaign.belongsTo(models.Company, {
                foreignKey: 'companyId',
                constrains: true,
                allowNull: false,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'companyName',
            });
            Campaign.belongsTo(models.Subcompany, {
                foreignKey: 'subCompanyId',
                constrains: true,
                allowNull: true,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'subCompanyName',
            });
            Campaign.hasMany(models.Field, {
                foreignKey: 'campaignId',
            });
            Campaign.hasMany(models.Invitee, {
                foreignKey: 'campaignId',
            });
            Campaign.hasMany(models.Voucher, {
                foreignKey: 'campaignId',
            });
            Campaign.hasMany(models.Survey, {
                foreignKey: 'campaignId',
            });
            Campaign.hasMany(models.Denomination, {
                foreignKey: 'campaignId',
            });
        }
    }
    Campaign.init(
        {
            campaignName: {
                type: DataTypes.STRING(20),
                allowNull: false,
            },
            issuedDate: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            startDate: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            endDate: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            inviteeAttempts: {
                type: DataTypes.INTEGER,
                allowNull: false,
                defaultValue: 1,
            },
            campaignUrl: {
                type: DataTypes.STRING,
                unique: true,
                allowNull: true,
            },
            status: {
                type: DataTypes.STRING(20),
                allowNull: false,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.campaignStatus],
                        msg: 'Invalid status value',
                    },
                },
            },
            campaignMode: {
                type: DataTypes.STRING,
                allowNull: false,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.campaignModes],
                        msg: 'Invalid Campaign Mode',
                    },
                },
                default: CONSTANTS.ENUMS.campaignModes[0],
            },
            publish: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
            },
            isActive: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
            },
        },
        {
            sequelize,
            modelName: Campaign.name,
            tableName: 'Campaigns',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Campaign;
};
