'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class OAuthClients extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            OAuthClients.hasOne(models.OAuthTokens, {
                foreignKey: 'clientId',
                as: 'token',
            });
        }
    }
    OAuthClients.init(
        {
            clientId: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            clientSecret: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            redirectUri: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            grants: {
                type: DataTypes.ARRAY(DataTypes.STRING),
                allowNull: false,
            },
        },
        {
            sequelize,
            modelName: OAuthClients.name,
            tableName: 'OAuthClients',
            timestamps: true,
        }
    );
    return OAuthClients;
};
