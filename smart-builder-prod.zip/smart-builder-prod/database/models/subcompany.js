'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Subcompany extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {}
    }
    Subcompany.init(
        {
            subCompanyName: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
        },
        {
            sequelize,
            modelName: Subcompany.name,
            tableName: 'Subcompanies',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Subcompany;
};
