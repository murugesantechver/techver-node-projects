'use strict';
const { Model } = require('sequelize');
const { CONSTANTS } = require('../../configs');
module.exports = (sequelize, DataTypes) => {
    class Invitee extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            Invitee.belongsTo(models.Campaign, {
                foreignKey: 'campaignId',
                constrains: true,
                allowNull: true,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'campaignData',
            });
        }
    }
    Invitee.init(
        {
            name: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            phone: {
                type: DataTypes.STRING(12),
                allowNull: false,
            },
            status: {
                type: DataTypes.STRING(20),
                allowNull: false,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.inviteeStatus],
                        msg: 'Invalid status value',
                    },
                },
            },
            rewardType: {
                type: DataTypes.STRING(20),
                allowNull: false,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.rewardFrame],
                        msg: 'Invalid Reward Frame',
                    },
                },
            },
            participated: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: false,
            },
            attempts: {
                type: DataTypes.INTEGER,
                allowNull: true,
                defaultValue: 0,
            },
            verified: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: false,
            },
        },
        {
            sequelize,
            modelName: Invitee.name,
            tableName: 'Invitees',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Invitee;
};
