'use strict';
const { Model } = require('sequelize');
const { CONSTANTS } = require('../../configs');
module.exports = (sequelize, DataTypes) => {
    class Survey extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequeliz lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            Survey.belongsTo(models.Campaign, {
                foreignKey: 'campaignId',
                constrains: true,
                allowNull: true,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'campaignData',
            });
            Survey.hasMany(models.Surveyimages, {
                foreignKey: 'surveyId',
            });
        }
    }
    Survey.init(
        {
            bookingId: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            orderId: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            beneficiaryId: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            skuNumber: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            amount: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            paymentStatus: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            message: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            name: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            mobileNumber: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            otp: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            firstName: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            lastName: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            pinCode: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            panCard: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            dob: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            state: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            city: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            address1: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            address2: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            email: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            aadharCard: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            ifscCode: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            accountNumber: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            vpa: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            voucherCode: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            inviteePhone: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            paytm: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            images: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            date: {
                type: DataTypes.DATE(128),
                allowNull: true,
            },
        },
        {
            sequelize,
            modelName: Survey.name,
            tableName: 'Surveys',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Survey;
};
