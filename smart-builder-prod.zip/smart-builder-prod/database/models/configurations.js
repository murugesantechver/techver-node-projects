'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Configurations extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            // define association here
        }
    }
    Configurations.init(
        {
            name: {
                type: DataTypes.STRING(20),
                unique: true,
                allowNull: true,
            },
            value: {
                type: DataTypes.STRING(255),
                unique: true,
                allowNull: true,
            },
        },
        {
            sequelize,
            modelName: Configurations.name,
            tableName: 'Configurations',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Configurations;
};
