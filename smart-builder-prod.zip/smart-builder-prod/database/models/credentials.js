'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Credentials extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            // define association here
        }
    }
    Credentials.init(
        {
            authorizationCode: {
                type: DataTypes.STRING(255),
                unique: true,
                allowNull: true,
            },
            bearerToken: {
                type: DataTypes.STRING(255),
                unique: true,
                allowNull: true,
            },
            requireNewTokenGeneration: {
                type: DataTypes.BOOLEAN,
                defaultValue: true,
                allowNull: true,
            },
            expiresOn: {
                type: DataTypes.DATE,
                allowNull: true,
            },
        },
        {
            sequelize,
            modelName: Credentials.name,
            tableName: 'Credentials',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Credentials;
};
