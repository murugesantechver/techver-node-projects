'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Denomination extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            Denomination.belongsTo(models.Campaign, {
                foreignKey: 'campaignId',
                constraints: true,
                allowNull: false,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'campaignDenomination',
            });
        }
    }
    Denomination.init(
        {
            value: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
            count: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
            redeemedCount: {
                type: DataTypes.INTEGER,
                allowNull: false,
                defaultValue: 0,
            },
            isRedeemable: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: true,
            },
        },
        {
            sequelize,
            modelName: Denomination.name,
            tableName: 'Denomination',
            timestamps: true,
        }
    );
    return Denomination;
};
