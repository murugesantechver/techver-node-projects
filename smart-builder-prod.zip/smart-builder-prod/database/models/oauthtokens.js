'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class OAuthTokens extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            OAuthTokens.belongsTo(models.OAuthClients, {
                foreignKey: 'clientId',
                as: 'client',
            });
            OAuthTokens.belongsTo(models.OAuthUsers, {
                foreignKey: 'userId',
                as: 'user',
            });
        }
    }
    OAuthTokens.init(
        {
            accessToken: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            accessTokenExpiresAt: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            refreshToken: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            refreshTokenExpiresAt: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            clientId: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
            userId: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
        },
        {
            sequelize,
            modelName: OAuthTokens.name,
            tableName: 'OAuthTokens',
            timestamps: true,
        }
    );
    return OAuthTokens;
};
