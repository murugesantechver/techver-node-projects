'use strict';
const { Model } = require('sequelize');
const { CONSTANTS } = require('../../configs');
module.exports = (sequelize, DataTypes) => {
    class Voucher extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            Voucher.belongsTo(models.Campaign, {
                foreignKey: 'campaignId',
                constrains: true,
                allowNull: true,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'campaignData',
            });
        }
    }
    Voucher.init(
        {
            voucherNumber: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            denomination: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            status: {
                type: DataTypes.STRING,
                allowNull: false,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.voucherStatus],
                        msg: 'Invalid status value',
                    },
                },
            },
        },
        {
            sequelize,
            modelName: Voucher.name,
            tableName: 'Vouchers',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Voucher;
};
