'use strict';
const { Model } = require('sequelize');
const { CONSTANTS } = require('../../configs');
module.exports = (sequelize, DataTypes) => {
    class Field extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            Field.belongsTo(models.Campaign, {
                foreignKey: 'campaignId',
                constrains: true,
                allowNull: true,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'campaignData',
            });
        }
    }
    Field.init(
        {
            fieldName: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            displayName: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            requireFileUpload: {
                type: DataTypes.BOOLEAN,
                allowNull: true,
                defaultValue: false,
            },
            isMandatory: {
                type: DataTypes.BOOLEAN,
                allowNull: true,
                defaultValue: true,
            },
            fieldType: {
                type: DataTypes.STRING(20),
                allowNull: true,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.fieldType],
                        msg: 'Invalid field type',
                    },
                },
            },
            rewardMode: {
                type: DataTypes.STRING(20),
                allowNull: true,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.rewardFrame],
                        msg: 'Invalid Reward Frame Provided',
                    },
                },
            },
        },
        {
            sequelize,
            modelName: Field.name,
            tableName: 'Fields',
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Field;
};
