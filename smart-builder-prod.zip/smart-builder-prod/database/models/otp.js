'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Otp extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            Otp.belongsTo(models.Campaign, {
                foreignKey: 'campaignId',
                constrains: true,
                allowNull: false,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'campaignData',
            });
        }
    }
    Otp.init(
        {
            mobileNumber: {
                type: DataTypes.STRING(12),
                allowNull: false,
            },
            otp: {
                type: DataTypes.STRING(4),
                allowNull: false,
            },
            timestamp: {
                type: DataTypes.DATE,
                allowNull: false,
            },
        },
        {
            sequelize,
            modelName: Otp.name,
            tableName: 'Otps',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Otp;
};
