'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Company extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {}
    }
    Company.init(
        {
            companyName: {
                type: DataTypes.STRING(255),
                unique: true,
                allowNull: false,
            },
        },
        {
            sequelize,
            modelName: Company.name,
            tableName: 'Companies',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Company;
};
