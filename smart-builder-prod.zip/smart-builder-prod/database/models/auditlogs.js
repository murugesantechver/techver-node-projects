'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Auditlogs extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            // define association here
            Auditlogs.belongsTo(models.User, {
                foreignKey: 'userId',
                constrains: true,
                allowNull: false,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'user',
            });
        }
    }
    Auditlogs.init(
        {
            currentTime: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            action: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            url: {
                type: DataTypes.STRING,
                allowNull: false,
            },
        },
        {
            sequelize,
            modelName: Auditlogs.name,
            tableName: 'Auditlogs',
            timestamps: true,
            indexes: [
                {
                    fields: ['id'],
                },
            ],
        }
    );
    return Auditlogs;
};
