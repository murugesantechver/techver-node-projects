'use strict';
const { Model } = require('sequelize');
const { CONSTANTS } = require('../../configs');
module.exports = (sequelize, DataTypes) => {
    class User extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            User.belongsTo(models.Company, {
                foreignKey: 'companyId',
                constrains: true,
                allowNull: false,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'companyName',
            });
            User.belongsTo(models.Subcompany, {
                foreignKey: 'subCompanyId',
                constrains: true,
                allowNull: true,
                onDelete: 'cascade',
                onUpdate: 'cascade',
                as: 'subCompanyName',
            });
        }
    }
    User.init(
        {
            firstName: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            lastName: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            userName: {
                type: DataTypes.STRING(128),
                unique: true,
                allowNull: true,
            },
            email: {
                type: DataTypes.STRING(50),
                allowNull: false,
                validate: {
                    notNull: {
                        msg: 'Email required',
                    },
                    isEmail: {
                        msg: 'Valid email id required',
                    },
                },
            },
            password: {
                type: DataTypes.STRING(20),
                allowNull: false,
            },
            mobile: {
                type: DataTypes.STRING(12),
                allowNull: true,
            },
            contactPersonName: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            country: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            location: {
                type: DataTypes.STRING(128),
                allowNull: true,
            },
            status: {
                type: DataTypes.STRING,
                allowNull: false,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.userStatus],
                        msg: 'Invalid status value',
                    },
                },
            },
            wrongPasswordAttempts: {
                type: DataTypes.INTEGER,
                allowNull: true,
                defaultValue: 0,
            },
            verifyOtp: {
                type: DataTypes.INTEGER,
                allowNull: true,
            },
            emailSent: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: false,
            },
        },
        {
            sequelize,
            modelName: User.name,
            tableName: 'Users',
            timestamps: true,
            indexes: [
                {
                    fields: ['userName'],
                },
            ],
        }
    );
    return User;
};
