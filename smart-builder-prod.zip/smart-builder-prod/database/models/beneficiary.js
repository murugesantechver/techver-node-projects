'use strict';
const { Model } = require('sequelize');
const { CONSTANTS } = require('../../configs');
module.exports = (sequelize, DataTypes) => {
    class Beneficiary extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {}
    }
    Beneficiary.init(
        {
            beneficiaryShortName: {
                type: DataTypes.STRING(50),
                allowNull: true,
            },
            beneficiaryId: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            accountType: {
                type: DataTypes.STRING(50),
                allowNull: false,
                validate: {
                    isIn: {
                        args: [CONSTANTS.ENUMS.paymentType],
                        msg: 'Invalid payment type',
                    },
                },
            },
            beneficiaryDetails: {
                type: DataTypes.STRING(128),
                allowNull: false,
            },
            isBeneficiaryValidated: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
            },
        },
        {
            sequelize,
            modelName: Beneficiary.name,
            tableName: 'Beneficiary',
            indexes: [
                {
                    fields: ['beneficiaryDetails'],
                },
            ],
        }
    );
    return Beneficiary;
};
