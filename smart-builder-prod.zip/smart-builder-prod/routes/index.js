const express = require('express');
const { version } = require('../package.json');

const router = express.Router();
const ClientRoutes = require('../modules/client/client.route');
const CampaignRoutes = require('../modules/campaign/');
const CommonRoutes = require('../modules/common/common.route');
const UserRoutes = require('../modules/user/user.route');
const CompanyRoutes = require('../modules/company/company.route');
const AuthRoutes = require('../modules/auth/auth.route');
const ConfigurationRoutes = require('../modules/configuration/configuration.route');
const NotificationRoutes = require('../modules/notification/notification.route');
const paymentRoutes = require('../modules/campaign/payment/payment.route');
const walletRoutes = require('../modules/campaign/wallet/wallet.route');
const pwsRoutes = require('../modules/campaign/pwsIntegration/pws.route');
// eslint-disable-next-line no-unused-vars
router.get('/', (req, res) => {
    res.send(`API Endpoint is working. Version - ${version}`);
});

router.use('/user', UserRoutes);
router.use('/client', ClientRoutes);
router.use('/campaign', CampaignRoutes);
router.use('/misc', CommonRoutes);
router.use('/company', CompanyRoutes);
router.use('/api/auth', AuthRoutes);
router.use('/configurations', ConfigurationRoutes);
router.use('/payment', paymentRoutes);
router.use('/api/notification', NotificationRoutes);
router.use('/wallet', walletRoutes);
router.use('/api/campaign', pwsRoutes);

module.exports = router;
