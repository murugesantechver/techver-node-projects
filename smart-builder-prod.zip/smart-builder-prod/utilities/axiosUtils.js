const axios = require('axios');
const logger = require('./logger');

exports.request = async (config) =>
    new Promise((resolve, reject) => {
        axios(config)
            .then((result) => {
                resolve(result);
            })
            .catch((error) => {
                if (error && error.response) {
                    logger.error('Error Occured');
                }
                reject(error.data);
            });
    });
