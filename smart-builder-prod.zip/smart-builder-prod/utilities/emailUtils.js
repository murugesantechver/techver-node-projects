const nodemailer = require('nodemailer');
const { CONSTANTS } = require('../configs');

const transporter = async () => {
    try {
        const transporter = nodemailer.createTransport({
            // service:'yahoo',
            host: 'smtp.gmail.com',
            port: 587,
            auth: {
                user: CONSTANTS.EMAIL.emailCreds.email,
                pass: CONSTANTS.EMAIL.emailCreds.APP_PASSWORD,
            },
        });
        return transporter;
    } catch (err) {
        return err;
    }
};

exports.sendUserRegistrationMail = async (email, userName, redirectLink) => {
    const subject = 'Registration Details';
    const courseMailOptions = {
        from: CONSTANTS.EMAIL.emailCreds.email,
        to: email,
        subject: subject,
        html: `<!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <meta http-equiv="X-UA-Compatible" content="ie=edge">
          <title>Smart Builder</title>
          <style>
            body {
              font-family: sans-serif;
              font-size: 16px;
              line-height: 1.5;
              margin: 0;
              padding: 0;
            }
        
            h1 {
              font-size: 24px;
              font-weight: bold;
              margin: 0;
            }
        
            a {
              color: #1a4b99;
              text-decoration: none;
            }
        
            button {
              background-color: #1a4b99;
              color: #fff;
              border: none;
              border-radius: 5px;
              padding: 10px;
              cursor: pointer;
            }
          </style>
        </head>
        <body>
          <div style="max-width: 600px; margin: 0 auto;">
            <h1>Welcome to SmartBuilder</h1>
            <p>Hey there,</p>
            <p>It's great to have you on board. Please take a moment to reset your password and use the provided username to login.</p>
            <p>
              <p>Username - ${userName}</p>
              <a href="${redirectLink}">
                <button>Reset Password</button>
              </a>
            </p>
            <p>Thank you,</p>
            <p>The SmartBuilder Team</p>
          </div>
        </body>
        </html>
        `,
    };
    try {
        let emailTransporter = await transporter();
        await emailTransporter.sendMail(courseMailOptions);
        return true;
    } catch (err) {
        if (err) {
            return false;
        }
    }
};

exports.sendOTPViaMail = async (email, otp) => {
    const subject = 'Max Password Attempts !';
    const courseMailOptions = {
        from: CONSTANTS.EMAIL.emailCreds.email,
        to: email,
        subject: subject,
        html: `<html lang="en">
    
        <head>
            <meta http-equiv="Content-Type" content="text/html charset=UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <link href="https://fonts.googleapis.com/css?family=Quicksand:400,600&display=swap" rel="stylesheet">
            <title>Smart Builder</title>
        </head>
        
        <body style="font-family: 'Quicksand';font-weight:400;margin:0 auto !important; padding:0 !important; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;width: 100%;max-width: 600px;">
            <center>
                <table cellpadding="0" cellspacing="0" border="0" style="height:auto !important; margin:0; padding: 30px 10px; width:100% !important; background: black; border: 1px solid #ececec;">
                    <tr>
                    </tr>
                    <!-- Content -->
                    <tr>
                        <td style="background: #fff; padding: 15px 25px; border: 1px solid #D1D3D3;text-align: center;">
                            <p align="center" style="color: #001F31; font-size: 14px; line-height: 24px;padding-bottom: 25px;"> OTP For Verification</p>
                            <ul>
                                OTP : ${otp}
                            </ul>
                            <p align="center" style=" color: #001F31; font-size: 14px; padding-top: 30px;"> Thank you</p>
                            <p align="center" style=" color: #001F31; font-size: 14px;"> Smartbuilder Team</p>
        
                        </td>
                    </tr>
                </table>
            </center>
        </body>
        
        </html>`,
    };

    try {
        let emailTransporter = await transporter();
        await emailTransporter.sendMail(courseMailOptions);
        return true;
    } catch (err) {
        if (err) {
            return false;
        }
    }
};
