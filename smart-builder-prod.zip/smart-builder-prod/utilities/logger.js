/* const { createLogger, format, transports } = require('winston');
const { combine, timestamp, printf } = format;

const logFormat = printf(({ timestamp, level, message }) => {
  return `${timestamp} ${level}: ${message}`;
});

const logger = createLogger({
  level: 'info',
  format: combine(
    timestamp({ format: 'YYYY-DD-MM, h:mm:ss A' }),
    logFormat
  ),
  transports: [
    new transports.Console({
      format: combine(
        format.colorize(),
        logFormat
      )
    }),
    new transports.File({
      filename: `${__dirname}/../logs/app.log`,
      maxsize: 2000, // 100KB
      maxFiles: 5,
      tailable: true,
    })
  ]
});

module.exports = logger; */

/* const { createLogger, format, transports } = require('winston');
const { combine, timestamp, printf } = format;
const moment = require('moment');
const fs = require('fs');
const { log } = require('console');

const logFormat = printf(({ timestamp, level, message }) => {
  return `${timestamp} ${level}: ${message}`;
});

const timestampFormat = 'YYYY-MM-DD-HH-mm-ss';

const logDirectory = `${__dirname}/../logs`;

function isLogFileFull(filename, maxSize) {
  try {
    const stats = fs.statSync(filename);
    return stats.size >= maxSize;
  } catch (err) {
    return false;
  }
}

function getNewLogFilename() {
  let index = 0;
  let newFilename;
  do {
    newFilename = `${logDirectory}/${moment().format(timestampFormat)}-${index}.log`;
    index++;
  } while (fs.existsSync(newFilename));
  return newFilename;
}

const existingLogFile = `${logDirectory}/${moment().format(timestampFormat)}.log`;

const logFilename = fs.existsSync(existingLogFile) && isLogFileFull(existingLogFile, 2000)
  ? getNewLogFilename()
  : existingLogFile;

const logger = createLogger({
  level: 'info',
  format: combine(
    timestamp({ format: 'YYYY-DD-MM, h:mm:ss A' }),
    logFormat
  ),
  transports: [
    new transports.Console({
      format: combine(
        format.colorize(),
        logFormat
      )
    }),
    new transports.File({
      filename: logFilename,
      maxsize: 2000,
      maxFiles: 5,
      tailable: true,
    })
  ]
});

if (!fs.existsSync(logDirectory)) {
  fs.mkdirSync(logDirectory);
}

module.exports = logger; */

'use strict';

const appRoot = require('app-root-path');
const winston = require('winston');
require('winston-daily-rotate-file');

// define the custom settings for each transport (file, console)
const options = {
    file: {
        level: 'info',
        filename: `${appRoot}/logs/app-%DATE%.log`,
        datePattern: 'YYYY-MM-DD',
        handleExceptions: true,
        json: true,
        zippedArchive: false,
        maxSize: '100k', // Maximum log file size is 100 KB
        maxFiles: '1d',
        colorize: true,
    },
    console: {
        level: 'debug',
        handleExceptions: true,
        json: false,
        colorize: true,
    },
};

// instantiate a new Winston Logger with the settings defined above
const logger = winston.createLogger({
    transports: [new winston.transports.DailyRotateFile(options.file), new winston.transports.Console(options.console)],
    exitOnError: false, // do not exit on handled exceptions
});

// create a stream object with a 'write' function that will be used by `morgan`
logger.stream = {
    write: function (message) {
        // use the 'info' log level so the output will be picked up by both transports
        logger.info(message);
    },
};

module.exports = logger;
