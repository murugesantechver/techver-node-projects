const amqp = require('amqplib');
const { CONSTANTS } = require('../../configs');
const { publishToQueue } = require('./publisher');
const { consumeQueue } = require('./consumer');
const { logger } = require('../');
let channel;
let conn;
let queueConnected = false;

async function setupRabbitMQ() {
    try {
        conn = await amqp.connect(CONSTANTS.QUEUE.CONNECTION_URL);

        channel = await conn.createChannel();
        queueConnected = true;

        logger.info('RabbitMQ connected');

        conn.on('error', (err) => {
            queueConnected = false;
            logger.error({ message: `RabbitMQ connection error - ${err.toString()}` });
        });
        conn.on('close', () => {
            queueConnected = false;
            logger.warn({ message: 'RabbitMQ connection Closed' });
        });
    } catch (err) {
        logger.error({ message: `RabbitMQ connection error - ${err.toString()}` });
    }
}

setupRabbitMQ();

module.exports = { conn, channel, publishToQueue, consumeQueue, queueConnected };
