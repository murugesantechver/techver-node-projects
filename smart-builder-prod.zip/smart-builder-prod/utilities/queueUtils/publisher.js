const amqp = require('amqplib');
const { CONSTANTS } = require('../../configs');

exports.publishToQueue = async (queueName, data) => {
    const conn = await amqp.connect(CONSTANTS.QUEUE.CONNECTION_URL);
    const channel = await conn.createChannel();
    await channel.assertQueue(queueName);
    // console.log(queueName,data);
    await channel.assertQueue(queueName);
    // eslint-disable-next-line
    const respData = channel.sendToQueue(queueName, new Buffer.from(JSON.stringify(data)), { persistent: true });
};
