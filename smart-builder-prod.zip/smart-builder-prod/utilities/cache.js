const nodeCache = require('node-cache');

const configCache = new nodeCache({ stdTTL: 60 * 60 }); // Cache with a default TTL of 1 hour

exports.createCache = async (key, value) => {
    configCache.set(key, value);
    return;
};

exports.deleteCache = async (cacheData) => {
    configCache.del(cacheData.name);
    return;
};

exports.getCache = async (cacheData) => {
    return await configCache.get(cacheData);
};
