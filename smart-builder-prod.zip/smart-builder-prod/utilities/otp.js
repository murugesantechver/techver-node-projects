const randomize = require('randomatic');
const { CONSTANTS } = require('../configs');
const client = require('twilio')(CONSTANTS.OTP.twillioAccountId, CONSTANTS.OTP.twillioAuthToken);

exports.generate = async () => {
    const otp = randomize('0', 4);
    return otp;
};

exports.sendOtpToPhone = async (to, otp, company) => {
    return await client.messages.create({
        body: `Hi User, ${otp} is your OTP, Thank You, ${company}.`,
        from: CONSTANTS.OTP.twillioFromNumber,
        to: `+91${to}`,
    });
};
