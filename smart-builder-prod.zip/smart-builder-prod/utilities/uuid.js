const { v4: uuidv4 } = require('uuid');

let counter = 0;

exports.generateUniqueUUID = (desiredLength) => {
    // Increment the counter
    counter++;

    // Generate a UUID
    const uuid = uuidv4().replace(/-/g, '');

    const uniqueId = `CAMP${counter.toString().padStart(4, '0')}${uuid.slice(0, desiredLength)}`;

    return uniqueId;
};
