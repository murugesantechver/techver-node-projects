const _ = require('lodash');
const userRepository = require('../modules/user/user.repository');
const surveyRepository = require('../modules/campaign/survey/survey.repository');
const paymentRepository = require('../modules/campaign/payment/payment.repository');
const { CONSTANTS } = require('../configs');
const { env } = CONSTANTS.APP;
const { Op } = require('sequelize');
const { encryptData } = require('../helpers/encryption');

exports.getBaseUrl = async () => {
    const config = CONSTANTS.APP.baseUrl[env];
    let baseUrl;
    if (config.use_env_variable) {
        baseUrl = config;
    } else {
        baseUrl = 'http://localhost:4000';
    }
    return baseUrl;
};

exports.generateUniqueUsernameAndCode = async (str, email) => {
    const words = str.split(' ');
    const initials = [];

    for (let i = 0; i < words.length; i++) {
        const word = words[i];
        if (word.length > 0) {
            initials.push(word[0].toUpperCase());
        }
    }

    const matches = email.match(/(.+)@/);
    const prefix = matches ? matches[1] : '';
    const uuid = Math.floor(1000 + Math.random() * 9000);

    const uniqueUsername = initials.join('');
    const uniqueCode = prefix + uuid;
    const userName = uniqueUsername + uniqueCode;
    const checks = [{ userName: { [Op.eq]: userName } }];
    let doesClientExists = await userRepository.checkUserAlreadyExists(checks);

    if (doesClientExists) {
        return exports.generateUniqueUsernameAndCode(str, email); // Corrected recursive call
    }

    return userName;
};

exports.generateBookingId = async (companyName) => {
    // Remove spaces from companyName
    const companyNameWithoutSpaces = companyName.replace(/\s+/g, '');

    // Truncate the companyName to 10 characters
    const truncatedCompanyName = companyNameWithoutSpaces.slice(0, 10);

    // Generate a 10-character random value
    const length = 10;
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let randomValue = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * chars.length);
        randomValue += chars.charAt(randomIndex);
    }

    // Concatenate the truncated companyName and random value
    const bookingId = truncatedCompanyName + '_' + randomValue;
    const checks = [{ bookingId: { [Op.eq]: bookingId } }];
    let doesBookingIdExists = await surveyRepository.surveyExists(checks);
    if (doesBookingIdExists) {
        this.generateBookingId(companyName);
    }
    return bookingId;
};

exports.generateUniqueShortNameForBeneficiary = async (vpa) => {
    // Remove spaces from vpa
    const upiIdWithoutSpaces = vpa.replace(/\s+/g, '');
    // Truncate the vpa to 10 characters
    const truncatedUpiId = upiIdWithoutSpaces.slice(0, 10);
    // Generate a 10-character random value using only alphabets
    const length = 10;
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    let randomValue = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * chars.length);
        randomValue += chars.charAt(randomIndex);
    }

    // Concatenate the truncated vpa and random value
    const shortName = truncatedUpiId + randomValue;

    // Check if the shortName already exists in the database
    const checks = [{ beneficiaryShortName: { [Op.eq]: shortName } }];
    let doesShortNameExist = await paymentRepository.checkExistsOnBeneficiary(checks);

    // If the shortName already exists, recursively generate a new one
    if (doesShortNameExist) {
        return this.generateUniqueShortNameForBeneficiary(vpa);
    }
    return shortName;
};

exports.generatePassword = () => {
    const length = 10;
    const uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';
    const numericChars = '0123456789';
    const specialChars = '@$!%*?&';
    let password = '';

    const uppercaseChar = uppercaseChars[Math.floor(Math.random() * uppercaseChars.length)];
    const lowercaseChar = lowercaseChars[Math.floor(Math.random() * lowercaseChars.length)];
    const numericChar = numericChars[Math.floor(Math.random() * numericChars.length)];
    const specialChar = specialChars[Math.floor(Math.random() * specialChars.length)];

    password += uppercaseChar + lowercaseChar + numericChar + specialChar;

    const remainingLength = length - 4;
    const allChars = uppercaseChars + lowercaseChars + numericChars + specialChars;

    for (let i = 0; i < remainingLength; i++) {
        const randomIndex = Math.floor(Math.random() * allChars.length);
        password += allChars.charAt(randomIndex);
    }

    return password;
};

// Generate unique patterned IDs using a combination of timestamp and random numbers
exports.generateUniqueIdsWithUrls = async (count, campaignId) => {
    const dataWithUrls = [];
    const url = await this.getBaseUrl();
    const encryptedCampaign = encryptData(campaignId);
    for (let i = 0; i < count; i++) {
        const timestamp = Date.now();
        const counter = i + 1;
        const randomPart = _.random(0, 999999);

        const uniqueId = `${timestamp}${counter}${randomPart}`;
        const campaignUrl = `${url}/${encryptedCampaign}/${uniqueId}`;

        const entry = {
            campaignId,
            uniqueId,
            url: campaignUrl,
        };

        dataWithUrls.push(entry);
    }
    return dataWithUrls;
};

exports.generateUniqueIds = async () => {
    const timestamp = Date.now();
    const randomPart = _.random(0, 999999);

    const uniqueId = `${timestamp}${randomPart}`;
    return uniqueId;
};

// Generate Reference Number after Look Up
exports.generateRefNo = async () => {
    let refNo = '';
    // generate a ref No here
    const checks = [{ beneficiaryId: { [Op.eq]: refNo } }];
    const refNoExists = await paymentRepository.checkExistsOnBeneficiary(checks);
    if (refNoExists) {
        this.generateRefNo();
    }
    return refNo;
};
