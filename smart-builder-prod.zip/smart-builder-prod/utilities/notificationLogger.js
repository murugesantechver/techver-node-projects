const { createLogger, format, transports } = require('winston');
const appRoot = require('app-root-path');

const notificationLogger = createLogger({
    format: format.combine(
        format.colorize(),
        format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        format.printf(({ timestamp, message }) => {
            return `${timestamp} ${message}`;
        })
    ),
    transports: [
        new transports.Console(),
        new transports.File({ filename: `${appRoot}/modules/notification/logs/notification.log` }), // You can also log to a file
    ],
});

module.exports = notificationLogger;
