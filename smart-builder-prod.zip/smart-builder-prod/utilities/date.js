const moment = require('moment');
const { CONSTANTS } = require('../configs');
const { dayGap } = CONSTANTS.QWIKGIFTAPI.tokenGenerationOptions;

exports.formatDate = (dateString) => {
    const date = new Date(dateString);
    const formattedDate = date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
    });
    return formattedDate;
};

exports.getCompaignStatusByDate = async (startDate, endDate) => {
    const date = moment();
    let status;
    if (date < startDate) {
        status = CONSTANTS.ENUMS.campaignStatus[2];
    } else {
        status = CONSTANTS.ENUMS.campaignStatus[0];
    }
    if (date < endDate) {
        status = CONSTANTS.ENUMS.campaignStatus[0];
    } else {
        status = CONSTANTS.ENUMS.campaignStatus[2];
    }
    if (startDate < date && date < endDate) {
        status = CONSTANTS.ENUMS.campaignStatus[0];
    } else {
        status = CONSTANTS.ENUMS.campaignStatus[1];
    }
    return status;
};

exports.addDaysToDate = () => {
    const currentDate = moment();
    return moment(currentDate).add(dayGap, 'days').toDate();
};

exports.hasDaysElapsed = (referenceDate) => {
    const date = moment();
    const currentDate = moment(date).toDate();
    // Compare currentDate with referenceDate
    return moment(currentDate).isAfter(referenceDate);
};
