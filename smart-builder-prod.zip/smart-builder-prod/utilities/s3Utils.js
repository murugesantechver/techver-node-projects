const AWS = require('aws-sdk');
const { getCache } = require('./cache');

// Get the environments from cache asynchronously.
async function getEnvironmentsFromCache() {
    const environments = await Promise.all([
        getCache('ACCESS_KEY_ID'),
        getCache('AWS_SECRET_ACCESS_KEY'),
        getCache('AWS_REGION'),
        getCache('AWS_STORAGE_BUCKET'),
    ]);
    return environments;
}

async function s3Client() {
    const environments = await getEnvironmentsFromCache();

    // const s3 = new AWS.S3({
    //     accessKeyId: environments[0],
    //     secretAccessKey: environments[1],
    //     region: environments[2],
    // });
    const s3 = new AWS.S3({
        accessKeyId: 'AKIA6IYZSR4LXM2E4KX4',
        secretAccessKey: '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',
        region: 'ap-south-1',
    });

    return s3;
}

const uploadFile = async (file, path) => {
    console.log('Entered Uploading file');
    console.log('File details are', file, path);
    const { s3, environments } = await s3Client();
    try {
        return await s3
            .upload({
                Bucket: environments[3],
                Body: file.data,
                Key: path,
                ContentType: file.mimetype,
            })
            .promise();
    } catch (ex) {
        return false;
    }
};

const deleteFile = async (path) => {
    const { s3, environments } = await s3Client();
    try {
        return await s3
            .deleteObject({
                Bucket: environments[3],
                Key: path,
            })
            .promise();
    } catch (ex) {
        // console.error(ex.toString());
        return false;
    }
};

const copyFile = async (source, destination) => {
    const { s3, environments } = await s3Client();
    try {
        const a = await s3
            .copyObject({
                Bucket: environments[3],
                CopySource: source,
                Key: destination,
            })
            .promise();
        return a;
    } catch (ex) {
        // console.error(ex.toString());
        return false;
    }
};

module.exports = {
    s3Client,
    uploadFile,
    deleteFile,
    copyFile,
};
