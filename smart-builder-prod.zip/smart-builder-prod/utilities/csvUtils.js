const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const fs = require('fs');
const path = require('path');
const { CONSTANTS } = require('../configs');
const { voucher, invitee, campaignUrl } = CONSTANTS.TEMPLATES;

exports.formatKeys = async (keysArray) => {
    return keysArray.map((key) => {
        return {
            id: key,
            title: key.charAt(0).toUpperCase() + key.slice(1),
        };
    });
};

exports.convertArrayToCsvFile = async (dataArray, campaignId, type, template) => {
    let header;
    let csvWriter;
    let records;
    let directoryPath;
    if (type === 'survey') {
        let allKeysForHeader;
        if (dataArray.length > 0) {
            allKeysForHeader = dataArray.reduce((keys, obj) => {
                Object.keys(obj).forEach((key) => {
                    if (key !== 'id' && !keys.includes(key)) {
                        keys.push(key);
                    }
                });
                return keys;
            }, []);
        }
        header = await this.formatKeys(allKeysForHeader); // Get the header based on the keys created
        records = await dataArray.map((item) => {
            const record = {};
            allKeysForHeader.forEach((key) => {
                record[key] = item[key] ? item[key] : '';
            });
            return record;
        });
    }
    if (type === 'invitee') {
        header = template ? invitee[template] : invitee.template1; // Get the header based on the template
        // Extract the required fields from the data array
        records = dataArray.map((item) => ({
            name: item.name,
            phone: item.phone,
            status: item.status,
        }));
    }
    if (type === 'voucher') {
        header = template ? voucher[template] : voucher.template1;
        records = dataArray.map((item) => ({
            voucherNumber: item.voucherNumber,
            denomination: item.denomination,
            status: item.status,
        }));
    }
    if (type === 'campaignurl') {
        header = campaignUrl.template1; // Get the header based on the template
        // Extract the required fields from the data array
        records = dataArray.map((item) => ({
            uniqueId: item.uniqueId,
            uniqueUrl: item.campaignurl,
        }));
    }
    csvWriter = createCsvWriter({
        path: `./uploads/${type}/${campaignId}_${type}_${Math.floor(new Date().getTime() / 1000)}.csv`, // Replace with the actual path where you want to save the file
        header: header,
    });

    directoryPath = path.join(__dirname, `../../../../uploads/${type}`);

    // Create the directory if it doesn't exist
    if (!fs.existsSync(directoryPath)) {
        fs.mkdirSync(directoryPath, { recursive: true });
    }

    return csvWriter
        .writeRecords(records)
        .then(() => {
            const serverUrl = `https://dev.customerengagelabs.com/files/${type}/${campaignId}_${type}_${Math.floor(new Date().getTime() / 1000)}.csv`; // Replace with your server URL and desired file URL
            return serverUrl;
        })
        .catch((error) => {
            throw error;
        });
};
